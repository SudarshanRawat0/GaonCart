# Build the GaonCart APK on GitHub (no computer needed)

Status: the workflow file has been statically checked (YAML, step order, shell syntax, URL validation, project-location logic) but has
NOT been run on GitHub yet. It is only proven once a GitHub Actions run finishes green. The first run may need a fix; the logs artifact tells us what.

## A. From an Android phone
1. Save `gaoncart-github-ready.zip` to your phone. DO NOT extract it.
2. Open https://github.com in Chrome, log in (or sign up). Menu (⋮) > tick **Desktop site** (makes the pages below easier).
3. Tap **+** > **New repository**. Name: `gaoncart`. Choose **Private**. Tap **Create repository**.
4. On the empty repo page tap **uploading an existing file**. Tap **choose your files**, pick `gaoncart-github-ready.zip` (Downloads folder). Wait for 100%, then **Commit changes**.
5. Create the workflow file: **Add file > Create new file**. In the name box type exactly `.github/workflows/build-apk.yml`
   (typing the slashes makes the folders). Paste the workflow text from `.github/workflows/build-apk.yml` (also shown in the chat). **Commit changes**.
6. Set your backend address: repo **Settings > Secrets and variables > Actions > Variables tab > New repository variable**.
   Name `API_BASE_URL`, value e.g. `https://api.yourdomain.in` (https only; no trailing path needed). This is NOT a secret and ends up inside the APK; never put passwords or API secrets in it.
7. **Actions** tab > **Build GaonCart APK** > **Run workflow** > **Run workflow**. Wait about 10-20 minutes for the first run.
8. Open the finished run. Scroll to **Artifacts**: `gaoncart-debug-apk`, `gaoncart-release-apk`, `build-logs`. Tap one to download (a ZIP).
   If any step is red, download `build-logs` and send it to me.
9. Open the downloaded ZIP in the Files app, extract, tap the `.apk`, allow **Install unknown apps** for your browser/Files app when asked, and install.

## B. From a computer with git
```
unzip gaoncart-github-ready.zip -d gaoncart && cd gaoncart
git init -b main && git add -A && git commit -m "GaonCart"
git remote add origin https://github.com/<you>/gaoncart.git && git push -u origin main
```
then do step 6 and 7 above.

## Notes
- Release APK is signed with a debug key: fine for testing, NOT accepted by Play Store. For Play you need your own keystore + `flutter build appbundle`.
- The app needs your **backend deployed on a public https address** (the zip includes the backend). `localhost` or http addresses will not work on a phone.
- Private repos get 2,000 free Actions minutes/month; a build uses roughly 10-20.
- Never commit `.env` files, keystores, Razorpay or SMS keys. They belong on the server only.

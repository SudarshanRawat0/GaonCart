// End-to-end tests against the real HTTP server and a real SQLite database file.
// Only EXTERNAL network services are replaced by test doubles at the HTTP-transport layer (Razorpay REST API, SMS provider).
// All signature verification, state machines, money math and DB logic run for real.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'gc-'));
process.env.JWT_SECRET = 'j'.repeat(48); process.env.DATA_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex'); process.env.NODE_ENV = 'test';
const { config } = await import('../src/config.js');
const { createApp } = await import('../src/app.js');
const { openDb, uid } = await import('../src/db.js');
const { hashPassword, hmacHex } = await import('../src/lib/security.js');

const KEY_SECRET = 'test_key_secret', WH_SECRET = 'test_wh_secret';
const cfg = { ...config, dbPath: path.join(tmp, 'db.sqlite'), uploadDir: path.join(tmp, 'up'), privateUploadDir: path.join(tmp, 'priv'), backupDir: path.join(tmp, 'bk'), razorpay: { keyId: 'rzp_test_x', keySecret: KEY_SECRET, webhookSecret: WH_SECRET } };

// ---- doubles for external services (transport level only) ----
const gw = { orders: [], payments: new Map(), refunds: [] };
const fetchImpl = async (url, opts = {}) => {
  const u = new URL(url), body = opts.body ? JSON.parse(opts.body) : {}, J = (o, s = 200) => new Response(JSON.stringify(o), { status: s });
  if (u.pathname === '/v1/orders' && opts.method === 'POST') { const o = { id: 'order_' + gw.orders.length + crypto.randomBytes(3).toString('hex'), amount: body.amount, receipt: body.receipt }; gw.orders.push(o); return J(o); }
  const m = u.pathname.match(/^\/v1\/payments\/([^/]+)(\/refund)?$/);
  if (m && m[2]) { const rf = { id: 'rfnd_' + crypto.randomBytes(4).toString('hex'), amount: body.amount, status: 'processed', payment: m[1] }; gw.refunds.push(rf); return J(rf); }
  if (m) { const p = gw.payments.get(m[1]); return p ? J(p) : J({ error: { description: 'not found' } }, 404); }
  return J({ error: { description: 'unexpected ' + url } }, 500);
};
const smsCodes = {};
const sms = { async sendOtp(mobile, code) { smsCodes[mobile] = code; } };

const app = createApp({ cfg, fetchImpl, sms });
await new Promise(r => app.server.listen(0, r));
const base = `http://127.0.0.1:${app.server.address().port}`;
const { db, A } = app;
after(async () => { await app.close(); });

async function api(method, p, { token, body, headers = {}, raw } = {}) {
  const res = await fetch(base + p, { method, headers: { ...(raw ? {} : { 'Content-Type': 'application/json' }), ...(token ? { Authorization: 'Bearer ' + token } : {}), ...headers }, body: raw ?? (body ? JSON.stringify(body) : undefined) });
  const text = await res.text(); let json; try { json = text ? JSON.parse(text) : null; } catch { json = text; }
  return { status: res.status, body: json };
}
const ok = async (...a) => { const r = await api(...a); assert.ok(r.status < 300, `${a[0]} ${a[1]} -> ${r.status} ${JSON.stringify(r.body)}`); return r.body; };
async function login(role, mobile, name) {
  await ok('POST', '/v1/auth/otp/request', { body: { mobile, role } });
  const r = await ok('POST', '/v1/auth/otp/verify', { body: { mobile, role, code: smsCodes[mobile], name } });
  return { token: r.access_token, refresh: r.refresh_token, id: r.user.id };
}
const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), crypto.randomBytes(64)]);
const S = {}; // shared state

before(async () => {
  const id = uid();
  db.run("INSERT INTO users(id,role,email,password_hash,name) VALUES (?,'admin','boss@gaoncart.test',?,'Boss')", id, await hashPassword('correct horse battery'));
  db.run("INSERT INTO admins(user_id,level) VALUES (?,'super')", id);
});

test('admin login: wrong password rejected, right password works, RBAC blocks other roles', async () => {
  assert.equal((await api('POST', '/v1/auth/admin/login', { body: { email: 'boss@gaoncart.test', password: 'wrong wrong wrong' } })).status, 401);
  const r = await ok('POST', '/v1/auth/admin/login', { body: { email: 'boss@gaoncart.test', password: 'correct horse battery' } });
  S.admin = r.access_token; assert.equal(r.admin_level, 'super');
  S.seller = await login('seller', '9000000001', 'Ramesh');
  S.cust = await login('customer', '9000000002', 'Sita');
  assert.equal((await api('GET', '/v1/admin/dashboard', { token: S.cust.token })).status, 403);
  assert.equal((await api('GET', '/v1/seller/shop', { token: S.cust.token })).status, 403);
  assert.equal((await api('GET', '/v1/customer/cart')).status, 401);
  assert.equal((await api('POST', '/v1/admin/categories', { token: S.seller.token, body: {} })).status, 403);
});

test('OTP: lockout after 5 wrong attempts, cooldown enforced', async () => {
  await ok('POST', '/v1/auth/otp/request', { body: { mobile: '9111111111', role: 'customer' } });
  assert.equal((await api('POST', '/v1/auth/otp/request', { body: { mobile: '9111111111', role: 'customer' } })).status, 429);
  for (let i = 0; i < 5; i++) assert.equal((await api('POST', '/v1/auth/otp/verify', { body: { mobile: '9111111111', role: 'customer', code: '000000' } })).status, 401);
  assert.equal((await api('POST', '/v1/auth/otp/verify', { body: { mobile: '9111111111', role: 'customer', code: smsCodes['9111111111'] } })).status, 429);
  assert.equal((await api('POST', '/v1/auth/otp/verify', { body: { mobile: '123', role: 'customer', code: '1' } })).status, 422);
});

test('refresh token rotation + reuse detection', async () => {
  const a = await ok('POST', '/v1/auth/refresh', { body: { refresh_token: S.cust.refresh } });
  assert.notEqual(a.refresh_token, S.cust.refresh);
  assert.equal((await api('POST', '/v1/auth/refresh', { body: { refresh_token: S.cust.refresh } })).status, 401); // reuse
  assert.equal((await api('POST', '/v1/auth/refresh', { body: { refresh_token: a.refresh_token } })).status, 401); // family revoked
  S.cust.refresh = null; // access token still valid until expiry
});

test('seller registers shop; shop is invisible until approved, online, and stocked', async () => {
  const cat = await ok('POST', '/v1/admin/categories', { token: S.admin, body: { name: 'Grocery', slug: 'grocery', kind: 'shop' } });
  S.cat = cat.id;
  const shop = await ok('POST', '/v1/seller/shop', { token: S.seller.token, body: { name: 'Ramesh Kirana', address: 'Main Bazaar, Rampur', village: 'Rampur', pincode: '110001', lat: 28.6139, lng: 77.2090, category_ids: [S.cat] } });
  S.shop = shop.id; assert.equal(shop.approval_status, 'pending');
  assert.equal((await api('POST', '/v1/seller/shop/status', { token: S.seller.token, body: { is_online: true } })).status, 409); // not approved
  await ok('POST', `/v1/admin/shops/${S.shop}/approve`, { token: S.admin });
  assert.equal((await api('POST', '/v1/seller/shop/status', { token: S.seller.token, body: { is_online: true } })).status, 409); // no products
  const p1 = await ok('POST', '/v1/seller/products', { token: S.seller.token, body: { name: 'Basmati Rice 1kg', price_paise: 12000, stock_qty: 10 } });
  const p2 = await ok('POST', '/v1/seller/products', { token: S.seller.token, body: { name: 'Sold Out Biscuits', price_paise: 3000, stock_qty: 0 } });
  S.p1 = p1.id; S.p2 = p2.id;
  await ok('POST', '/v1/seller/shop/status', { token: S.seller.token, body: { is_online: true } });
  S.addr = (await ok('POST', '/v1/customer/addresses', { token: S.cust.token, body: { recipient_name: 'Sita', phone: '9000000002', line1: 'House 4, Rampur', village: 'Rampur', pincode: '110001', lat: 28.6200, lng: 77.2100 } })).id;
  const q = '?lat=28.62&lng=77.21';
  let l = await ok('GET', '/v1/customer/shops' + q, { token: S.cust.token }); assert.equal(l.items.length, 1); assert.ok(l.items[0].distance_km < 2);
  // far-away customer sees nothing
  l = await ok('GET', '/v1/customer/shops?lat=19.07&lng=72.87', { token: S.cust.token }); assert.equal(l.items.length, 0);
  // offline => hidden
  await ok('POST', '/v1/seller/shop/status', { token: S.seller.token, body: { is_online: false } });
  l = await ok('GET', '/v1/customer/shops' + q, { token: S.cust.token }); assert.equal(l.items.length, 0);
  await ok('POST', '/v1/seller/shop/status', { token: S.seller.token, body: { is_online: true } });
  // outside opening hours => hidden automatically
  const now = A.domain.nowMin();
  await ok('PATCH', '/v1/seller/shop', { token: S.seller.token, body: { opens_min: (now + 120) % 1440, closes_min: (now + 180) % 1440 } });
  l = await ok('GET', '/v1/customer/shops' + q, { token: S.cust.token }); assert.equal(l.items.length, 0);
  await ok('PATCH', '/v1/seller/shop', { token: S.seller.token, body: { opens_min: (now + 1430) % 1440, closes_min: (now + 10) % 1440 } }); // open now (wraps midnight if needed)
  l = await ok('GET', '/v1/customer/shops' + q, { token: S.cust.token }); assert.equal(l.items.length, 1);
  // all products out of stock => shop disappears automatically
  await ok('PATCH', `/v1/seller/products/${S.p1}/stock`, { token: S.seller.token, body: { stock_qty: 0 } });
  l = await ok('GET', '/v1/customer/shops' + q, { token: S.cust.token }); assert.equal(l.items.length, 0);
  await ok('PATCH', `/v1/seller/products/${S.p1}/stock`, { token: S.seller.token, body: { stock_qty: 10 } });
  l = await ok('GET', '/v1/customer/shops' + q, { token: S.cust.token }); assert.equal(l.items.length, 1);
  const search = await ok('GET', '/v1/customer/search?q=rice&lat=28.62&lng=77.21', { token: S.cust.token }); assert.equal(search.products.length, 1);
});

test('cart: out-of-stock not purchasable, single-shop rule, quantities', async () => {
  const r = await api('PUT', '/v1/customer/cart/items', { token: S.cust.token, body: { product_id: S.p2, qty: 1 } });
  assert.equal(r.status, 409); assert.equal(r.body.error.code, 'out_of_stock');
  assert.equal((await api('PUT', '/v1/customer/cart/items', { token: S.cust.token, body: { product_id: S.p1, qty: 11 } })).status, 409);
  const c = await ok('PUT', '/v1/customer/cart/items', { token: S.cust.token, body: { product_id: S.p1, qty: 2 } });
  assert.equal(c.subtotal_paise, 24000); assert.equal(c.delivery_fee_paise, 2000);
  const c2 = await ok('PUT', '/v1/customer/cart/items', { token: S.cust.token, body: { product_id: S.p1, qty: 0 } });
  assert.equal(c2.items.length, 0);
  await ok('PUT', '/v1/customer/cart/items', { token: S.cust.token, body: { product_id: S.p1, qty: 2 } });
});

test('COD order: full lifecycle placed -> delivered with ₹20 / ₹5 / ₹15 split recorded in the ledger', async () => {
  const quote = await ok('POST', '/v1/customer/checkout/quote', { token: S.cust.token, body: { address_id: S.addr } });
  assert.equal(quote.total_paise, 26000);
  const hdr = { 'Idempotency-Key': 'k-1' };
  const o = await ok('POST', '/v1/customer/orders', { token: S.cust.token, body: { address_id: S.addr, payment_method: 'cod' }, headers: hdr });
  S.o1 = o.id; assert.equal(o.status, 'placed');
  const again = await api('POST', '/v1/customer/orders', { token: S.cust.token, body: { address_id: S.addr, payment_method: 'cod' }, headers: hdr });
  assert.equal(again.status, 200); assert.equal(again.body.id, o.id); // idempotent replay, no duplicate order
  assert.equal(db.get('SELECT stock_qty s FROM products WHERE id=?', S.p1).s, 8);
  assert.equal((await ok('GET', '/v1/customer/cart', { token: S.cust.token })).items.length, 0);
  // seller sees order + customer info
  const so = await ok('GET', '/v1/seller/orders?group=active', { token: S.seller.token });
  assert.equal(so.items.length, 1); assert.equal(so.items[0].address.phone, '9000000002');
  // invalid transitions blocked
  assert.equal((await api('POST', `/v1/seller/orders/${S.o1}/ready`, { token: S.seller.token })).status, 409);
  assert.equal((await api('POST', `/v1/seller/orders/${S.o1}/accept`, { token: S.cust.token })).status, 403);
  await ok('POST', `/v1/seller/orders/${S.o1}/accept`, { token: S.seller.token });
  await ok('POST', `/v1/seller/orders/${S.o1}/preparing`, { token: S.seller.token });
  await ok('POST', `/v1/seller/orders/${S.o1}/ready`, { token: S.seller.token });

  // partners: registration, documents, admin verification
  S.d1 = await login('delivery', '9000000003', 'Mohan'); S.d2 = await login('delivery', '9000000004', 'Karan');
  for (const d of [S.d1, S.d2]) {
    await ok('PUT', '/v1/delivery/profile', { token: d.token, body: { vehicle_type: 'bike', vehicle_number: 'UP32AB1234' } });
    assert.equal((await api('POST', '/v1/delivery/status', { token: d.token, body: { is_online: true } })).status, 403); // unverified
    assert.equal((await api('POST', '/v1/uploads?kind=partner_doc', { token: d.token, raw: Buffer.from('not an image at all, really not'), headers: { 'Content-Type': 'image/png' } })).status, 400);
    const up = await ok('POST', '/v1/uploads?kind=partner_doc', { token: d.token, raw: png, headers: { 'Content-Type': 'image/png' } });
    await ok('POST', '/v1/delivery/documents', { token: d.token, body: { doc_type: 'driving_licence', file_key: up.file_key, doc_number: 'DL1234567890' } });
    assert.equal((await api('GET', `/v1/admin/partners/${d.id}/documents/x/file`, { token: d.token })).status, 403); // docs are admin only
    const detail = await ok('GET', `/v1/admin/partners/${d.id}`, { token: S.admin }); assert.match(detail.documents[0].doc_number_masked, /7890$/);
    await ok('POST', `/v1/admin/partners/${d.id}/verify`, { token: S.admin });
    await ok('POST', '/v1/delivery/status', { token: d.token, body: { is_online: true } });
    await ok('POST', '/v1/delivery/location', { token: d.token, body: { lat: 28.615, lng: 77.211, accuracy_m: 8 } });
  }
  const reqs = await ok('GET', '/v1/delivery/requests', { token: S.d1.token });
  assert.equal(reqs.items.length, 1); assert.equal(reqs.items[0].earning_paise, 1500); assert.equal(reqs.items[0].collect_cash_paise, 26000);
  // race: both partners accept at once -> exactly one wins
  const [a, b] = await Promise.all([api('POST', `/v1/delivery/orders/${S.o1}/accept`, { token: S.d1.token }), api('POST', `/v1/delivery/orders/${S.o1}/accept`, { token: S.d2.token })]);
  assert.deepEqual([a.status, b.status].sort(), [200, 409]);
  const win = a.status === 200 ? S.d1 : S.d2, lose = a.status === 200 ? S.d2 : S.d1;
  assert.equal((await api('POST', `/v1/delivery/orders/${S.o1}/pickup`, { token: lose.token })).status, 404);
  // live tracking uses the GPS points the partner posts
  await ok('POST', '/v1/delivery/location', { token: win.token, body: { lat: 28.616, lng: 77.2105, speed_mps: 6, heading: 90 } });
  const tr = await ok('GET', `/v1/customer/orders/${S.o1}/tracking`, { token: S.cust.token });
  assert.equal(tr.live, true); assert.equal(tr.partner_location.lat, 28.616);
  const other = await login('customer', '9000000005', 'Gita');
  assert.equal((await api('GET', `/v1/customer/orders/${S.o1}/tracking`, { token: other.token })).status, 404); // no IDOR
  assert.equal((await api('GET', `/v1/customer/orders/${S.o1}`, { token: other.token })).status, 404);
  await ok('POST', `/v1/delivery/orders/${S.o1}/pickup`, { token: win.token });
  assert.equal((await api('POST', `/v1/delivery/orders/${S.o1}/deliver`, { token: win.token, body: { code: '0000' } })).status, 400); // must be out_for_delivery & right code
  await ok('POST', `/v1/delivery/orders/${S.o1}/out-for-delivery`, { token: win.token });
  const cv = await ok('GET', `/v1/customer/orders/${S.o1}`, { token: S.cust.token });
  assert.match(cv.delivery_code, /^\d{4}$/); assert.equal(cv.partner.name, win === S.d1 ? 'Mohan' : 'Karan');
  const wrong = cv.delivery_code === '1234' ? '4321' : '1234';
  assert.equal((await api('POST', `/v1/delivery/orders/${S.o1}/deliver`, { token: win.token, body: { code: wrong } })).status, 400);
  assert.equal((await api('POST', `/v1/delivery/orders/${S.o1}/deliver`, { token: lose.token, body: { code: cv.delivery_code } })).status, 404);
  const done = await ok('POST', `/v1/delivery/orders/${S.o1}/deliver`, { token: win.token, body: { code: cv.delivery_code } });
  assert.equal(done.status, 'delivered'); S.win = win;
  assert.equal((await api('POST', `/v1/delivery/orders/${S.o1}/deliver`, { token: win.token, body: { code: cv.delivery_code } })).status, 409); // cannot deliver twice
  // money
  const com = db.get('SELECT * FROM commissions WHERE order_id=?', S.o1);
  assert.equal(com.partner_earning_paise, 1500); assert.equal(com.delivery_commission_paise, 500); assert.equal(com.seller_earning_paise, 24000);
  const led = Object.fromEntries(db.all("SELECT payee_type||':'||kind k, amount_paise a FROM transactions WHERE order_id=?", S.o1).map(r => [r.k, r.a]));
  assert.deepEqual(led, { 'seller:order_earning': 24000, 'partner:delivery_earning': 1500, 'platform:delivery_commission': 500, 'partner:cod_cash_held': -26000 });
  assert.equal(db.get('SELECT payment_status s FROM orders WHERE id=?', S.o1).s, 'paid');
  const earn = await ok('GET', '/v1/delivery/earnings', { token: win.token });
  assert.equal(earn.today_paise, 1500); assert.equal(earn.total_paise, 1500); assert.equal(earn.cash_to_remit_paise, 26000);
  // review
  await ok('POST', `/v1/customer/orders/${S.o1}/review`, { token: S.cust.token, body: { shop_rating: 4, comment: 'Quick' } });
  assert.equal((await api('POST', `/v1/customer/orders/${S.o1}/review`, { token: S.cust.token, body: { shop_rating: 5 } })).status, 409);
  const rep = await ok('GET', '/v1/seller/reports/sales', { token: S.seller.token }); assert.equal(rep.totals.orders, 1); assert.equal(rep.totals.net_paise, 24000);
});

test('notifications were stored for every party', async () => {
  const types = u => db.all('SELECT title FROM notifications WHERE user_id=?', u).map(n => n.title);
  const c = types(S.cust.id); for (const t of ['Order placed', 'Order accepted', 'Preparing your order', 'Order is ready', 'Delivery partner assigned', 'Order picked up', 'Out for delivery', 'Order delivered']) assert.ok(c.includes(t), 'customer missing ' + t);
  assert.ok(types(S.seller.id).includes('New order'));
  assert.ok(types(S.win.id).some(t => t === 'Delivery completed'));
  const list = await ok('GET', '/v1/notifications?unread=1', { token: S.cust.token }); assert.ok(list.unread_count >= 8);
});

test('online payment: signature + gateway verification, duplicates, failure, refund on cancel', async () => {
  await ok('PUT', '/v1/customer/cart/items', { token: S.cust.token, body: { product_id: S.p1, qty: 1 } });
  const o = await ok('POST', '/v1/customer/orders', { token: S.cust.token, body: { address_id: S.addr, payment_method: 'online' } });
  assert.equal(o.status, 'pending_payment'); assert.ok(o.payment.gateway_order_id); assert.equal(o.payment.amount_paise, 14000);
  assert.equal((await ok('GET', '/v1/seller/orders', { token: S.seller.token })).items.filter(x => x.id === o.id).length, 0); // seller does not see unpaid orders
  const go = o.payment.gateway_order_id, pid = 'pay_abc123';
  const verify = (sig, payId = pid) => api('POST', '/v1/customer/payments/verify', { token: S.cust.token, body: { order_id: o.id, razorpay_order_id: go, razorpay_payment_id: payId, razorpay_signature: sig } });
  assert.equal((await verify('deadbeef')).status, 400); // forged signature
  assert.equal(db.get('SELECT status s FROM orders WHERE id=?', o.id).s, 'pending_payment');
  const goodSig = hmacHex(KEY_SECRET, `${go}|${pid}`);
  assert.equal((await api('POST', '/v1/customer/payments/verify', { token: S.cust.token, body: { order_id: o.id, razorpay_order_id: go, razorpay_payment_id: pid, razorpay_signature: goodSig } })).status, 502); // gateway has no such payment -> never marked paid
  assert.equal(db.get('SELECT payment_status s FROM orders WHERE id=?', o.id).s, 'unpaid');
  gw.payments.set(pid, { id: pid, order_id: go, amount: 14000, currency: 'INR', status: 'created' });
  assert.equal((await verify(goodSig)).status, 409); // not captured => not paid
  gw.payments.set(pid, { id: pid, order_id: go, amount: 9999, currency: 'INR', status: 'captured' });
  assert.equal((await verify(goodSig)).status, 400); // amount mismatch
  gw.payments.set(pid, { id: pid, order_id: go, amount: 14000, currency: 'INR', status: 'captured' });
  const r = await ok('POST', '/v1/customer/payments/verify', { token: S.cust.token, body: { order_id: o.id, razorpay_order_id: go, razorpay_payment_id: pid, razorpay_signature: goodSig } });
  assert.equal(r.status, 'paid'); assert.equal(r.order.status, 'placed'); assert.equal(r.order.payment_status, 'paid');
  await ok('POST', '/v1/customer/payments/verify', { token: S.cust.token, body: { order_id: o.id, razorpay_order_id: go, razorpay_payment_id: pid, razorpay_signature: goodSig } }); // duplicate is idempotent
  assert.equal(db.get('SELECT COUNT(*) c FROM payments WHERE order_id=? AND status=\'paid\'', o.id).c, 1);
  // webhook authenticity + dedupe
  const body = JSON.stringify({ event: 'payment.captured', payload: { payment: { entity: { id: pid, order_id: go, amount: 14000 } } } });
  assert.equal((await api('POST', '/v1/webhooks/razorpay', { raw: body, headers: { 'x-razorpay-signature': 'bad', 'x-razorpay-event-id': 'e1' } })).status, 401);
  const wsig = hmacHex(WH_SECRET, body);
  assert.equal((await api('POST', '/v1/webhooks/razorpay', { raw: body, headers: { 'x-razorpay-signature': wsig, 'x-razorpay-event-id': 'e1' } })).status, 200);
  assert.equal((await api('POST', '/v1/webhooks/razorpay', { raw: body, headers: { 'x-razorpay-signature': wsig, 'x-razorpay-event-id': 'e1' } })).body.duplicate, true);
  // customer cancels a paid order -> automatic refund through the gateway
  const c = await ok('POST', `/v1/customer/orders/${o.id}/cancel`, { token: S.cust.token, body: { reason: 'changed mind' } });
  assert.equal(c.status, 'cancelled');
  const ref = db.get('SELECT * FROM refunds WHERE order_id=?', o.id);
  assert.equal(ref.amount_paise, 14000); assert.equal(ref.status, 'processed'); assert.equal(gw.refunds.length, 1);
  assert.equal(db.get('SELECT payment_status s FROM orders WHERE id=?', o.id).s, 'refunded');
  assert.equal(db.get('SELECT stock_qty s FROM products WHERE id=?', S.p1).s, 8); // stock restored
  assert.equal((await api('POST', '/v1/admin/refunds', { token: S.admin, body: { order_id: o.id, amount_paise: 100, reason: 'x' } })).status, 409); // cannot refund more than paid
});

test('abandoned online payment expires and restores stock; late capture is auto-refunded; webhook amount mismatch ignored', async () => {
  await ok('PUT', '/v1/customer/cart/items', { token: S.cust.token, body: { product_id: S.p1, qty: 1 } });
  const o = await ok('POST', '/v1/customer/orders', { token: S.cust.token, body: { address_id: S.addr, payment_method: 'online' } });
  assert.equal(db.get('SELECT stock_qty s FROM products WHERE id=?', S.p1).s, 7);
  db.run("UPDATE orders SET created_at=datetime('now','-1 hour') WHERE id=?", o.id);
  assert.equal(await A.domain.expirePendingPayments(), 1);
  assert.equal(db.get('SELECT status s FROM orders WHERE id=?', o.id).s, 'cancelled'); assert.equal(db.get('SELECT stock_qty s FROM products WHERE id=?', S.p1).s, 8);
  const go = o.payment.gateway_order_id, hook = async (payload, id) => { const b = JSON.stringify(payload); return api('POST', '/v1/webhooks/razorpay', { raw: b, headers: { 'x-razorpay-signature': hmacHex(WH_SECRET, b), 'x-razorpay-event-id': id } }); };
  await hook({ event: 'payment.captured', payload: { payment: { entity: { id: 'pay_wrong', order_id: go, amount: 1 } } } }, 'e2');
  assert.equal(db.get("SELECT status s FROM payments WHERE order_id=?", o.id).s, 'failed'); // mismatch never marks paid
  await hook({ event: 'payment.captured', payload: { payment: { entity: { id: 'pay_late', order_id: go, amount: 14000 } } } }, 'e3');
  // payment row was already failed (order cancelled) -> still must not silently keep money: late capture on a closed order refunds
  const p = db.get('SELECT * FROM payments WHERE order_id=?', o.id);
  assert.ok(p.status === 'refunded' || db.get('SELECT * FROM refunds WHERE order_id=?', o.id), 'late capture must be refunded');
});

test('stock oversell protection: two customers race for the last unit', async () => {
  const p = await ok('POST', '/v1/seller/products', { token: S.seller.token, body: { name: 'Last Mango', price_paise: 5000, stock_qty: 1 } });
  const c2 = await login('customer', '9000000006', 'Raju'), c3 = await login('customer', '9000000007', 'Mina');
  const addr = async c => (await ok('POST', '/v1/customer/addresses', { token: c.token, body: { recipient_name: 'X', phone: '9000000006', line1: 'Lane 1', lat: 28.62, lng: 77.21 } })).id;
  const [a2, a3] = [await addr(c2), await addr(c3)];
  await ok('PUT', '/v1/customer/cart/items', { token: c2.token, body: { product_id: p.id, qty: 1 } }); await ok('PUT', '/v1/customer/cart/items', { token: c3.token, body: { product_id: p.id, qty: 1 } });
  const rs = await Promise.all([api('POST', '/v1/customer/orders', { token: c2.token, body: { address_id: a2, payment_method: 'cod' } }), api('POST', '/v1/customer/orders', { token: c3.token, body: { address_id: a3, payment_method: 'cod' } })]);
  assert.deepEqual(rs.map(r => r.status).sort(), [201, 409]); assert.equal(db.get('SELECT stock_qty s FROM products WHERE id=?', p.id).s, 0);
});

test('seller rejects / cancellation policy / out-of-range delivery', async () => {
  await ok('PUT', '/v1/customer/cart/items', { token: S.cust.token, body: { product_id: S.p1, qty: 1 } });
  const far = (await ok('POST', '/v1/customer/addresses', { token: S.cust.token, body: { recipient_name: 'Sita', phone: '9000000002', line1: 'Far away', lat: 28.9, lng: 77.6 } })).id;
  assert.equal((await api('POST', '/v1/customer/orders', { token: S.cust.token, body: { address_id: far, payment_method: 'cod' } })).body.error.code, 'out_of_range');
  const o = await ok('POST', '/v1/customer/orders', { token: S.cust.token, body: { address_id: S.addr, payment_method: 'cod' } });
  await ok('POST', `/v1/seller/orders/${o.id}/reject`, { token: S.seller.token, body: { reason: 'Out of cooking gas' } });
  assert.equal(db.get('SELECT status s FROM orders WHERE id=?', o.id).s, 'rejected'); assert.equal(db.get('SELECT stock_qty s FROM products WHERE id=?', S.p1).s, 8);
  await ok('PUT', '/v1/customer/cart/items', { token: S.cust.token, body: { product_id: S.p1, qty: 1 } });
  const o2 = await ok('POST', '/v1/customer/orders', { token: S.cust.token, body: { address_id: S.addr, payment_method: 'cod' } });
  await ok('POST', `/v1/seller/orders/${o2.id}/accept`, { token: S.seller.token }); await ok('POST', `/v1/seller/orders/${o2.id}/preparing`, { token: S.seller.token });
  const r = await api('POST', `/v1/customer/orders/${o2.id}/cancel`, { token: S.cust.token, body: {} }); assert.equal(r.status, 409); // too late once preparing
  const re = await ok('POST', `/v1/customer/orders/${S.o1}/reorder`, { token: S.cust.token }); assert.equal(re.added.length, 1);
});

test('account suspension is immediate; deletion blocked by active orders; online payment refuses when gateway unconfigured', async () => {
  const x = await login('customer', '9000000008', 'Temp');
  assert.equal((await api('GET', '/v1/me', { token: x.token })).status, 200);
  await ok('POST', `/v1/admin/users/${x.id}/status`, { token: S.admin, body: { status: 'blocked', reason: 'fraud' } });
  assert.equal((await api('GET', '/v1/me', { token: x.token })).status, 401);
  assert.equal((await api('POST', '/v1/auth/otp/request', { body: { mobile: '9000000008', role: 'customer' } })).status, 403);
  assert.equal((await api('DELETE', '/v1/me', { token: S.cust.token })).status, 409); // has active order
  const y = await login('customer', '9000000009', 'Del');
  assert.equal((await api('DELETE', '/v1/me', { token: y.token })).status, 204);
  assert.equal(db.get('SELECT mobile m, status s FROM users WHERE id=?', y.id).m, null);
  assert.equal((await api('GET', '/v1/me', { token: y.token })).status, 401);
});

test('settlements: generate, pay, ledger nets to zero for settled payees', async () => {
  const gen = await ok('POST', '/v1/admin/settlements/generate', { token: S.admin, body: { payee_type: 'seller' } });
  assert.equal(gen.created.length, 1); assert.equal(gen.created[0].amount_paise, 24000);
  const gp = await ok('POST', '/v1/admin/settlements/generate', { token: S.admin, body: { payee_type: 'partner' } });
  assert.equal(gp.created[0].amount_paise, 1500 - 26000); // partner owes platform the COD cash minus their earning
  assert.equal((await ok('POST', '/v1/admin/settlements/generate', { token: S.admin, body: { payee_type: 'seller' } })).created.length, 0);
  await ok('POST', `/v1/admin/settlements/${gen.created[0].id}/mark-paid`, { token: S.admin, body: { reference: 'UTR123456' } });
  assert.equal((await api('POST', `/v1/admin/settlements/${gen.created[0].id}/mark-paid`, { token: S.admin, body: { reference: 'again' } })).status, 409);
  const pay = await ok('GET', '/v1/seller/reports/payments', { token: S.seller.token }); assert.equal(pay.items[0].status, 'paid');
  const dash = await ok('GET', '/v1/admin/dashboard', { token: S.admin }); assert.equal(dash.platform_revenue_paise, 500);
  const rev = await ok('GET', '/v1/admin/revenue', { token: S.admin }); assert.equal(rev.total_paise, 500);
});

test('validation, uploads and security headers', async () => {
  const r = await api('POST', '/v1/seller/products', { token: S.seller.token, body: { name: '', price_paise: -5, stock_qty: 1.5 } });
  assert.equal(r.status, 422); assert.ok(r.body.error.details.price_paise);
  assert.equal((await api('POST', '/v1/uploads?kind=product', { token: S.seller.token, raw: Buffer.from('<script>alert(1)</script>'.repeat(5)), headers: { 'Content-Type': 'image/png' } })).status, 400);
  const up = await ok('POST', '/v1/uploads?kind=product', { token: S.seller.token, raw: png, headers: { 'Content-Type': 'image/png' } });
  const img = await fetch(base + up.url); assert.equal(img.status, 200); assert.equal(img.headers.get('x-content-type-options'), 'nosniff');
  assert.equal((await fetch(base + '/uploads/../../etc/passwd')).status, 404);
  assert.equal((await api('POST', '/v1/uploads?kind=product', { token: S.cust.token, raw: png })).status, 403);
  const h = await fetch(base + '/healthz'); assert.equal(h.headers.get('x-frame-options'), 'DENY');
  assert.equal((await api('POST', '/v1/customer/addresses', { token: S.cust.token, body: { recipient_name: 'x', phone: '12', line1: 'y', lat: 999, lng: 0 } })).status, 422);
  const bad = await fetch(base + '/v1/auth/otp/request', { method: 'POST', body: '{nope', headers: { 'Content-Type': 'application/json' } }); assert.equal(bad.status, 400);
  assert.equal(JSON.stringify(await (await fetch(base + '/v1/me')).json()).includes('stack'), false);
});

test('SSE: devices receive order updates in real time', async () => {
  const ctrl = new AbortController();
  const res = await fetch(base + '/v1/stream', { headers: { Authorization: 'Bearer ' + S.cust.token }, signal: ctrl.signal });
  assert.equal(res.status, 200);
  const reader = res.body.getReader(); const dec = new TextDecoder(); let buf = '';
  const readUntil = async (needle) => { while (!buf.includes(needle)) { const { value, done } = await reader.read(); if (done) break; buf += dec.decode(value); } return buf.includes(needle); };
  assert.ok(await readUntil('event: ready'));
  await ok('PUT', '/v1/customer/cart/items', { token: S.cust.token, body: { product_id: S.p1, qty: 1 } });
  const o = await ok('POST', '/v1/customer/orders', { token: S.cust.token, body: { address_id: S.addr, payment_method: 'cod' } });
  assert.ok(await readUntil('event: order_update')); assert.ok(buf.includes(o.id));
  ctrl.abort();
});

test('banners: admin creates, public list shows only active ones, non-admin refused', async () => {
  const up = await ok('POST', '/v1/uploads?kind=profile', { token: S.admin, raw: png, headers: { 'Content-Type': 'image/png' } });
  assert.equal((await api('POST', '/v1/admin/banners', { token: S.seller.token, body: { title: 'x', image_url: up.url } })).status, 403);
  assert.equal((await api('POST', '/v1/admin/banners', { token: S.admin, body: { title: 'x', image_url: 'https://evil.example/a.png' } })).status, 422);
  const b = await ok('POST', '/v1/admin/banners', { token: S.admin, body: { title: 'Diwali Offers', image_url: up.url } });
  await ok('POST', '/v1/admin/banners', { token: S.admin, body: { title: 'Expired', image_url: up.url, ends_at: '2020-01-01T00:00:00Z' } });
  const l = await ok('GET', '/v1/banners'); assert.deepEqual(l.items.map(x => x.title), ['Diwali Offers']);
  await ok('DELETE', `/v1/admin/banners/${b.id}`, { token: S.admin }); assert.equal((await ok('GET', '/v1/banners')).items.length, 0);
});

test('response shapes the Flutter app depends on are present (guards against accidental API drift)', async () => {
  const has = (o, keys, what) => { for (const k of keys) assert.ok(k in o, `${what} is missing "${k}"`); };
  const shops = await ok('GET', '/v1/customer/shops?lat=28.62&lng=77.21', { token: S.cust.token });
  has(shops.items[0], ['id', 'name', 'description', 'logo_url', 'cover_url', 'address', 'village', 'rating_avg', 'rating_count', 'min_order_paise', 'distance_km', 'eta_min', 'lat', 'lng'], 'shop card');
  const detail = await ok('GET', `/v1/customer/shops/${S.shop}?lat=28.62&lng=77.21`, { token: S.cust.token });
  has(detail, ['categories', 'products'], 'shop detail'); has(detail.products[0], ['id', 'name', 'description', 'image_url', 'price_paise', 'purchasable', 'low_stock'], 'product');
  await ok('PUT', '/v1/customer/cart/items', { token: S.cust.token, body: { product_id: S.p1, qty: 1 } });
  const cart = await ok('GET', '/v1/customer/cart', { token: S.cust.token });
  has(cart, ['shop', 'items', 'subtotal_paise', 'delivery_fee_paise'], 'cart'); has(cart.items[0], ['product_id', 'name', 'image_url', 'price_paise', 'qty', 'available'], 'cart item');
  const q = await ok('POST', '/v1/customer/checkout/quote', { token: S.cust.token, body: { address_id: S.addr } });
  has(q, ['subtotal_paise', 'delivery_fee_paise', 'platform_fee_paise', 'total_paise', 'distance_km', 'online_payment_available', 'cod_available'], 'quote');
  const od = await ok('GET', `/v1/customer/orders/${S.o1}`, { token: S.cust.token });
  has(od, ['number', 'status', 'payment_method', 'payment_status', 'subtotal_paise', 'delivery_fee_paise', 'total_paise', 'address', 'shop', 'items', 'events', 'reviewed', 'partner'], 'order');
  has(od.address, ['name', 'phone', 'line', 'lat', 'lng'], 'order.address'); has(od.shop, ['name', 'address', 'phone', 'lat', 'lng'], 'order.shop'); has(od.partner, ['name', 'phone'], 'order.partner'); has(od.events[0], ['status', 'created_at'], 'event');
  const list = await ok('GET', '/v1/customer/orders', { token: S.cust.token }); has(list.items[0], ['id', 'number', 'status', 'total_paise', 'shop_name', 'shop_logo', 'created_at', 'item_count'], 'order list');
  const so = await ok('GET', '/v1/seller/orders?group=completed', { token: S.seller.token }); has(so.items[0], ['customer', 'address', 'items', 'note', 'status', 'payment_method', 'subtotal_paise'], 'seller order'); has(so.items[0].customer, ['name', 'phone'], 'seller order.customer');
  const sales = await ok('GET', '/v1/seller/reports/sales', { token: S.seller.token }); has(sales.totals, ['orders', 'gross_paise', 'net_paise', 'cancelled_orders'], 'sales totals');
  const earn = await ok('GET', '/v1/seller/reports/earnings', { token: S.seller.token }); has(earn, ['unsettled_paise', 'paid_out_paise', 'entries'], 'seller earnings');
  const de = await ok('GET', '/v1/delivery/earnings', { token: S.win.token }); has(de, ['today_paise', 'today_deliveries', 'total_paise', 'cash_to_remit_paise', 'unsettled_paise', 'paid_out_paise', 'days'], 'delivery earnings');
  const dh = await ok('GET', '/v1/delivery/orders?group=history', { token: S.win.token }); has(dh.items[0], ['number', 'shop', 'address', 'status', 'earning_paise', 'collect_cash_paise'], 'delivery order');
  const dp = await ok('GET', '/v1/delivery/profile', { token: S.win.token }); has(dp, ['name', 'mobile', 'vehicle_type', 'vehicle_number', 'verification_status', 'rejection_reason', 'is_online', 'documents'], 'delivery profile');
  const sh = await ok('GET', '/v1/seller/shop', { token: S.seller.token }); has(sh, ['approval_status', 'is_online', 'categories', 'opens_min', 'closes_min', 'lat', 'lng'], 'seller shop');
});

test('database backup produces a valid, readable snapshot', async () => {
  const r = spawnSync(process.execPath, ['--no-warnings', 'scripts/backup.js'], { env: { ...process.env, DB_PATH: cfg.dbPath, BACKUP_DIR: cfg.backupDir }, encoding: 'utf8' });
  assert.equal(r.status, 0, r.stderr);
  const f = fs.readdirSync(cfg.backupDir)[0]; const b = openDb(path.join(cfg.backupDir, f));
  assert.ok(b.get('SELECT COUNT(*) c FROM orders').c >= 5); assert.equal(b.get('PRAGMA integrity_check').integrity_check, 'ok'); b.close();
});

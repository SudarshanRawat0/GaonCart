# GaonCart Backend (Phase 1 + 2)

Node.js 22 API, **zero npm dependencies** (node:http, node:sqlite, node:crypto). ~100 endpoints for customer, seller, delivery partner and admin.

## Run
```bash
cp .env.example .env   # fill JWT_SECRET (openssl rand -hex 48), DATA_ENCRYPTION_KEY (openssl rand -hex 32), SMS_PROVIDER etc.
npm run migrate
ADMIN_EMAIL=you@domain.in ADMIN_PASSWORD='min-12-chars-passphrase' npm run create-admin
npm start
npm test            # 16 end-to-end tests
npm run backup      # cron: 0 */6 * * *
```

## Folder structure
```
migrations/001_init.sql     full schema (36 tables), forward-only migrations
src/config.js               env config + startup validation (refuses weak secrets)
src/db.js                   SQLite layer, transactions, migration runner, settings
src/app.js                  HTTP server, router wiring, auth guards, security headers, background jobs
src/domain.js               order state machine, stock, payments, refunds, commissions, ledger
src/lib/                    security (scrypt, JWT, AES-GCM), http (router, validation), gateway (Razorpay),
                            sms (MSG91), push (FCM), realtime (SSE), notify
src/routes/                 common (auth, profile, uploads, support), customer, seller, delivery, admin, webhooks
scripts/                    migrate, create-admin, backup
test/e2e.test.js            real-server integration tests
```

## Order lifecycle
`pending_payment`(online only) -> `placed` -> `accepted` -> `preparing` -> `ready_for_pickup` -> `assigned` -> `picked_up` -> `out_for_delivery` -> `delivered`
Side exits: `rejected` (seller, at placed), `cancelled` (customer until accepted; seller until ready; admin any time before delivery).
Every transition is an atomic compare-and-set UPDATE plus an `order_events` row; cancelling restores stock and auto-refunds paid online orders.
Delivery requires the customer's 4-digit code. Partners claim orders with `UPDATE ... WHERE status='ready_for_pickup' AND partner_id IS NULL`, so only one can win.

## Money (paise, integers; settings editable by admin)
Customer delivery fee 2000 = partner commission 500 (platform) + partner earning 1500, snapshotted on the order at checkout.
On delivery the ledger (`transactions`, unique per order/payee/kind) records: seller `order_earning`, partner `delivery_earning` +1500,
platform `delivery_commission` +500, `shop_commission`, `platform_fee`, and for COD partner `cod_cash_held` = -total (cash they must remit).
Admin "generate settlements" nets all unsettled entries per payee; positive = platform pays out, negative = payee remits cash.

## Realtime & tracking
`GET /v1/stream` (SSE, Authorization header) pushes `order_update`, `notification`, `tracking`. Partner app posts real GPS to `POST /v1/delivery/location`; customers read it via SSE or `GET /v1/customer/orders/:id/tracking`.

## External accounts/credentials you must supply (none are faked)
| Need | Env vars | Without it |
|---|---|---|
| SMS OTP (MSG91 + DLT-registered template) | SMS_PROVIDER, MSG91_AUTH_KEY, MSG91_OTP_TEMPLATE_ID | OTP login returns 503 |
| Razorpay (keys + webhook to `/v1/webhooks/razorpay`, events payment.captured/failed, refund.processed/failed) | RAZORPAY_* | online payment returns 503; COD works |
| Firebase Cloud Messaging service account | FCM_SERVICE_ACCOUNT_FILE | notifications saved + delivered over SSE, push marked `not_configured` |
| Server, HTTPS domain, object storage (recommended for uploads) | | |
| Razorpay Route/RazorpayX or bank transfer for payouts | | settlements are recorded; actual payout is manual |

## Known limits (be aware before launch)
- Database is SQLite (WAL) because that is what could be verified offline here. Fine for a single-server launch; move to PostgreSQL before scaling out. SQL is plain; the `db.js` adapter is the only layer to replace.
- SSE hub and rate limiter are in-process; multiple API instances need Redis (or Postgres LISTEN/NOTIFY).
- Uploads are on local disk; use S3/R2 for production.
- Legal pages are placeholders; have a lawyer review (DPDP Act, consumer e-commerce rules, FSSAI/GST obligations).

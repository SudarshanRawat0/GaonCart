-- Promotional banners shown on the customer home screen (managed by admin).
CREATE TABLE banners (
  id TEXT PRIMARY KEY, title TEXT NOT NULL, subtitle TEXT, image_url TEXT NOT NULL,
  shop_id TEXT REFERENCES shops(id), category_id TEXT REFERENCES categories(id),
  sort_order INTEGER NOT NULL DEFAULT 0, is_active INTEGER NOT NULL DEFAULT 1,
  starts_at TEXT, ends_at TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

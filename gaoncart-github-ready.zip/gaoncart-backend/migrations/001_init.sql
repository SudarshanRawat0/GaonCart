-- GaonCart schema v1. All money is INTEGER paise. All ids are UUID text. Timestamps are ISO-8601 UTC text.
CREATE TABLE users (
  id TEXT PRIMARY KEY,
  role TEXT NOT NULL CHECK (role IN ('customer','seller','delivery','admin')),
  mobile TEXT, email TEXT, password_hash TEXT, name TEXT, photo_url TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','blocked','deleted')),
  status_reason TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE (role, mobile), UNIQUE (email)
);
CREATE TABLE refresh_tokens (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE, device TEXT, expires_at TEXT NOT NULL, revoked_at TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_refresh_user ON refresh_tokens(user_id);
CREATE TABLE otp_codes (
  id TEXT PRIMARY KEY, mobile TEXT NOT NULL, role TEXT NOT NULL, code_hash TEXT NOT NULL,
  expires_at TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, consumed_at TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_otp_lookup ON otp_codes(mobile, role, created_at);
CREATE TABLE device_tokens (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token TEXT NOT NULL UNIQUE, platform TEXT NOT NULL CHECK (platform IN ('android','ios','web')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE customers (user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE admins (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  level TEXT NOT NULL CHECK (level IN ('super','finance','support'))
);
CREATE TABLE sellers (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  business_name TEXT, gstin TEXT, fssai_no TEXT, payout_upi_enc TEXT
);
CREATE TABLE delivery_partners (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  vehicle_type TEXT CHECK (vehicle_type IN ('bicycle','bike','scooter','other')),
  vehicle_number TEXT,
  verification_status TEXT NOT NULL DEFAULT 'pending' CHECK (verification_status IN ('pending','verified','rejected')),
  rejection_reason TEXT, is_online INTEGER NOT NULL DEFAULT 0,
  last_lat REAL, last_lng REAL, last_seen_at TEXT, payout_upi_enc TEXT
);
CREATE TABLE partner_documents (
  id TEXT PRIMARY KEY, partner_id TEXT NOT NULL REFERENCES delivery_partners(user_id) ON DELETE CASCADE,
  doc_type TEXT NOT NULL CHECK (doc_type IN ('aadhaar','driving_licence','vehicle_rc','photo','other')),
  doc_number_enc TEXT, file_key TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE addresses (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  label TEXT, recipient_name TEXT NOT NULL, phone TEXT NOT NULL, line1 TEXT NOT NULL,
  landmark TEXT, village TEXT, pincode TEXT, lat REAL NOT NULL, lng REAL NOT NULL,
  is_default INTEGER NOT NULL DEFAULT 0, deleted_at TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE categories (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, slug TEXT NOT NULL UNIQUE, icon_url TEXT,
  kind TEXT NOT NULL DEFAULT 'product' CHECK (kind IN ('shop','product')),
  sort_order INTEGER NOT NULL DEFAULT 0, is_active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE shops (
  id TEXT PRIMARY KEY, seller_id TEXT NOT NULL UNIQUE REFERENCES sellers(user_id),
  name TEXT NOT NULL, description TEXT, logo_url TEXT, cover_url TEXT,
  address TEXT NOT NULL, village TEXT, pincode TEXT, lat REAL NOT NULL, lng REAL NOT NULL,
  phone TEXT, opens_min INTEGER, closes_min INTEGER, min_order_paise INTEGER NOT NULL DEFAULT 0,
  approval_status TEXT NOT NULL DEFAULT 'pending' CHECK (approval_status IN ('pending','approved','rejected','suspended')),
  rejection_reason TEXT, is_online INTEGER NOT NULL DEFAULT 0,
  commission_bps INTEGER, rating_avg REAL NOT NULL DEFAULT 0, rating_count INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_shops_geo ON shops(approval_status, is_online, lat, lng);
CREATE TABLE shop_categories (
  shop_id TEXT NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  category_id TEXT NOT NULL REFERENCES categories(id), PRIMARY KEY (shop_id, category_id)
);
CREATE TABLE products (
  id TEXT PRIMARY KEY, shop_id TEXT NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  category_id TEXT REFERENCES categories(id), name TEXT NOT NULL, description TEXT, image_url TEXT,
  price_paise INTEGER NOT NULL CHECK (price_paise > 0), is_available INTEGER NOT NULL DEFAULT 1,
  stock_qty INTEGER NOT NULL DEFAULT 0 CHECK (stock_qty >= 0), is_blocked INTEGER NOT NULL DEFAULT 0,
  deleted_at TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_products_shop ON products(shop_id, deleted_at, is_available);
CREATE TABLE stock_movements (
  id INTEGER PRIMARY KEY AUTOINCREMENT, product_id TEXT NOT NULL REFERENCES products(id),
  delta INTEGER NOT NULL, reason TEXT NOT NULL, order_id TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE carts (
  customer_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  shop_id TEXT REFERENCES shops(id), updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE cart_items (
  customer_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  product_id TEXT NOT NULL REFERENCES products(id), qty INTEGER NOT NULL CHECK (qty > 0),
  PRIMARY KEY (customer_id, product_id)
);
CREATE TABLE orders (
  id TEXT PRIMARY KEY, number TEXT NOT NULL UNIQUE,
  customer_id TEXT NOT NULL REFERENCES users(id), shop_id TEXT NOT NULL REFERENCES shops(id),
  partner_id TEXT REFERENCES users(id),
  status TEXT NOT NULL CHECK (status IN ('pending_payment','placed','accepted','preparing','ready_for_pickup','assigned','picked_up','out_for_delivery','delivered','rejected','cancelled')),
  payment_method TEXT NOT NULL CHECK (payment_method IN ('cod','online')),
  payment_status TEXT NOT NULL DEFAULT 'unpaid' CHECK (payment_status IN ('unpaid','paid','failed','refunded','partially_refunded')),
  subtotal_paise INTEGER NOT NULL, delivery_fee_paise INTEGER NOT NULL, platform_fee_paise INTEGER NOT NULL DEFAULT 0,
  total_paise INTEGER NOT NULL, partner_commission_paise INTEGER NOT NULL, partner_earning_paise INTEGER NOT NULL,
  shop_commission_bps INTEGER NOT NULL DEFAULT 0,
  addr_name TEXT NOT NULL, addr_phone TEXT NOT NULL, addr_line TEXT NOT NULL, addr_lat REAL NOT NULL, addr_lng REAL NOT NULL,
  note TEXT, delivery_code TEXT NOT NULL, cancel_reason TEXT, cancelled_by TEXT, idempotency_key TEXT,
  accepted_at TEXT, ready_at TEXT, assigned_at TEXT, picked_up_at TEXT, delivered_at TEXT, cancelled_at TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE (customer_id, idempotency_key)
);
CREATE INDEX idx_orders_customer ON orders(customer_id, created_at);
CREATE INDEX idx_orders_shop ON orders(shop_id, status, created_at);
CREATE INDEX idx_orders_partner ON orders(partner_id, status);
CREATE INDEX idx_orders_status ON orders(status, created_at);
CREATE TABLE order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT, order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id TEXT NOT NULL REFERENCES products(id), name TEXT NOT NULL, price_paise INTEGER NOT NULL, qty INTEGER NOT NULL
);
CREATE TABLE order_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT, order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  status TEXT NOT NULL, actor_id TEXT, actor_role TEXT, note TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE payments (
  id TEXT PRIMARY KEY, order_id TEXT NOT NULL REFERENCES orders(id), method TEXT NOT NULL,
  gateway TEXT, gateway_order_id TEXT UNIQUE, gateway_payment_id TEXT UNIQUE,
  amount_paise INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'created' CHECK (status IN ('created','paid','failed','refunded','partially_refunded')),
  failure_reason TEXT, paid_at TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_payments_order ON payments(order_id);
CREATE TABLE webhook_events (
  id TEXT PRIMARY KEY, provider TEXT NOT NULL, event_type TEXT, received_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE refunds (
  id TEXT PRIMARY KEY, order_id TEXT NOT NULL REFERENCES orders(id), payment_id TEXT NOT NULL REFERENCES payments(id),
  amount_paise INTEGER NOT NULL CHECK (amount_paise > 0), reason TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','processed','failed')),
  gateway_refund_id TEXT UNIQUE, failure_reason TEXT, requested_by TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')), processed_at TEXT
);
CREATE TABLE commissions (
  order_id TEXT PRIMARY KEY REFERENCES orders(id),
  shop_commission_paise INTEGER NOT NULL, delivery_commission_paise INTEGER NOT NULL,
  platform_fee_paise INTEGER NOT NULL, partner_earning_paise INTEGER NOT NULL, seller_earning_paise INTEGER NOT NULL,
  calculated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE settlements (
  id TEXT PRIMARY KEY, payee_type TEXT NOT NULL CHECK (payee_type IN ('seller','partner')), payee_id TEXT NOT NULL REFERENCES users(id),
  amount_paise INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid','failed')),
  reference TEXT, created_by TEXT, paid_at TEXT, note TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
-- Ledger: append-only money movements. Positive = platform owes payee, negative = payee owes platform.
CREATE TABLE transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, order_id TEXT NOT NULL REFERENCES orders(id),
  payee_type TEXT NOT NULL CHECK (payee_type IN ('seller','partner','platform')), payee_id TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('order_earning','delivery_earning','shop_commission','delivery_commission','platform_fee','cod_cash_held','refund_adjustment')),
  amount_paise INTEGER NOT NULL, settlement_id TEXT REFERENCES settlements(id),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE (order_id, payee_type, payee_id, kind)
);
CREATE INDEX idx_tx_payee ON transactions(payee_type, payee_id, settlement_id);
CREATE TABLE delivery_tracking (
  id INTEGER PRIMARY KEY AUTOINCREMENT, order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  partner_id TEXT NOT NULL REFERENCES users(id), lat REAL NOT NULL, lng REAL NOT NULL,
  accuracy_m REAL, speed_mps REAL, heading REAL, recorded_at TEXT NOT NULL
);
CREATE INDEX idx_tracking_order ON delivery_tracking(order_id, id);
CREATE TABLE notifications (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL, title TEXT NOT NULL, body TEXT, data TEXT, read_at TEXT,
  push_status TEXT NOT NULL DEFAULT 'pending' CHECK (push_status IN ('pending','sent','failed','not_configured','no_device')),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_notif_user ON notifications(user_id, created_at);
CREATE TABLE reviews (
  id TEXT PRIMARY KEY, order_id TEXT NOT NULL UNIQUE REFERENCES orders(id), customer_id TEXT NOT NULL REFERENCES users(id),
  shop_id TEXT NOT NULL REFERENCES shops(id), shop_rating INTEGER NOT NULL CHECK (shop_rating BETWEEN 1 AND 5),
  partner_rating INTEGER CHECK (partner_rating BETWEEN 1 AND 5), comment TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE support_tickets (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), order_id TEXT REFERENCES orders(id),
  subject TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','in_progress','resolved','closed')),
  category TEXT NOT NULL DEFAULT 'general' CHECK (category IN ('general','order','payment','refund','delivery','account','complaint')),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE ticket_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id TEXT NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
  author_id TEXT NOT NULL REFERENCES users(id), body TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE admin_settings (
  key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_by TEXT,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE site_content (
  key TEXT PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT, actor_id TEXT, action TEXT NOT NULL, entity TEXT, entity_id TEXT, meta TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

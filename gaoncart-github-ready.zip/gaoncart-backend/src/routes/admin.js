import fs from 'node:fs';
import path from 'node:path';
import { uid, nowIso, getSetting } from '../db.js';
import { E, v, validate, page } from '../lib/http.js';
import { hashPassword } from '../lib/security.js';
import { istRange, istTodayStart } from '../lib/dates.js';

export function registerAdmin(r, A) {
  const { db, domain, notify, audit, enc, cfg, adminLevel } = A;
  const ANY = adminLevel('support', 'finance'), FIN = adminLevel('finance'), SUP = adminLevel('support'), SUPER = adminLevel();
  const rev = id => db.run('UPDATE refresh_tokens SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL', nowIso(), id);

  r.get('/v1/admin/dashboard', ANY, () => {
    const c = q => db.get(q).c, today = istTodayStart();
    return {
      customers: c("SELECT COUNT(*) c FROM users WHERE role='customer' AND status!='deleted'"), sellers: c("SELECT COUNT(*) c FROM users WHERE role='seller' AND status!='deleted'"), delivery_partners: c("SELECT COUNT(*) c FROM users WHERE role='delivery' AND status!='deleted'"),
      shops: db.all('SELECT approval_status status, COUNT(*) count FROM shops GROUP BY approval_status'), pending_partner_verifications: c("SELECT COUNT(*) c FROM delivery_partners WHERE verification_status='pending' AND user_id IN (SELECT partner_id FROM partner_documents)"),
      orders_by_status: db.all('SELECT status, COUNT(*) count FROM orders GROUP BY status'),
      today: db.get("SELECT COUNT(*) orders, COALESCE(SUM(total_paise),0) gmv_paise FROM orders WHERE created_at>=? AND status NOT IN ('cancelled','rejected','pending_payment')", today),
      platform_revenue_paise: db.get("SELECT COALESCE(SUM(amount_paise),0) s FROM transactions WHERE payee_type='platform'").s,
      open_tickets: c("SELECT COUNT(*) c FROM support_tickets WHERE status IN ('open','in_progress')"), pending_refunds: c("SELECT COUNT(*) c FROM refunds WHERE status='pending'"),
    };
  });

  // ----- users -----
  r.get('/v1/admin/users', ANY, (ctx) => {
    const { limit, offset } = page(ctx.query, 30), role = ctx.query.get('role'), st = ctx.query.get('status'), q = ctx.query.get('q');
    const cond = ['1=1'], p = [];
    if (role) { cond.push('role=?'); p.push(role); } if (st) { cond.push('status=?'); p.push(st); } if (q) { cond.push('(name LIKE ? OR mobile LIKE ? OR email LIKE ?)'); p.push(`%${q}%`, `%${q}%`, `%${q}%`); }
    return { items: db.all(`SELECT id,role,name,mobile,email,status,status_reason,created_at FROM users WHERE ${cond.join(' AND ')} ORDER BY created_at DESC LIMIT ? OFFSET ?`, ...p, limit, offset) };
  });
  r.get('/v1/admin/users/:id', ANY, (ctx) => {
    const u = db.get('SELECT id,role,name,mobile,email,status,status_reason,created_at FROM users WHERE id=?', ctx.params.id); if (!u) throw E.notFound();
    return { ...u, orders: db.get('SELECT COUNT(*) c FROM orders WHERE customer_id=? OR partner_id=? OR shop_id IN (SELECT id FROM shops WHERE seller_id=?)', u.id, u.id, u.id).c };
  });
  r.post('/v1/admin/users/:id/status', SUP, (ctx) => {
    const b = validate(ctx.body, { status: v.oneOf(['active', 'suspended', 'blocked']), reason: v.opt(v.str({ max: 200 })) });
    const u = db.get('SELECT * FROM users WHERE id=?', ctx.params.id); if (!u || u.status === 'deleted') throw E.notFound();
    if (u.role === 'admin' && ctx.user.level !== 'super') throw E.forbid('Only a super admin can change admin accounts');
    if (u.id === ctx.user.id) throw E.conflict('You cannot change your own status');
    db.tx(() => {
      db.run('UPDATE users SET status=?, status_reason=?, updated_at=? WHERE id=?', b.status, b.reason ?? null, nowIso(), u.id);
      if (b.status !== 'active') { rev(u.id); if (u.role === 'seller') db.run('UPDATE shops SET is_online=0 WHERE seller_id=?', u.id); if (u.role === 'delivery') db.run('UPDATE delivery_partners SET is_online=0 WHERE user_id=?', u.id); }
      audit(ctx.user.id, 'user_status', 'user', u.id, b);
    });
    return { id: u.id, status: b.status };
  });
  r.post('/v1/admin/admins', SUPER, async (ctx) => {
    const b = validate(ctx.body, { email: v.str({ max: 120, re: /^[^@\s]+@[^@\s]+\.[^@\s]+$/ }), password: v.str({ min: 12, max: 200, trim: false }), name: v.str({ max: 80 }), level: v.oneOf(['super', 'finance', 'support']) });
    const id = uid(), h = await hashPassword(b.password);
    db.tx(() => { db.run("INSERT INTO users(id,role,email,password_hash,name) VALUES (?,'admin',?,?,?)", id, b.email.toLowerCase(), h, b.name); db.run('INSERT INTO admins(user_id,level) VALUES (?,?)', id, b.level); audit(ctx.user.id, 'admin_created', 'user', id, { level: b.level }); });
    ctx.status = 201; return { id };
  });

  // ----- shops -----
  r.get('/v1/admin/shops', ANY, (ctx) => {
    const { limit, offset } = page(ctx.query, 30), st = ctx.query.get('approval_status');
    return { items: db.all(`SELECT s.id,s.name,s.address,s.village,s.lat,s.lng,s.approval_status,s.rejection_reason,s.is_online,s.commission_bps,s.rating_avg,s.created_at,u.name seller_name,u.mobile seller_mobile,u.status seller_status, sl.gstin, sl.fssai_no
      FROM shops s JOIN users u ON u.id=s.seller_id JOIN sellers sl ON sl.user_id=s.seller_id ${st ? 'WHERE s.approval_status=?' : ''} ORDER BY s.created_at DESC LIMIT ? OFFSET ?`, ...(st ? [st] : []), limit, offset) };
  });
  const shopDecision = (p, status, reasonReq) => r.post(`/v1/admin/shops/:id/${p}`, SUP, (ctx) => {
    const b = reasonReq ? validate(ctx.body, { reason: v.str({ max: 200 }) }) : {};
    const s = db.get('SELECT * FROM shops WHERE id=?', ctx.params.id); if (!s) throw E.notFound();
    db.run('UPDATE shops SET approval_status=?, rejection_reason=?, is_online=CASE WHEN ?=\'approved\' THEN is_online ELSE 0 END, updated_at=? WHERE id=?', status, b.reason ?? null, status, nowIso(), s.id);
    audit(ctx.user.id, 'shop_' + status, 'shop', s.id, b);
    notify(s.seller_id, 'shop_status', status === 'approved' ? 'Shop approved' : `Shop ${status}`, status === 'approved' ? 'Your shop is approved. Add products and go online.' : (b.reason ?? ''), { shop_id: s.id });
    return { id: s.id, approval_status: status };
  });
  shopDecision('approve', 'approved'); shopDecision('reject', 'rejected', true); shopDecision('suspend', 'suspended', true);
  r.patch('/v1/admin/shops/:id', FIN, (ctx) => {
    const b = validate(ctx.body, { commission_bps: v.int({ min: 0, max: 5000 }) });
    if (!db.run('UPDATE shops SET commission_bps=?, updated_at=? WHERE id=?', b.commission_bps, nowIso(), ctx.params.id).changes) throw E.notFound();
    audit(ctx.user.id, 'shop_commission', 'shop', ctx.params.id, b); return { ok: true };
  });

  // ----- delivery partners -----
  r.get('/v1/admin/partners', ANY, (ctx) => {
    const { limit, offset } = page(ctx.query, 30), st = ctx.query.get('verification_status');
    return { items: db.all(`SELECT u.id,u.name,u.mobile,u.status,dp.vehicle_type,dp.vehicle_number,dp.verification_status,dp.is_online,dp.rejection_reason,(SELECT COUNT(*) FROM partner_documents d WHERE d.partner_id=u.id) documents
      FROM delivery_partners dp JOIN users u ON u.id=dp.user_id WHERE u.status!='deleted' ${st ? 'AND dp.verification_status=?' : ''} ORDER BY u.created_at DESC LIMIT ? OFFSET ?`, ...(st ? [st] : []), limit, offset) };
  });
  r.get('/v1/admin/partners/:id', ANY, (ctx) => {
    const p = db.get('SELECT u.id,u.name,u.mobile,u.status,dp.* FROM delivery_partners dp JOIN users u ON u.id=dp.user_id WHERE dp.user_id=?', ctx.params.id); if (!p) throw E.notFound();
    const docs = db.all('SELECT id,doc_type,doc_number_enc,status,created_at FROM partner_documents WHERE partner_id=?', p.id).map(d => { const n = enc.decrypt(d.doc_number_enc); return { id: d.id, doc_type: d.doc_type, status: d.status, created_at: d.created_at, doc_number_masked: n ? '•'.repeat(Math.max(0, n.length - 4)) + n.slice(-4) : null, file_url: `/v1/admin/partners/${p.id}/documents/${d.id}/file` }; });
    delete p.payout_upi_enc; return { ...p, documents: docs };
  });
  r.get('/v1/admin/partners/:id/documents/:docId/file', SUP, (ctx) => {
    const d = db.get('SELECT file_key FROM partner_documents WHERE id=? AND partner_id=?', ctx.params.docId, ctx.params.id); if (!d) throw E.notFound();
    const f = path.join(cfg.privateUploadDir, path.basename(d.file_key)); if (!fs.existsSync(f)) throw E.notFound();
    audit(ctx.user.id, 'document_viewed', 'partner_document', ctx.params.docId);
    const ext = f.split('.').pop();
    ctx.res.writeHead(200, { 'Content-Type': { jpg: 'image/jpeg', png: 'image/png', webp: 'image/webp' }[ext], 'Cache-Control': 'private, no-store' }); ctx.res.end(fs.readFileSync(f)); ctx.responded = true;
  });
  r.post('/v1/admin/partners/:id/verify', SUP, (ctx) => {
    const p = db.get('SELECT * FROM delivery_partners WHERE user_id=?', ctx.params.id); if (!p) throw E.notFound();
    if (!db.get('SELECT 1 x FROM partner_documents WHERE partner_id=?', p.user_id)) throw E.conflict('The partner has not uploaded any documents', 'no_documents');
    db.tx(() => { db.run("UPDATE delivery_partners SET verification_status='verified', rejection_reason=NULL WHERE user_id=?", p.user_id); db.run("UPDATE partner_documents SET status='approved' WHERE partner_id=?", p.user_id); audit(ctx.user.id, 'partner_verified', 'user', p.user_id); });
    notify(p.user_id, 'verification', 'You are verified', 'You can now go online and accept deliveries.', {}); return { ok: true };
  });
  r.post('/v1/admin/partners/:id/reject', SUP, (ctx) => {
    const b = validate(ctx.body, { reason: v.str({ max: 200 }) });
    if (!db.run("UPDATE delivery_partners SET verification_status='rejected', rejection_reason=?, is_online=0 WHERE user_id=?", b.reason, ctx.params.id).changes) throw E.notFound();
    audit(ctx.user.id, 'partner_rejected', 'user', ctx.params.id, b); notify(ctx.params.id, 'verification', 'Verification rejected', b.reason, {}); return { ok: true };
  });

  // ----- catalog -----
  r.get('/v1/admin/products', ANY, (ctx) => {
    const { limit, offset } = page(ctx.query, 30), q = ctx.query.get('q'), shop = ctx.query.get('shop_id'), cond = ['p.deleted_at IS NULL'], p = [];
    if (q) { cond.push('p.name LIKE ?'); p.push(`%${q}%`); } if (shop) { cond.push('p.shop_id=?'); p.push(shop); }
    return { items: db.all(`SELECT p.id,p.name,p.price_paise,p.stock_qty,p.is_available,p.is_blocked,s.name shop_name FROM products p JOIN shops s ON s.id=p.shop_id WHERE ${cond.join(' AND ')} ORDER BY p.created_at DESC LIMIT ? OFFSET ?`, ...p, limit, offset) };
  });
  r.post('/v1/admin/products/:id/block', SUP, (ctx) => {
    const b = validate(ctx.body, { blocked: v.bool(), reason: v.opt(v.str({ max: 200 })) });
    if (!db.run('UPDATE products SET is_blocked=?, updated_at=? WHERE id=?', b.blocked ? 1 : 0, nowIso(), ctx.params.id).changes) throw E.notFound();
    if (b.blocked) db.run('DELETE FROM cart_items WHERE product_id=?', ctx.params.id);
    audit(ctx.user.id, 'product_block', 'product', ctx.params.id, b); return { ok: true };
  });
  const cat = { name: v.str({ max: 60 }), slug: v.str({ max: 60, re: /^[a-z0-9-]+$/ }), kind: v.oneOf(['shop', 'product']), icon_url: v.opt(v.str({ max: 200 })), sort_order: v.opt(v.int({ min: 0, max: 9999 })) };
  r.get('/v1/admin/categories', ANY, () => ({ items: db.all('SELECT * FROM categories ORDER BY sort_order,name') }));
  r.post('/v1/admin/categories', SUP, (ctx) => { const b = validate(ctx.body, cat), id = uid(); db.run('INSERT INTO categories(id,name,slug,kind,icon_url,sort_order) VALUES (?,?,?,?,?,?)', id, b.name, b.slug, b.kind, b.icon_url ?? null, b.sort_order ?? 0); ctx.status = 201; return { id }; });
  r.patch('/v1/admin/categories/:id', SUP, (ctx) => {
    const b = validate(ctx.body, { ...Object.fromEntries(Object.entries(cat).map(([k, f]) => [k, f.optional ? f : v.opt(f)])), is_active: v.opt(v.bool()) });
    const c = db.get('SELECT * FROM categories WHERE id=?', ctx.params.id); if (!c) throw E.notFound(); const m = { ...c, ...b };
    db.run('UPDATE categories SET name=?,slug=?,kind=?,icon_url=?,sort_order=?,is_active=? WHERE id=?', m.name, m.slug, m.kind, m.icon_url, m.sort_order, m.is_active === false || m.is_active === 0 ? 0 : 1, c.id); return { ok: true };
  });

  // ----- banners -----
  const ban = { title: v.str({ max: 80 }), subtitle: v.opt(v.str({ max: 150 })), image_url: v.str({ max: 100, re: /^\/uploads\/[a-f0-9-]{36}\.(jpg|png|webp)$/ }), shop_id: v.opt(v.id()), category_id: v.opt(v.id()), sort_order: v.opt(v.int({ min: 0, max: 999 })), is_active: v.opt(v.bool()), starts_at: v.opt(v.str({ max: 40 })), ends_at: v.opt(v.str({ max: 40 })) };
  r.get('/v1/admin/banners', ANY, () => ({ items: db.all('SELECT * FROM banners ORDER BY sort_order, created_at DESC') }));
  r.post('/v1/admin/banners', SUP, (ctx) => { const b = validate(ctx.body, ban), id = uid();
    db.run('INSERT INTO banners(id,title,subtitle,image_url,shop_id,category_id,sort_order,is_active,starts_at,ends_at) VALUES (?,?,?,?,?,?,?,?,?,?)', id, b.title, b.subtitle ?? null, b.image_url, b.shop_id ?? null, b.category_id ?? null, b.sort_order ?? 0, b.is_active === false ? 0 : 1, b.starts_at ?? null, b.ends_at ?? null);
    audit(ctx.user.id, 'banner_created', 'banner', id); ctx.status = 201; return { id }; });
  r.del('/v1/admin/banners/:id', SUP, (ctx) => { if (!db.run('DELETE FROM banners WHERE id=?', ctx.params.id).changes) throw E.notFound(); ctx.status = 204; return undefined; });

  // ----- orders -----
  r.get('/v1/admin/orders', ANY, (ctx) => {
    const { limit, offset } = page(ctx.query, 30), [from, to] = istRange(ctx.query, 3650), cond = ['o.created_at>=?', 'o.created_at<?'], p = [from, to];
    for (const [k, col] of [['status', 'o.status'], ['shop_id', 'o.shop_id'], ['customer_id', 'o.customer_id'], ['partner_id', 'o.partner_id']]) if (ctx.query.get(k)) { cond.push(`${col}=?`); p.push(ctx.query.get(k)); }
    return { items: db.all(`SELECT o.id,o.number,o.status,o.payment_method,o.payment_status,o.total_paise,o.created_at,o.cancel_reason,s.name shop_name,u.name customer_name FROM orders o JOIN shops s ON s.id=o.shop_id JOIN users u ON u.id=o.customer_id WHERE ${cond.join(' AND ')} ORDER BY o.created_at DESC LIMIT ? OFFSET ?`, ...p, limit, offset) };
  });
  r.get('/v1/admin/orders/:id', ANY, (ctx) => {
    const o = db.get('SELECT * FROM orders WHERE id=?', ctx.params.id); if (!o) throw E.notFound();
    return { ...A.orderView(o, 'admin'), payments: db.all('SELECT id,method,status,amount_paise,gateway_payment_id,paid_at FROM payments WHERE order_id=?', o.id), refunds: db.all('SELECT * FROM refunds WHERE order_id=?', o.id), commission: db.get('SELECT * FROM commissions WHERE order_id=?', o.id) ?? null };
  });
  r.post('/v1/admin/orders/:id/cancel', SUP, async (ctx) => {
    const b = validate(ctx.body, { reason: v.str({ max: 200 }) });
    await domain.transition(ctx.params.id, 'cancelled', { id: ctx.user.id, role: 'admin' }, { note: b.reason });
    audit(ctx.user.id, 'order_cancelled', 'order', ctx.params.id, b); return { ok: true };
  });

  // ----- complaints / tickets -----
  r.get('/v1/admin/tickets', ANY, (ctx) => {
    const { limit, offset } = page(ctx.query, 30), st = ctx.query.get('status');
    return { items: db.all(`SELECT t.id,t.subject,t.status,t.category,t.order_id,t.created_at,t.updated_at,u.name,u.role,u.mobile FROM support_tickets t JOIN users u ON u.id=t.user_id ${st ? 'WHERE t.status=?' : ''} ORDER BY t.updated_at DESC LIMIT ? OFFSET ?`, ...(st ? [st] : []), limit, offset) };
  });
  r.get('/v1/admin/tickets/:id', ANY, (ctx) => { const t = db.get('SELECT * FROM support_tickets WHERE id=?', ctx.params.id); if (!t) throw E.notFound(); return { ...t, messages: db.all('SELECT m.id,m.body,m.created_at,m.author_id FROM ticket_messages m WHERE ticket_id=? ORDER BY id', t.id) }; });
  r.post('/v1/admin/tickets/:id/reply', SUP, (ctx) => {
    const b = validate(ctx.body, { body: v.str({ max: 3000 }), status: v.opt(v.oneOf(['in_progress', 'resolved', 'closed'])) });
    const t = db.get('SELECT * FROM support_tickets WHERE id=?', ctx.params.id); if (!t) throw E.notFound();
    db.tx(() => { db.run('INSERT INTO ticket_messages(ticket_id,author_id,body) VALUES (?,?,?)', t.id, ctx.user.id, b.body); db.run('UPDATE support_tickets SET status=?, updated_at=? WHERE id=?', b.status ?? 'in_progress', nowIso(), t.id); });
    notify(t.user_id, 'ticket', 'Support replied', t.subject, { ticket_id: t.id }); return { ok: true };
  });

  // ----- refunds -----
  r.get('/v1/admin/refunds', FIN, (ctx) => { const st = ctx.query.get('status'); return { items: db.all(`SELECT r.*, o.number FROM refunds r JOIN orders o ON o.id=r.order_id ${st ? 'WHERE r.status=?' : ''} ORDER BY r.created_at DESC LIMIT 200`, ...(st ? [st] : [])) }; });
  r.post('/v1/admin/refunds', FIN, async (ctx) => {
    const b = validate(ctx.body, { order_id: v.id(), amount_paise: v.int({ min: 100 }), reason: v.str({ max: 200 }) });
    const id = db.tx(() => domain.startRefundTx(b.order_id, b.amount_paise, b.reason, ctx.user.id));
    audit(ctx.user.id, 'refund_requested', 'refund', id, b); const out = await domain.processRefund(id); ctx.status = 201; return out;
  });
  r.post('/v1/admin/refunds/:id/retry', FIN, async (ctx) => { const x = db.get('SELECT 1 x FROM refunds WHERE id=?', ctx.params.id); if (!x) throw E.notFound(); return domain.processRefund(ctx.params.id); });

  // ----- money views -----
  r.get('/v1/admin/payments', FIN, (ctx) => { const st = ctx.query.get('status'), { limit, offset } = page(ctx.query, 50); return { items: db.all(`SELECT p.id,p.order_id,o.number,p.method,p.status,p.amount_paise,p.gateway_order_id,p.gateway_payment_id,p.failure_reason,p.paid_at,p.created_at FROM payments p JOIN orders o ON o.id=p.order_id ${st ? 'WHERE p.status=?' : ''} ORDER BY p.created_at DESC LIMIT ? OFFSET ?`, ...(st ? [st] : []), limit, offset) }; });
  r.get('/v1/admin/transactions', FIN, (ctx) => {
    const { limit, offset } = page(ctx.query, 50), cond = ['1=1'], p = [];
    for (const k of ['payee_type', 'payee_id', 'kind']) if (ctx.query.get(k)) { cond.push(`${k}=?`); p.push(ctx.query.get(k)); }
    return { items: db.all(`SELECT * FROM transactions WHERE ${cond.join(' AND ')} ORDER BY id DESC LIMIT ? OFFSET ?`, ...p, limit, offset) };
  });
  r.get('/v1/admin/revenue', FIN, (ctx) => {
    const [from, to] = istRange(ctx.query);
    const t = db.all("SELECT kind, COALESCE(SUM(amount_paise),0) paise FROM transactions WHERE payee_type='platform' AND created_at>=? AND created_at<? GROUP BY kind", from, to);
    return { from, to, by_kind: t, total_paise: t.reduce((a, x) => a + x.paise, 0), gmv_paise: db.get("SELECT COALESCE(SUM(total_paise),0) s FROM orders WHERE status='delivered' AND delivered_at>=? AND delivered_at<?", from, to).s };
  });

  // ----- settlements -----
  // Groups every unsettled ledger entry per payee into one settlement. Positive = we pay them; negative = they owe us (COD cash).
  r.post('/v1/admin/settlements/generate', FIN, (ctx) => {
    const b = validate(ctx.body, { payee_type: v.oneOf(['seller', 'partner']), payee_id: v.opt(v.id()) });
    const out = db.tx(() => {
      const groups = db.all(`SELECT payee_id, SUM(amount_paise) net FROM transactions WHERE payee_type=? AND settlement_id IS NULL ${b.payee_id ? 'AND payee_id=?' : ''} GROUP BY payee_id HAVING net != 0`, b.payee_type, ...(b.payee_id ? [b.payee_id] : []));
      return groups.map(g => { const id = uid(); db.run('INSERT INTO settlements(id,payee_type,payee_id,amount_paise,created_by) VALUES (?,?,?,?,?)', id, b.payee_type, g.payee_id, g.net, ctx.user.id);
        db.run('UPDATE transactions SET settlement_id=? WHERE payee_type=? AND payee_id=? AND settlement_id IS NULL', id, b.payee_type, g.payee_id); return { id, payee_id: g.payee_id, amount_paise: g.net }; });
    });
    audit(ctx.user.id, 'settlements_generated', 'settlement', null, { count: out.length }); ctx.status = 201; return { created: out };
  });
  r.get('/v1/admin/settlements', FIN, (ctx) => { const st = ctx.query.get('status'); return { items: db.all(`SELECT s.*, u.name payee_name, u.mobile payee_mobile FROM settlements s JOIN users u ON u.id=s.payee_id ${st ? 'WHERE s.status=?' : ''} ORDER BY s.created_at DESC LIMIT 200`, ...(st ? [st] : [])) }; });
  r.post('/v1/admin/settlements/:id/mark-paid', FIN, (ctx) => {
    const b = validate(ctx.body, { reference: v.str({ max: 100 }) });
    const x = db.run("UPDATE settlements SET status='paid', reference=?, paid_at=? WHERE id=? AND status='pending'", b.reference, nowIso(), ctx.params.id);
    if (!x.changes) throw E.conflict('Settlement not found or not pending', 'not_pending');
    const s = db.get('SELECT * FROM settlements WHERE id=?', ctx.params.id); audit(ctx.user.id, 'settlement_paid', 'settlement', s.id, b);
    notify(s.payee_id, 'payment', s.amount_paise >= 0 ? 'Payout sent' : 'Cash remittance recorded', `₹${(Math.abs(s.amount_paise) / 100).toFixed(2)} ref ${b.reference}`, { settlement_id: s.id }); return s;
  });
  r.post('/v1/admin/settlements/:id/fail', FIN, (ctx) => {
    const b = validate(ctx.body, { reason: v.str({ max: 200 }) });
    db.tx(() => { const x = db.run("UPDATE settlements SET status='failed', note=? WHERE id=? AND status='pending'", b.reason, ctx.params.id); if (!x.changes) throw E.conflict('Settlement not pending', 'not_pending'); db.run('UPDATE transactions SET settlement_id=NULL WHERE settlement_id=?', ctx.params.id); });
    return { ok: true };
  });

  // ----- settings, content, broadcast, analytics -----
  const SETTINGS = { delivery_fee_paise: v.int({ min: 0, max: 100000 }), partner_commission_paise: v.int({ min: 0, max: 100000 }), shop_commission_bps: v.int({ min: 0, max: 5000 }), platform_fee_paise: v.int({ min: 0, max: 50000 }), service_radius_km: v.int({ min: 1, max: 50 }), customer_cancel_until: v.oneOf(['placed', 'accepted']), pending_payment_ttl_min: v.int({ min: 5, max: 120 }), cod_max_paise: v.int({ min: 0, max: 5000000 }) };
  r.get('/v1/admin/settings', ANY, () => Object.fromEntries(db.all('SELECT key,value FROM admin_settings').map(s => [s.key, s.value])));
  r.patch('/v1/admin/settings', FIN, (ctx) => {
    const b = validate(ctx.body, Object.fromEntries(Object.entries(SETTINGS).map(([k, f]) => [k, v.opt(f)])));
    if (b.partner_commission_paise != null && b.partner_commission_paise > Number(b.delivery_fee_paise ?? getSetting(db, 'delivery_fee_paise'))) throw E.invalid({ partner_commission_paise: 'cannot exceed the delivery fee' });
    db.tx(() => { for (const [k, val] of Object.entries(b)) db.run('INSERT INTO admin_settings(key,value,updated_by) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_by=excluded.updated_by, updated_at=?', k, String(val), ctx.user.id, nowIso()); audit(ctx.user.id, 'settings', 'settings', null, b); });
    return Object.fromEntries(db.all('SELECT key,value FROM admin_settings').map(s => [s.key, s.value]));
  });
  r.get('/v1/admin/content', ANY, () => ({ items: db.all('SELECT * FROM site_content ORDER BY key') }));
  r.put('/v1/admin/content/:key', SUP, (ctx) => {
    const b = validate(ctx.body, { title: v.str({ max: 150 }), body: v.str({ max: 50000, trim: false }) });
    if (!/^[a-z0-9_]{2,40}$/.test(ctx.params.key)) throw E.bad('Invalid key');
    db.run('INSERT INTO site_content(key,title,body) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET title=excluded.title, body=excluded.body, updated_at=?', ctx.params.key, b.title, b.body, nowIso()); audit(ctx.user.id, 'content', 'site_content', ctx.params.key); return { ok: true };
  });
  r.post('/v1/admin/notifications', SUP, (ctx) => {
    const b = validate(ctx.body, { role: v.oneOf(['customer', 'seller', 'delivery']), title: v.str({ max: 80 }), body: v.str({ max: 300 }) });
    const ids = db.all("SELECT id FROM users WHERE role=? AND status='active'", b.role);
    db.tx(() => { for (const u of ids) notify(u.id, 'announcement', b.title, b.body, {}); }); audit(ctx.user.id, 'broadcast', 'notification', null, { role: b.role, recipients: ids.length });
    return { recipients: ids.length };
  });
  r.get('/v1/admin/analytics', ANY, (ctx) => {
    const [from, to] = istRange(ctx.query);
    return { from, to,
      orders_per_day: db.all("SELECT date(created_at,'+330 minutes') day, COUNT(*) orders, SUM(CASE WHEN status='delivered' THEN total_paise ELSE 0 END) delivered_gmv_paise FROM orders WHERE created_at>=? AND created_at<? AND status!='pending_payment' GROUP BY day ORDER BY day", from, to),
      cancellation: db.get("SELECT SUM(status IN ('cancelled','rejected')) cancelled, COUNT(*) total FROM orders WHERE created_at>=? AND created_at<? AND status!='pending_payment'", from, to),
      avg_delivery_minutes: db.get("SELECT ROUND(AVG((julianday(delivered_at)-julianday(created_at))*1440),1) m FROM orders WHERE status='delivered' AND delivered_at>=? AND delivered_at<?", from, to).m,
      top_shops: db.all("SELECT s.name, COUNT(*) orders, SUM(o.subtotal_paise) gross_paise FROM orders o JOIN shops s ON s.id=o.shop_id WHERE o.status='delivered' AND o.delivered_at>=? AND o.delivered_at<? GROUP BY s.id ORDER BY gross_paise DESC LIMIT 10", from, to),
      new_users: db.all("SELECT role, COUNT(*) count FROM users WHERE created_at>=? AND created_at<? AND role!='admin' GROUP BY role", from, to) };
  });
  r.get('/v1/admin/audit', SUPER, (ctx) => ({ items: db.all('SELECT * FROM audit_log ORDER BY id DESC LIMIT 200') }));
}

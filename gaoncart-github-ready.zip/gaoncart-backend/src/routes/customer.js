import { uid, nowIso, getIntSetting } from '../db.js';
import { E, v, validate, page } from '../lib/http.js';
import { haversineKm, bbox, safeEqual } from '../lib/security.js';

export function registerCustomer(r, A) {
  const { db, domain, auth, notify, gateway, limiter } = A;
  const C = auth('customer');

  // ----- addresses -----
  const addrSchema = { label: v.opt(v.str({ max: 30 })), recipient_name: v.str({ max: 80 }), phone: v.mobile(), line1: v.str({ max: 200 }), landmark: v.opt(v.str({ max: 100 })), village: v.opt(v.str({ max: 80 })), pincode: v.opt(v.str({ re: /^\d{6}$/ })), lat: v.lat(), lng: v.lng(), is_default: v.opt(v.bool()) };
  const AD = 'id,label,recipient_name,phone,line1,landmark,village,pincode,lat,lng,is_default';
  r.get('/v1/customer/addresses', C, (ctx) => ({ items: db.all(`SELECT ${AD} FROM addresses WHERE user_id=? AND deleted_at IS NULL ORDER BY is_default DESC, created_at DESC`, ctx.user.id) }));
  r.post('/v1/customer/addresses', C, (ctx) => {
    const b = validate(ctx.body, addrSchema);
    return db.tx(() => {
      const n = db.get('SELECT COUNT(*) c FROM addresses WHERE user_id=? AND deleted_at IS NULL', ctx.user.id).c;
      if (n >= 10) throw E.conflict('You can save up to 10 addresses', 'limit');
      const def = n === 0 || b.is_default ? 1 : 0, id = uid();
      if (def) db.run('UPDATE addresses SET is_default=0 WHERE user_id=?', ctx.user.id);
      db.run('INSERT INTO addresses(id,user_id,label,recipient_name,phone,line1,landmark,village,pincode,lat,lng,is_default) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', id, ctx.user.id, b.label ?? null, b.recipient_name, b.phone, b.line1, b.landmark ?? null, b.village ?? null, b.pincode ?? null, b.lat, b.lng, def);
      ctx.status = 201; return db.get(`SELECT ${AD} FROM addresses WHERE id=?`, id);
    });
  });
  r.patch('/v1/customer/addresses/:id', C, (ctx) => {
    const sch = Object.fromEntries(Object.entries(addrSchema).map(([k, f]) => [k, f.optional ? f : v.opt(f)]));
    const b = validate(ctx.body, sch);
    const a = db.get('SELECT * FROM addresses WHERE id=? AND user_id=? AND deleted_at IS NULL', ctx.params.id, ctx.user.id);
    if (!a) throw E.notFound();
    return db.tx(() => {
      const m = { ...a, ...b };
      if (b.is_default) db.run('UPDATE addresses SET is_default=0 WHERE user_id=?', ctx.user.id);
      db.run('UPDATE addresses SET label=?,recipient_name=?,phone=?,line1=?,landmark=?,village=?,pincode=?,lat=?,lng=?,is_default=? WHERE id=?', m.label, m.recipient_name, m.phone, m.line1, m.landmark, m.village, m.pincode, m.lat, m.lng, b.is_default ? 1 : a.is_default, a.id);
      return db.get(`SELECT ${AD} FROM addresses WHERE id=?`, a.id);
    });
  });
  r.del('/v1/customer/addresses/:id', C, (ctx) => {
    const x = db.run('UPDATE addresses SET deleted_at=?, is_default=0 WHERE id=? AND user_id=? AND deleted_at IS NULL', nowIso(), ctx.params.id, ctx.user.id);
    if (!x.changes) throw E.notFound(); ctx.status = 204; return undefined;
  });

  // ----- discovery (only approved + online + in-hours shops that have purchasable products) -----
  const geo = q => {
    const lat = Number(q.get('lat')), lng = Number(q.get('lng'));
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180 || q.get('lat') === null) throw E.bad('lat and lng query parameters are required');
    return { lat, lng, radius: Math.min(25, Math.max(1, Number(q.get('radius')) || getIntSetting(db, 'service_radius_km'))) };
  };
  const shopCard = (s, km) => ({ id: s.id, name: s.name, description: s.description, logo_url: s.logo_url, cover_url: s.cover_url, address: s.address, village: s.village, rating_avg: s.rating_avg, rating_count: s.rating_count, min_order_paise: s.min_order_paise, distance_km: Math.round(km * 10) / 10, eta_min: Math.round(15 + km * 4), lat: s.lat, lng: s.lng });
  function visibleShops({ lat, lng, radius }, { q, categoryId } = {}) {
    const [a, b, c, d] = bbox(lat, lng, radius);
    const rows = db.all(`SELECT s.* FROM shops s JOIN users u ON u.id=s.seller_id WHERE s.approval_status='approved' AND s.is_online=1 AND u.status='active'
      AND s.lat BETWEEN ? AND ? AND s.lng BETWEEN ? AND ? ${q ? 'AND s.name LIKE ?' : ''}
      ${categoryId ? 'AND s.id IN (SELECT shop_id FROM shop_categories WHERE category_id=?)' : ''}`, a, b, c, d, ...(q ? [`%${q}%`] : []), ...(categoryId ? [categoryId] : []));
    return rows.map(s => ({ s, km: haversineKm(lat, lng, s.lat, s.lng) })).filter(x => x.km <= radius && domain.shopOpenNow(x.s) && domain.availableProductCount(x.s.id) > 0).sort((x, y) => x.km - y.km);
  }
  r.get('/v1/customer/shops', C, (ctx) => {
    const g = geo(ctx.query), { limit, offset } = page(ctx.query, 20);
    const list = visibleShops(g, { q: ctx.query.get('q')?.slice(0, 60) || null, categoryId: ctx.query.get('category_id') });
    return { total: list.length, items: list.slice(offset, offset + limit).map(x => shopCard(x.s, x.km)) };
  });
  r.get('/v1/customer/shops/:id', C, (ctx) => {
    const s = db.get('SELECT s.* FROM shops s JOIN users u ON u.id=s.seller_id WHERE s.id=? AND u.status=\'active\'', ctx.params.id);
    if (!s || !domain.shopOpenNow(s) || domain.availableProductCount(s.id) === 0) throw E.notFound('This shop is not available right now');
    const lat = Number(ctx.query.get('lat')), lng = Number(ctx.query.get('lng'));
    const km = Number.isFinite(lat) && Number.isFinite(lng) && ctx.query.get('lat') !== null ? haversineKm(lat, lng, s.lat, s.lng) : 0;
    const products = db.all(`SELECT id,name,description,image_url,price_paise,category_id,(is_available=1 AND stock_qty>0) AS purchasable, CASE WHEN stock_qty BETWEEN 1 AND 5 THEN stock_qty END AS low_stock
      FROM products WHERE shop_id=? AND deleted_at IS NULL AND is_blocked=0 ORDER BY name`, s.id).map(p => ({ ...p, purchasable: !!p.purchasable }));
    const cats = db.all('SELECT c.id,c.name FROM categories c JOIN shop_categories sc ON sc.category_id=c.id WHERE sc.shop_id=?', s.id);
    return { ...shopCard(s, km), categories: cats, products };
  });
  r.get('/v1/customer/search', C, (ctx) => {
    const q = (ctx.query.get('q') || '').trim().slice(0, 60);
    if (q.length < 2) throw E.bad('q must be at least 2 characters');
    const g = geo(ctx.query);
    const shops = visibleShops(g, { q }).slice(0, 20).map(x => shopCard(x.s, x.km));
    const open = new Map(visibleShops(g).map(x => [x.s.id, x]));
    const products = db.all("SELECT p.id,p.name,p.image_url,p.price_paise,p.shop_id FROM products p WHERE p.deleted_at IS NULL AND p.is_blocked=0 AND p.is_available=1 AND p.stock_qty>0 AND p.name LIKE ? LIMIT 200", `%${q}%`)
      .filter(p => open.has(p.shop_id)).slice(0, 40).map(p => ({ ...p, shop_name: open.get(p.shop_id).s.name, distance_km: Math.round(open.get(p.shop_id).km * 10) / 10 }));
    return { shops, products };
  });

  // ----- cart -----
  function cartView(uidv) {
    const c = db.get('SELECT shop_id FROM carts WHERE customer_id=?', uidv);
    const items = db.all(`SELECT p.id product_id, p.name, p.image_url, p.price_paise, ci.qty, (p.is_available=1 AND p.deleted_at IS NULL AND p.is_blocked=0 AND p.stock_qty>=ci.qty) AS available
      FROM cart_items ci JOIN products p ON p.id=ci.product_id WHERE ci.customer_id=? ORDER BY p.name`, uidv).map(i => ({ ...i, available: !!i.available, line_total_paise: i.price_paise * i.qty }));
    const shop = c?.shop_id ? db.get('SELECT id,name,logo_url FROM shops WHERE id=?', c.shop_id) : null;
    return { shop, items, subtotal_paise: items.reduce((s, i) => s + i.line_total_paise, 0), delivery_fee_paise: items.length ? getIntSetting(db, 'delivery_fee_paise') : 0 };
  }
  r.get('/v1/customer/cart', C, (ctx) => cartView(ctx.user.id));
  r.put('/v1/customer/cart/items', C, (ctx) => {
    const b = validate(ctx.body, { product_id: v.id(), qty: v.int({ min: 0, max: 50 }), replace_cart: v.opt(v.bool()) });
    db.tx(() => {
      const p = db.get(`SELECT p.*, s.approval_status FROM products p JOIN shops s ON s.id=p.shop_id WHERE p.id=? AND p.deleted_at IS NULL AND p.is_blocked=0`, b.product_id);
      if (!p || p.approval_status !== 'approved') throw E.notFound('Product not found');
      const cart = db.get('SELECT shop_id FROM carts WHERE customer_id=?', ctx.user.id);
      if (b.qty > 0 && (!p.is_available || p.stock_qty < b.qty)) throw E.conflict(p.stock_qty > 0 && p.is_available ? `Only ${p.stock_qty} left` : 'Out of stock', 'out_of_stock');
      if (cart?.shop_id && cart.shop_id !== p.shop_id && b.qty > 0) {
        if (!b.replace_cart) throw E.conflict('Your cart has items from another shop', 'cart_other_shop');
        db.run('DELETE FROM cart_items WHERE customer_id=?', ctx.user.id);
      }
      db.run('INSERT INTO carts(customer_id,shop_id) VALUES (?,NULL) ON CONFLICT(customer_id) DO NOTHING', ctx.user.id);
      if (b.qty === 0) db.run('DELETE FROM cart_items WHERE customer_id=? AND product_id=?', ctx.user.id, p.id);
      else { db.run('INSERT INTO cart_items(customer_id,product_id,qty) VALUES (?,?,?) ON CONFLICT(customer_id,product_id) DO UPDATE SET qty=excluded.qty', ctx.user.id, p.id, b.qty); db.run('UPDATE carts SET shop_id=?, updated_at=? WHERE customer_id=?', p.shop_id, nowIso(), ctx.user.id); }
      if (!db.get('SELECT 1 x FROM cart_items WHERE customer_id=?', ctx.user.id)) db.run('UPDATE carts SET shop_id=NULL WHERE customer_id=?', ctx.user.id);
    });
    return cartView(ctx.user.id);
  });
  r.del('/v1/customer/cart', C, (ctx) => { db.run('DELETE FROM cart_items WHERE customer_id=?', ctx.user.id); db.run('UPDATE carts SET shop_id=NULL WHERE customer_id=?', ctx.user.id); ctx.status = 204; return undefined; });

  // ----- checkout + orders -----
  r.post('/v1/customer/checkout/quote', C, (ctx) => {
    const b = validate(ctx.body, { address_id: v.id() });
    const q = domain.quote(ctx.user.id, b.address_id);
    return { shop_id: q.shop.id, shop_name: q.shop.name, distance_km: q.distance_km, subtotal_paise: q.subtotal_paise, delivery_fee_paise: q.delivery_fee_paise, platform_fee_paise: q.platform_fee_paise, total_paise: q.total_paise, online_payment_available: gateway.configured, cod_available: q.total_paise <= Number(db.get("SELECT value FROM admin_settings WHERE key='cod_max_paise'")?.value ?? 500000) };
  });

  function orderView(o, role = 'customer') {
    const items = db.all('SELECT product_id,name,price_paise,qty FROM order_items WHERE order_id=?', o.id);
    const events = db.all('SELECT status,note,created_at FROM order_events WHERE order_id=? ORDER BY id', o.id);
    const shop = db.get('SELECT id,name,logo_url,address,phone,lat,lng FROM shops WHERE id=?', o.shop_id);
    const out = { id: o.id, number: o.number, status: o.status, payment_method: o.payment_method, payment_status: o.payment_status, subtotal_paise: o.subtotal_paise, delivery_fee_paise: o.delivery_fee_paise, platform_fee_paise: o.platform_fee_paise, total_paise: o.total_paise,
      address: { name: o.addr_name, phone: o.addr_phone, line: o.addr_line, lat: o.addr_lat, lng: o.addr_lng }, note: o.note, cancel_reason: o.cancel_reason, created_at: o.created_at, delivered_at: o.delivered_at, shop, items, events, reviewed: !!db.get('SELECT 1 x FROM reviews WHERE order_id=?', o.id) };
    if (o.partner_id) { const p = db.get('SELECT u.name, u.mobile phone FROM users u WHERE u.id=?', o.partner_id); out.partner = { name: p.name, phone: p.phone }; }
    if (role === 'customer' && ['assigned', 'picked_up', 'out_for_delivery'].includes(o.status)) out.delivery_code = o.delivery_code;
    if (o.status === 'pending_payment' && o.payment_method === 'online') {
      const p = db.get("SELECT gateway_order_id, amount_paise FROM payments WHERE order_id=? AND method='online'", o.id);
      out.payment = { gateway: 'razorpay', key_id: gateway.keyId, gateway_order_id: p.gateway_order_id, amount_paise: p.amount_paise, currency: 'INR' };
    }
    return out;
  }

  r.post('/v1/customer/orders', C, async (ctx) => {
    const b = validate(ctx.body, { address_id: v.id(), payment_method: v.oneOf(['cod', 'online']), note: v.opt(v.str({ max: 300 })) });
    if (b.payment_method === 'online' && !gateway.configured) throw E.unavailable('Online payment is not available right now. Please choose Cash on Delivery.');
    const idem = ctx.req.headers['idempotency-key'] ? String(ctx.req.headers['idempotency-key']).slice(0, 80) : null;
    if (!limiter.hit('order:' + ctx.user.id, 20, 3600000)) throw E.tooMany();
    const { orderId, replay } = domain.createOrder(ctx.user.id, { addressId: b.address_id, paymentMethod: b.payment_method, note: b.note, idempotencyKey: idem });
    if (!replay) {
      if (b.payment_method === 'online') await domain.startOnlinePayment(orderId);
      else domain.emitOrderUpdate(db.get('SELECT * FROM orders WHERE id=?', orderId), { role: 'customer', id: ctx.user.id });
    }
    ctx.status = replay ? 200 : 201;
    return orderView(db.get('SELECT * FROM orders WHERE id=?', orderId));
  });
  r.get('/v1/customer/orders', C, (ctx) => {
    const { limit, offset } = page(ctx.query, 20);
    const st = ctx.query.get('status');
    const rows = db.all(`SELECT o.*, s.name shop_name, s.logo_url shop_logo FROM orders o JOIN shops s ON s.id=o.shop_id WHERE o.customer_id=? ${st ? 'AND o.status=?' : ''} ORDER BY o.created_at DESC LIMIT ? OFFSET ?`, ctx.user.id, ...(st ? [st] : []), limit, offset);
    return { items: rows.map(o => ({ id: o.id, number: o.number, status: o.status, total_paise: o.total_paise, payment_method: o.payment_method, payment_status: o.payment_status, shop_name: o.shop_name, shop_logo: o.shop_logo, created_at: o.created_at, item_count: db.get('SELECT SUM(qty) c FROM order_items WHERE order_id=?', o.id).c })) };
  });
  const own = ctx => { const o = db.get('SELECT * FROM orders WHERE id=? AND customer_id=?', ctx.params.id, ctx.user.id); if (!o) throw E.notFound('Order not found'); return o; };
  r.get('/v1/customer/orders/:id', C, (ctx) => orderView(own(ctx)));
  r.post('/v1/customer/orders/:id/cancel', C, async (ctx) => {
    const b = validate(ctx.body ?? {}, { reason: v.opt(v.str({ max: 200 })) });
    const o = own(ctx);
    await domain.transition(o.id, 'cancelled', { id: ctx.user.id, role: 'customer' }, { note: b.reason ?? 'Cancelled by customer' });
    return orderView(db.get('SELECT * FROM orders WHERE id=?', o.id));
  });
  r.post('/v1/customer/orders/:id/reorder', C, (ctx) => {
    const o = own(ctx), added = [], skipped = [];
    db.tx(() => {
      db.run('DELETE FROM cart_items WHERE customer_id=?', ctx.user.id);
      db.run('INSERT INTO carts(customer_id,shop_id) VALUES (?,NULL) ON CONFLICT(customer_id) DO NOTHING', ctx.user.id);
      for (const it of db.all('SELECT * FROM order_items WHERE order_id=?', o.id)) {
        const p = db.get('SELECT * FROM products WHERE id=? AND deleted_at IS NULL AND is_blocked=0 AND is_available=1 AND stock_qty>0', it.product_id);
        if (!p) { skipped.push(it.name); continue; }
        const q = Math.min(it.qty, p.stock_qty);
        db.run('INSERT INTO cart_items(customer_id,product_id,qty) VALUES (?,?,?)', ctx.user.id, p.id, q); added.push({ name: p.name, qty: q });
      }
      db.run('UPDATE carts SET shop_id=? WHERE customer_id=?', added.length ? o.shop_id : null, ctx.user.id);
    });
    return { added, skipped, cart: cartView(ctx.user.id) };
  });

  // ----- tracking (real GPS posted by the assigned delivery partner) -----
  r.get('/v1/customer/orders/:id/tracking', C, (ctx) => {
    const o = own(ctx);
    const shop = db.get('SELECT name,lat,lng FROM shops WHERE id=?', o.shop_id);
    const base = { order_status: o.status, shop: { name: shop.name, lat: shop.lat, lng: shop.lng }, destination: { lat: o.addr_lat, lng: o.addr_lng } };
    if (!['assigned', 'picked_up', 'out_for_delivery'].includes(o.status)) return { ...base, live: false };
    const last = db.get('SELECT lat,lng,accuracy_m,speed_mps,heading,recorded_at FROM delivery_tracking WHERE order_id=? ORDER BY id DESC LIMIT 1', o.id);
    const trail = db.all('SELECT lat,lng FROM (SELECT id,lat,lng FROM delivery_tracking WHERE order_id=? ORDER BY id DESC LIMIT 60) ORDER BY id', o.id);
    return { ...base, live: !!last, partner_location: last ?? null, trail };
  });

  // ----- payment verification (never reports success unless gateway confirms) -----
  r.post('/v1/customer/payments/verify', C, async (ctx) => {
    const b = validate(ctx.body, { order_id: v.id(), razorpay_order_id: v.str({ max: 64 }), razorpay_payment_id: v.str({ max: 64 }), razorpay_signature: v.str({ max: 128 }) });
    const o = own({ params: { id: b.order_id }, user: ctx.user });
    const p = db.get("SELECT * FROM payments WHERE order_id=? AND method='online'", o.id);
    if (!p || p.gateway_order_id !== b.razorpay_order_id) throw E.bad('Payment does not belong to this order');
    if (!gateway.verifyCheckoutSignature(b.razorpay_order_id, b.razorpay_payment_id, b.razorpay_signature)) throw E.bad('Payment signature verification failed');
    if (p.status === 'paid') return { status: 'paid', order: orderView(db.get('SELECT * FROM orders WHERE id=?', o.id)) };
    let gp = await gateway.fetchPayment(b.razorpay_payment_id);
    if (gp.order_id !== p.gateway_order_id || gp.amount !== p.amount_paise || gp.currency !== 'INR') throw E.bad('Payment details do not match this order');
    if (gp.status === 'authorized') gp = await gateway.capture(b.razorpay_payment_id, p.amount_paise);
    if (gp.status === 'failed') { domain.recordPaymentFailure(p.gateway_order_id, gp.error_description); throw new (await import('../lib/http.js')).ApiError(402, 'payment_failed', 'Payment failed. You can retry.'); }
    if (gp.status !== 'captured') throw E.conflict('Payment is not confirmed yet. We will update your order automatically.', 'payment_pending');
    const res = await domain.afterPayment(domain.applyCaptured({ gatewayOrderId: p.gateway_order_id, gatewayPaymentId: b.razorpay_payment_id, amountPaise: gp.amount }));
    return { status: 'paid', order: orderView(db.get('SELECT * FROM orders WHERE id=?', o.id)) };
  });

  // ----- reviews -----
  r.post('/v1/customer/orders/:id/review', C, (ctx) => {
    const b = validate(ctx.body, { shop_rating: v.int({ min: 1, max: 5 }), partner_rating: v.opt(v.int({ min: 1, max: 5 })), comment: v.opt(v.str({ max: 500 })) });
    const o = own(ctx);
    if (o.status !== 'delivered') throw E.conflict('You can review only delivered orders', 'not_delivered');
    db.tx(() => {
      db.run('INSERT INTO reviews(id,order_id,customer_id,shop_id,shop_rating,partner_rating,comment) VALUES (?,?,?,?,?,?,?)', uid(), o.id, ctx.user.id, o.shop_id, b.shop_rating, b.partner_rating ?? null, b.comment ?? null);
      db.run('UPDATE shops SET rating_count=rating_count+1, rating_avg=ROUND((rating_avg*rating_count+?)/(rating_count+1),2) WHERE id=?', b.shop_rating, o.shop_id);
    });
    ctx.status = 201; return { ok: true };
  });
  r.get('/v1/shops/:id/reviews', C, (ctx) => ({ items: db.all('SELECT r.shop_rating rating, r.comment, r.created_at, u.name customer FROM reviews r JOIN users u ON u.id=r.customer_id WHERE r.shop_id=? ORDER BY r.created_at DESC LIMIT 50', ctx.params.id) }));

  A.orderView = orderView;
}

import { uid, nowIso } from '../db.js';
import { E, v, validate, page } from '../lib/http.js';
import { istRange } from '../lib/dates.js';

const PUB = /^\/uploads\/[a-f0-9-]{36}\.(jpg|png|webp)$/;
const UPI = /^[\w.\-]{2,}@[a-zA-Z]{2,}$/;

export function registerSeller(r, A) {
  const { db, domain, auth, enc, notifyAdmins, audit } = A;
  const S = auth('seller');
  const shopOf = ctx => { const s = db.get('SELECT * FROM shops WHERE seller_id=?', ctx.user.id); if (!s) throw E.notFound('Register your shop first'); return s; };
  const shopSchema = { name: v.str({ max: 80 }), description: v.opt(v.str({ max: 500 })), address: v.str({ max: 250 }), village: v.opt(v.str({ max: 80 })), pincode: v.opt(v.str({ re: /^\d{6}$/ })), lat: v.lat(), lng: v.lng(), phone: v.opt(v.mobile()), opens_min: v.opt(v.int({ min: 0, max: 1439 })), closes_min: v.opt(v.int({ min: 0, max: 1439 })), min_order_paise: v.opt(v.int({ min: 0, max: 5000000 })), logo_url: v.opt(v.str({ re: PUB })), cover_url: v.opt(v.str({ re: PUB })), category_ids: v.opt(v.arr(v.id(), { max: 10 })) };

  const shopView = s => ({ ...s, categories: db.all('SELECT c.id,c.name FROM categories c JOIN shop_categories sc ON sc.category_id=c.id WHERE sc.shop_id=?', s.id), available_products: domain.availableProductCount(s.id), open_now: domain.shopOpenNow(s) && domain.availableProductCount(s.id) > 0 });
  function setCats(shopId, ids) {
    for (const cid of ids) if (!db.get("SELECT 1 x FROM categories WHERE id=? AND is_active=1", cid)) throw E.bad(`Unknown category ${cid}`);
    db.run('DELETE FROM shop_categories WHERE shop_id=?', shopId);
    for (const cid of ids) db.run('INSERT OR IGNORE INTO shop_categories(shop_id,category_id) VALUES (?,?)', shopId, cid);
  }

  r.patch('/v1/seller/profile', S, (ctx) => {
    const b = validate(ctx.body, { business_name: v.opt(v.str({ max: 100 })), gstin: v.opt(v.str({ re: /^[0-9A-Z]{15}$/ })), fssai_no: v.opt(v.str({ re: /^\d{14}$/ })), payout_upi: v.opt(v.str({ re: UPI, max: 80 })) });
    db.run('UPDATE sellers SET business_name=COALESCE(?,business_name), gstin=COALESCE(?,gstin), fssai_no=COALESCE(?,fssai_no), payout_upi_enc=COALESCE(?,payout_upi_enc) WHERE user_id=?', b.business_name ?? null, b.gstin ?? null, b.fssai_no ?? null, b.payout_upi ? enc.encrypt(b.payout_upi) : null, ctx.user.id);
    return { ok: true };
  });
  r.get('/v1/seller/profile', S, (ctx) => { const s = db.get('SELECT * FROM sellers WHERE user_id=?', ctx.user.id); return { business_name: s.business_name, gstin: s.gstin, fssai_no: s.fssai_no, payout_upi: s.payout_upi_enc ? enc.decrypt(s.payout_upi_enc) : null }; });

  // ----- shop -----
  r.post('/v1/seller/shop', S, (ctx) => {
    const b = validate(ctx.body, shopSchema);
    if (db.get('SELECT 1 x FROM shops WHERE seller_id=?', ctx.user.id)) throw E.conflict('You already registered a shop', 'shop_exists');
    const id = uid();
    db.tx(() => {
      db.run('INSERT INTO shops(id,seller_id,name,description,logo_url,cover_url,address,village,pincode,lat,lng,phone,opens_min,closes_min,min_order_paise) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', id, ctx.user.id, b.name, b.description ?? null, b.logo_url ?? null, b.cover_url ?? null, b.address, b.village ?? null, b.pincode ?? null, b.lat, b.lng, b.phone ?? ctx.user.mobile, b.opens_min ?? null, b.closes_min ?? null, b.min_order_paise ?? 0);
      setCats(id, b.category_ids ?? []);
    });
    notifyAdmins('shop_pending', 'New shop awaiting approval', b.name, { shop_id: id });
    ctx.status = 201; return shopView(db.get('SELECT * FROM shops WHERE id=?', id));
  });
  r.get('/v1/seller/shop', S, (ctx) => shopView(shopOf(ctx)));
  r.patch('/v1/seller/shop', S, (ctx) => {
    const sch = Object.fromEntries(Object.entries(shopSchema).map(([k, f]) => [k, f.optional ? f : v.opt(f)]));
    const b = validate(ctx.body, sch), s = shopOf(ctx), m = { ...s, ...b };
    db.tx(() => {
      db.run('UPDATE shops SET name=?,description=?,logo_url=?,cover_url=?,address=?,village=?,pincode=?,lat=?,lng=?,phone=?,opens_min=?,closes_min=?,min_order_paise=?,updated_at=? WHERE id=?', m.name, m.description, m.logo_url, m.cover_url, m.address, m.village, m.pincode, m.lat, m.lng, m.phone, m.opens_min, m.closes_min, m.min_order_paise, nowIso(), s.id);
      if (b.category_ids) setCats(s.id, b.category_ids);
    });
    return shopView(db.get('SELECT * FROM shops WHERE id=?', s.id));
  });
  r.post('/v1/seller/shop/status', S, (ctx) => {
    const b = validate(ctx.body, { is_online: v.bool() }), s = shopOf(ctx);
    if (b.is_online) {
      if (s.approval_status !== 'approved') throw E.conflict('Your shop is not approved yet', 'not_approved');
      if (domain.availableProductCount(s.id) === 0) throw E.conflict('Add at least one in-stock product before going online', 'no_products');
    }
    db.run('UPDATE shops SET is_online=?, updated_at=? WHERE id=?', b.is_online ? 1 : 0, nowIso(), s.id);
    return shopView(db.get('SELECT * FROM shops WHERE id=?', s.id));
  });

  // ----- products -----
  const prodSchema = { name: v.str({ max: 120 }), description: v.opt(v.str({ max: 1000 })), price_paise: v.int({ min: 100, max: 10000000 }), stock_qty: v.int({ min: 0, max: 100000 }), category_id: v.opt(v.id()), image_url: v.opt(v.str({ re: PUB })), is_available: v.opt(v.bool()) };
  const PF = 'id,name,description,image_url,price_paise,stock_qty,is_available,is_blocked,category_id,created_at,updated_at';
  const prodOf = ctx => { const p = db.get(`SELECT p.* FROM products p JOIN shops s ON s.id=p.shop_id WHERE p.id=? AND s.seller_id=? AND p.deleted_at IS NULL`, ctx.params.id, ctx.user.id); if (!p) throw E.notFound('Product not found'); return p; };
  const checkCat = id => { if (id && !db.get('SELECT 1 x FROM categories WHERE id=? AND is_active=1', id)) throw E.bad('Unknown category'); };
  r.get('/v1/seller/products', S, (ctx) => ({ items: db.all(`SELECT ${PF} FROM products WHERE shop_id=? AND deleted_at IS NULL ORDER BY name`, shopOf(ctx).id) }));
  r.post('/v1/seller/products', S, (ctx) => {
    const b = validate(ctx.body, prodSchema), s = shopOf(ctx); checkCat(b.category_id);
    if (db.get('SELECT COUNT(*) c FROM products WHERE shop_id=? AND deleted_at IS NULL', s.id).c >= 2000) throw E.conflict('Product limit reached', 'limit');
    const id = uid();
    db.tx(() => { db.run('INSERT INTO products(id,shop_id,category_id,name,description,image_url,price_paise,is_available,stock_qty) VALUES (?,?,?,?,?,?,?,?,?)', id, s.id, b.category_id ?? null, b.name, b.description ?? null, b.image_url ?? null, b.price_paise, b.is_available === false ? 0 : 1, b.stock_qty);
      if (b.stock_qty) db.run('INSERT INTO stock_movements(product_id,delta,reason) VALUES (?,?,?)', id, b.stock_qty, 'initial'); });
    ctx.status = 201; return db.get(`SELECT ${PF} FROM products WHERE id=?`, id);
  });
  r.patch('/v1/seller/products/:id', S, (ctx) => {
    const sch = Object.fromEntries(Object.entries(prodSchema).filter(([k]) => k !== 'stock_qty').map(([k, f]) => [k, f.optional ? f : v.opt(f)]));
    const b = validate(ctx.body, sch), p = prodOf(ctx); checkCat(b.category_id); const m = { ...p, ...b };
    db.run('UPDATE products SET name=?,description=?,image_url=?,price_paise=?,category_id=?,is_available=?,updated_at=? WHERE id=?', m.name, m.description, m.image_url, m.price_paise, m.category_id, m.is_available === false || m.is_available === 0 ? 0 : 1, nowIso(), p.id);
    return db.get(`SELECT ${PF} FROM products WHERE id=?`, p.id);
  });
  r.patch('/v1/seller/products/:id/stock', S, (ctx) => {
    const b = validate(ctx.body, { stock_qty: v.opt(v.int({ min: 0, max: 100000 })), delta: v.opt(v.int({ min: -100000, max: 100000 })) });
    if ((b.stock_qty === undefined) === (b.delta === undefined)) throw E.invalid({ _: 'Provide exactly one of stock_qty or delta' });
    const p = prodOf(ctx);
    db.tx(() => {
      const next = b.stock_qty ?? p.stock_qty + b.delta;
      if (next < 0) throw E.conflict('Stock cannot go below zero', 'negative_stock');
      db.run('UPDATE products SET stock_qty=?, updated_at=? WHERE id=?', next, nowIso(), p.id);
      db.run('INSERT INTO stock_movements(product_id,delta,reason) VALUES (?,?,?)', p.id, next - p.stock_qty, 'seller_adjustment');
    });
    return db.get(`SELECT ${PF} FROM products WHERE id=?`, p.id);
  });
  r.del('/v1/seller/products/:id', S, (ctx) => {
    const p = prodOf(ctx);
    db.tx(() => { db.run('UPDATE products SET deleted_at=?, is_available=0 WHERE id=?', nowIso(), p.id); db.run('DELETE FROM cart_items WHERE product_id=?', p.id); });
    ctx.status = 204; return undefined;
  });

  // ----- orders -----
  const sellerOrder = ctx => { const o = db.get('SELECT o.* FROM orders o JOIN shops s ON s.id=o.shop_id WHERE o.id=? AND s.seller_id=?', ctx.params.id, ctx.user.id); if (!o) throw E.notFound('Order not found'); return o; };
  const sView = o => { const base = A.orderView(o, 'seller'); const c = db.get('SELECT name, mobile FROM users WHERE id=?', o.customer_id); return { ...base, customer: { name: c.name ?? o.addr_name, phone: o.addr_phone }, payment: undefined }; };
  r.get('/v1/seller/orders', S, (ctx) => {
    const s = shopOf(ctx), { limit, offset } = page(ctx.query, 30), st = ctx.query.get('status'), grp = ctx.query.get('group');
    const where = grp === 'active' ? "status IN ('placed','accepted','preparing','ready_for_pickup','assigned','picked_up','out_for_delivery')" : grp === 'completed' ? "status='delivered'" : grp === 'cancelled' ? "status IN ('cancelled','rejected')" : st ? 'status=?' : "status!='pending_payment'";
    const rows = db.all(`SELECT * FROM orders WHERE shop_id=? AND ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`, s.id, ...(!grp && st ? [st] : []), limit, offset);
    return { items: rows.map(sView) };
  });
  r.get('/v1/seller/orders/:id', S, (ctx) => sView(sellerOrder(ctx)));
  const act = (path, to, noteReq) => r.post(`/v1/seller/orders/:id/${path}`, S, async (ctx) => {
    const b = noteReq ? validate(ctx.body ?? {}, { reason: v.str({ max: 200 }) }) : {};
    const o = sellerOrder(ctx);
    await domain.transition(o.id, to, { id: ctx.user.id, role: 'seller' }, { note: b.reason });
    return sView(db.get('SELECT * FROM orders WHERE id=?', o.id));
  });
  act('accept', 'accepted'); act('reject', 'rejected', true); act('preparing', 'preparing'); act('ready', 'ready_for_pickup'); act('cancel', 'cancelled', true);

  // ----- reports -----
  r.get('/v1/seller/reports/sales', S, (ctx) => {
    const s = shopOf(ctx), [from, to] = istRange(ctx.query);
    const days = db.all(`SELECT date(o.delivered_at,'+330 minutes') day, COUNT(*) orders, SUM(o.subtotal_paise) gross_paise, SUM(c.shop_commission_paise) commission_paise, SUM(c.seller_earning_paise) net_paise
      FROM orders o JOIN commissions c ON c.order_id=o.id WHERE o.shop_id=? AND o.status='delivered' AND o.delivered_at>=? AND o.delivered_at<? GROUP BY day ORDER BY day`, s.id, from, to);
    const top = db.all(`SELECT oi.name, SUM(oi.qty) qty, SUM(oi.qty*oi.price_paise) revenue_paise FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.shop_id=? AND o.status='delivered' AND o.delivered_at>=? AND o.delivered_at<? GROUP BY oi.product_id ORDER BY qty DESC LIMIT 10`, s.id, from, to);
    const cancelled = db.get("SELECT COUNT(*) c FROM orders WHERE shop_id=? AND status IN ('cancelled','rejected') AND created_at>=? AND created_at<?", s.id, from, to).c;
    return { from, to, totals: { orders: days.reduce((a, d) => a + d.orders, 0), gross_paise: days.reduce((a, d) => a + d.gross_paise, 0), net_paise: days.reduce((a, d) => a + d.net_paise, 0), cancelled_orders: cancelled }, days, top_products: top };
  });
  const balance = (type, id) => ({ unsettled_paise: db.get('SELECT COALESCE(SUM(amount_paise),0) s FROM transactions WHERE payee_type=? AND payee_id=? AND settlement_id IS NULL', type, id).s,
    in_settlement_paise: db.get("SELECT COALESCE(SUM(t.amount_paise),0) s FROM transactions t JOIN settlements st ON st.id=t.settlement_id WHERE t.payee_type=? AND t.payee_id=? AND st.status='pending'", type, id).s,
    paid_out_paise: db.get("SELECT COALESCE(SUM(t.amount_paise),0) s FROM transactions t JOIN settlements st ON st.id=t.settlement_id WHERE t.payee_type=? AND t.payee_id=? AND st.status='paid'", type, id).s });
  r.get('/v1/seller/reports/earnings', S, (ctx) => {
    shopOf(ctx); const [from, to] = istRange(ctx.query);
    return { ...balance('seller', ctx.user.id), entries: db.all("SELECT t.order_id, o.number, t.amount_paise, t.created_at, t.settlement_id IS NOT NULL settled FROM transactions t JOIN orders o ON o.id=t.order_id WHERE t.payee_type='seller' AND t.payee_id=? AND t.created_at>=? AND t.created_at<? ORDER BY t.id DESC LIMIT 200", ctx.user.id, from, to) };
  });
  r.get('/v1/seller/reports/payments', S, (ctx) => ({ items: db.all("SELECT id,amount_paise,status,reference,paid_at,created_at FROM settlements WHERE payee_type='seller' AND payee_id=? ORDER BY created_at DESC LIMIT 100", ctx.user.id) }));
  A.balance = balance;
}

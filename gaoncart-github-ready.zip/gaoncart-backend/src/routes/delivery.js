import fs from 'node:fs';
import path from 'node:path';
import { uid, nowIso, getIntSetting } from '../db.js';
import { E, v, validate, page } from '../lib/http.js';
import { haversineKm, bbox, safeEqual } from '../lib/security.js';
import { istRange, istTodayStart } from '../lib/dates.js';
import { ACTIVE_DELIVERY, MAX_ACTIVE_PER_PARTNER } from '../domain.js';

export function registerDelivery(r, A) {
  const { db, domain, auth, enc, hub, limiter, cfg, notify } = A;
  const D = auth('delivery');
  const partner = ctx => db.get('SELECT * FROM delivery_partners WHERE user_id=?', ctx.user.id);
  const needVerified = p => { if (p.verification_status !== 'verified') throw E.forbid('Your documents are not verified yet'); };

  r.get('/v1/delivery/profile', D, (ctx) => {
    const p = partner(ctx), u = db.get('SELECT name,mobile,photo_url FROM users WHERE id=?', ctx.user.id);
    return { ...u, vehicle_type: p.vehicle_type, vehicle_number: p.vehicle_number, verification_status: p.verification_status, rejection_reason: p.rejection_reason, is_online: !!p.is_online, payout_upi: p.payout_upi_enc ? enc.decrypt(p.payout_upi_enc) : null,
      documents: db.all('SELECT id,doc_type,status,created_at FROM partner_documents WHERE partner_id=?', ctx.user.id) };
  });
  r.put('/v1/delivery/profile', D, (ctx) => {
    const b = validate(ctx.body, { vehicle_type: v.oneOf(['bicycle', 'bike', 'scooter', 'other']), vehicle_number: v.opt(v.str({ max: 20, re: /^[A-Za-z0-9 -]{4,20}$/ })), payout_upi: v.opt(v.str({ re: /^[\w.\-]{2,}@[a-zA-Z]{2,}$/, max: 80 })), name: v.opt(v.str({ max: 80 })) });
    db.tx(() => { db.run('UPDATE delivery_partners SET vehicle_type=?, vehicle_number=COALESCE(?,vehicle_number), payout_upi_enc=COALESCE(?,payout_upi_enc) WHERE user_id=?', b.vehicle_type, b.vehicle_number ?? null, b.payout_upi ? enc.encrypt(b.payout_upi) : null, ctx.user.id);
      if (b.name) db.run('UPDATE users SET name=? WHERE id=?', b.name, ctx.user.id); });
    return { ok: true };
  });
  r.post('/v1/delivery/documents', D, (ctx) => {
    const b = validate(ctx.body, { doc_type: v.oneOf(['aadhaar', 'driving_licence', 'vehicle_rc', 'photo', 'other']), file_key: v.str({ max: 120, re: /^[A-Za-z0-9._-]+$/ }), doc_number: v.opt(v.str({ max: 30 })) });
    if (!b.file_key.startsWith(ctx.user.id + '_') || !fs.existsSync(path.join(cfg.privateUploadDir, b.file_key))) throw E.bad('Unknown file. Upload it first with kind=partner_doc.');
    const id = uid();
    db.tx(() => { db.run('INSERT INTO partner_documents(id,partner_id,doc_type,doc_number_enc,file_key) VALUES (?,?,?,?,?)', id, ctx.user.id, b.doc_type, enc.encrypt(b.doc_number), b.file_key);
      db.run("UPDATE delivery_partners SET verification_status='pending', rejection_reason=NULL WHERE user_id=? AND verification_status='rejected'", ctx.user.id); });
    A.notifyAdmins('partner_pending', 'Delivery partner documents submitted', ctx.user.name ?? ctx.user.mobile, { partner_id: ctx.user.id });
    ctx.status = 201; return { id };
  });

  r.post('/v1/delivery/status', D, (ctx) => {
    const b = validate(ctx.body, { is_online: v.bool() }), p = partner(ctx);
    if (b.is_online) needVerified(p);
    else if (db.get(`SELECT 1 x FROM orders WHERE partner_id=? AND status IN ('assigned','picked_up','out_for_delivery')`, ctx.user.id)) throw E.conflict('Finish your active deliveries before going offline', 'active_orders');
    db.run('UPDATE delivery_partners SET is_online=? WHERE user_id=?', b.is_online ? 1 : 0, ctx.user.id);
    return { is_online: b.is_online };
  });

  // Real GPS from the partner's device. Stored per active order and pushed live to the customer + shop.
  r.post('/v1/delivery/location', D, (ctx) => {
    const b = validate(ctx.body, { lat: v.lat(), lng: v.lng(), accuracy_m: v.opt(v.num({ min: 0, max: 100000 })), speed_mps: v.opt(v.num({ min: 0, max: 100 })), heading: v.opt(v.num({ min: 0, max: 360 })), recorded_at: v.opt(v.str({ max: 40 })) });
    if (!limiter.hit('loc:' + ctx.user.id, 90, 60000)) throw E.tooMany();
    let at = Date.now();
    if (b.recorded_at) { at = Date.parse(b.recorded_at); if (!Number.isFinite(at) || at > Date.now() + 60000 || at < Date.now() - 120000) throw E.invalid({ recorded_at: 'must be within the last 2 minutes' }); }
    const p = partner(ctx);
    const active = db.all(`SELECT o.id, o.customer_id, s.seller_id FROM orders o JOIN shops s ON s.id=o.shop_id WHERE o.partner_id=? AND o.status IN ('assigned','picked_up','out_for_delivery')`, ctx.user.id);
    if (!p.is_online && !active.length) throw E.conflict('Go online to share your location', 'offline');
    const iso = new Date(at).toISOString();
    db.tx(() => {
      db.run('UPDATE delivery_partners SET last_lat=?, last_lng=?, last_seen_at=? WHERE user_id=?', b.lat, b.lng, nowIso(), ctx.user.id);
      for (const o of active) db.run('INSERT INTO delivery_tracking(order_id,partner_id,lat,lng,accuracy_m,speed_mps,heading,recorded_at) VALUES (?,?,?,?,?,?,?,?)', o.id, ctx.user.id, b.lat, b.lng, b.accuracy_m ?? null, b.speed_mps ?? null, b.heading ?? null, iso);
    });
    for (const o of active) { const ev = { order_id: o.id, lat: b.lat, lng: b.lng, heading: b.heading ?? null, speed_mps: b.speed_mps ?? null, recorded_at: iso }; hub.publish(o.customer_id, 'tracking', ev); hub.publish(o.seller_id, 'tracking', ev); }
    ctx.status = 204; return undefined;
  });

  // ----- requests -----
  r.get('/v1/delivery/requests', D, (ctx) => {
    const p = partner(ctx); needVerified(p);
    if (!p.is_online) throw E.conflict('Go online to see delivery requests', 'offline');
    if (p.last_lat == null) throw E.conflict('Share your location to see nearby requests', 'location_required');
    const radius = getIntSetting(db, 'service_radius_km'), [a, b, c, d] = bbox(p.last_lat, p.last_lng, radius);
    const rows = db.all(`SELECT o.id,o.number,o.partner_earning_paise,o.payment_method,o.total_paise,o.addr_lat,o.addr_lng,o.created_at,o.ready_at,s.name shop_name,s.address shop_address,s.lat shop_lat,s.lng shop_lng
      FROM orders o JOIN shops s ON s.id=o.shop_id WHERE o.status='ready_for_pickup' AND o.partner_id IS NULL AND s.lat BETWEEN ? AND ? AND s.lng BETWEEN ? AND ? ORDER BY o.ready_at`, a, b, c, d);
    return { items: rows.map(o => ({ id: o.id, number: o.number, shop: { name: o.shop_name, address: o.shop_address, lat: o.shop_lat, lng: o.shop_lng }, pickup_distance_km: +haversineKm(p.last_lat, p.last_lng, o.shop_lat, o.shop_lng).toFixed(1), trip_km: +haversineKm(o.shop_lat, o.shop_lng, o.addr_lat, o.addr_lng).toFixed(1), earning_paise: o.partner_earning_paise, collect_cash_paise: o.payment_method === 'cod' ? o.total_paise : 0, ready_at: o.ready_at })).filter(o => o.pickup_distance_km <= radius) };
  });
  const pView = o => { const v0 = A.orderView(o, 'delivery'); delete v0.delivery_code; const sh = db.get('SELECT u.mobile FROM users u JOIN shops s ON s.seller_id=u.id WHERE s.id=?', o.shop_id); return { ...v0, shop_phone: sh?.mobile, earning_paise: o.partner_earning_paise, collect_cash_paise: o.payment_method === 'cod' ? o.total_paise : 0 }; };
  const mine = ctx => { const o = db.get('SELECT * FROM orders WHERE id=? AND partner_id=?', ctx.params.id, ctx.user.id); if (!o) throw E.notFound('Order not found'); return o; };

  r.post('/v1/delivery/orders/:id/accept', D, async (ctx) => {
    const p = partner(ctx); needVerified(p);
    if (!p.is_online) throw E.conflict('Go online first', 'offline');
    const n = db.get(`SELECT COUNT(*) c FROM orders WHERE partner_id=? AND status IN ('assigned','picked_up','out_for_delivery')`, ctx.user.id).c;
    if (n >= MAX_ACTIVE_PER_PARTNER) throw E.conflict(`You can carry at most ${MAX_ACTIVE_PER_PARTNER} orders at a time`, 'too_many_active');
    // Atomic claim: only one partner can win this UPDATE (see transitionTx: WHERE status AND partner_id IS NULL).
    await domain.transition(ctx.params.id, 'assigned', { id: ctx.user.id, role: 'delivery' }, { set: { partner_id: ctx.user.id }, unassignedOnly: true });
    return pView(mine(ctx));
  });
  const step = (p, to) => r.post(`/v1/delivery/orders/:id/${p}`, D, async (ctx) => {
    const o = mine(ctx);
    await domain.transition(o.id, to, { id: ctx.user.id, role: 'delivery' }, { requirePartner: true });
    return pView(mine(ctx));
  });
  step('pickup', 'picked_up'); step('out-for-delivery', 'out_for_delivery');
  r.post('/v1/delivery/orders/:id/deliver', D, async (ctx) => {
    const b = validate(ctx.body, { code: v.str({ re: /^\d{4}$/ }) }), o = mine(ctx);
    if (!limiter.hit('dcode:' + o.id, 5, 900000)) throw E.tooMany();
    if (!safeEqual(b.code, o.delivery_code)) throw E.bad('Incorrect delivery code. Ask the customer for the 4-digit code shown in their app.');
    await domain.transition(o.id, 'delivered', { id: ctx.user.id, role: 'delivery' }, { requirePartner: true });
    return pView(mine(ctx));
  });
  r.get('/v1/delivery/orders', D, (ctx) => {
    const { limit, offset } = page(ctx.query, 30), h = ctx.query.get('group') === 'history';
    const rows = db.all(`SELECT * FROM orders WHERE partner_id=? AND status ${h ? "IN ('delivered','cancelled')" : "IN ('assigned','picked_up','out_for_delivery')"} ORDER BY updated_at DESC LIMIT ? OFFSET ?`, ctx.user.id, limit, offset);
    return { items: rows.map(pView) };
  });
  r.get('/v1/delivery/orders/:id', D, (ctx) => pView(mine(ctx)));

  // ----- earnings -----
  r.get('/v1/delivery/earnings', D, (ctx) => {
    const [from, to] = istRange(ctx.query), today = istTodayStart();
    const sum = (q, ...p) => db.get(q, ...p).s;
    const bal = A.balance('partner', ctx.user.id);
    return { today_paise: sum("SELECT COALESCE(SUM(amount_paise),0) s FROM transactions WHERE payee_type='partner' AND payee_id=? AND kind='delivery_earning' AND created_at>=?", ctx.user.id, today),
      today_deliveries: db.get("SELECT COUNT(*) c FROM orders WHERE partner_id=? AND status='delivered' AND delivered_at>=?", ctx.user.id, today).c,
      total_paise: sum("SELECT COALESCE(SUM(amount_paise),0) s FROM transactions WHERE payee_type='partner' AND payee_id=? AND kind='delivery_earning'", ctx.user.id),
      cash_to_remit_paise: -sum("SELECT COALESCE(SUM(amount_paise),0) s FROM transactions WHERE payee_type='partner' AND payee_id=? AND kind='cod_cash_held' AND settlement_id IS NULL", ctx.user.id),
      ...bal, days: db.all("SELECT date(created_at,'+330 minutes') day, COUNT(*) deliveries, SUM(amount_paise) earned_paise FROM transactions WHERE payee_type='partner' AND payee_id=? AND kind='delivery_earning' AND created_at>=? AND created_at<? GROUP BY day ORDER BY day DESC", ctx.user.id, from, to) };
  });
  r.get('/v1/delivery/payments', D, (ctx) => ({ items: db.all("SELECT id,amount_paise,status,reference,paid_at,created_at FROM settlements WHERE payee_type='partner' AND payee_id=? ORDER BY created_at DESC LIMIT 100", ctx.user.id) }));
}

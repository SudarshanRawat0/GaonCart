import fs from 'node:fs';
import path from 'node:path';
import { uid, nowIso } from '../db.js';
import { E, ApiError, v, validate, page } from '../lib/http.js';
import { hashPassword, verifyPassword, signJwt, randomToken, sha256, hmacHex, safeEqual, otp } from '../lib/security.js';

const ACCESS_TTL = 15 * 60, REFRESH_TTL_DAYS = 30;
const PUBLIC_URL = /^\/uploads\/[a-f0-9-]{36}\.(jpg|png|webp)$/;
const DUMMY_HASH = 'scrypt$AAAAAAAAAAAAAAAAAAAAAA==$' + Buffer.alloc(64).toString('base64');

export function registerCommon(r, A) {
  const { db, cfg, auth, limiter, sms, hub, notify, enc } = A;

  function issueTokens(user, device) {
    const refresh = randomToken(48);
    db.run('INSERT INTO refresh_tokens(id,user_id,token_hash,device,expires_at) VALUES (?,?,?,?,?)', uid(), user.id, sha256(refresh), device ?? null, new Date(Date.now() + REFRESH_TTL_DAYS * 864e5).toISOString());
    return { access_token: signJwt({ sub: user.id, role: user.role, typ: 'access' }, cfg.jwtSecret, ACCESS_TTL), refresh_token: refresh, expires_in: ACCESS_TTL };
  }
  const publicUser = u => ({ id: u.id, role: u.role, name: u.name, mobile: u.mobile, email: u.email, photo_url: u.photo_url, status: u.status });

  r.get('/healthz', () => { A.db.get('SELECT 1'); return { ok: true, payments: A.gateway.configured, push: A.push.configured }; });

  // ---------- auth ----------
  r.post('/v1/auth/otp/request', async (ctx) => {
    const b = validate(ctx.body, { mobile: v.mobile(), role: v.oneOf(['customer', 'seller', 'delivery']) });
    if (!limiter.hit('otpip:' + ctx.ip, 30, 3600000)) throw E.tooMany();
    const u = db.get('SELECT status FROM users WHERE role=? AND mobile=?', b.role, b.mobile);
    if (u && u.status !== 'active') throw E.forbid('This account is not active. Contact support.');
    const last = db.get('SELECT created_at FROM otp_codes WHERE mobile=? AND role=? ORDER BY created_at DESC LIMIT 1', b.mobile, b.role);
    if (last && Date.now() - Date.parse(last.created_at) < 30000) throw E.tooMany();
    const hourAgo = new Date(Date.now() - 3600000).toISOString();
    if (db.get('SELECT COUNT(*) c FROM otp_codes WHERE mobile=? AND role=? AND created_at>?', b.mobile, b.role, hourAgo).c >= 5) throw E.tooMany();
    const code = otp(), id = uid();
    db.run('INSERT INTO otp_codes(id,mobile,role,code_hash,expires_at) VALUES (?,?,?,?,?)', id, b.mobile, b.role, hmacHex(cfg.jwtSecret, `${b.mobile}|${b.role}|${code}`), new Date(Date.now() + 5 * 60000).toISOString());
    try { await sms.sendOtp(b.mobile, code); } catch (e) { db.run('DELETE FROM otp_codes WHERE id=?', id); throw e; }
    return { sent: true, expires_in: 300 };
  });

  r.post('/v1/auth/otp/verify', (ctx) => {
    const b = validate(ctx.body, { mobile: v.mobile(), role: v.oneOf(['customer', 'seller', 'delivery']), code: v.str({ re: /^\d{6}$/ }), name: v.opt(v.str({ max: 80 })), device: v.opt(v.str({ max: 100 })) });
    if (!limiter.hit('verifyip:' + ctx.ip, 60, 3600000)) throw E.tooMany();
    const row = db.get('SELECT * FROM otp_codes WHERE mobile=? AND role=? AND consumed_at IS NULL ORDER BY created_at DESC LIMIT 1', b.mobile, b.role);
    if (!row || row.expires_at < nowIso()) throw E.bad('OTP expired or not requested');
    if (row.attempts >= 5) throw E.tooMany();
    db.run('UPDATE otp_codes SET attempts=attempts+1 WHERE id=?', row.id);
    if (!safeEqual(hmacHex(cfg.jwtSecret, `${b.mobile}|${b.role}|${b.code}`), row.code_hash)) throw new ApiError(401, 'invalid_otp', 'Incorrect OTP');
    return db.tx(() => {
      db.run('UPDATE otp_codes SET consumed_at=? WHERE id=?', nowIso(), row.id);
      let u = db.get('SELECT * FROM users WHERE role=? AND mobile=?', b.role, b.mobile), isNew = false;
      if (u && u.status !== 'active') throw E.forbid('This account is not active. Contact support.');
      if (!u) {
        const id = uid(); isNew = true;
        db.run('INSERT INTO users(id,role,mobile,name) VALUES (?,?,?,?)', id, b.role, b.mobile, b.name ?? null);
        if (b.role === 'customer') db.run('INSERT INTO customers(user_id) VALUES (?)', id);
        if (b.role === 'seller') db.run('INSERT INTO sellers(user_id) VALUES (?)', id);
        if (b.role === 'delivery') db.run('INSERT INTO delivery_partners(user_id) VALUES (?)', id);
        u = db.get('SELECT * FROM users WHERE id=?', id);
      }
      return { is_new_user: isNew, user: publicUser(u), ...issueTokens(u, b.device) };
    });
  });

  r.post('/v1/auth/admin/login', async (ctx) => {
    const b = validate(ctx.body, { email: v.str({ max: 120, re: /^[^@\s]+@[^@\s]+\.[^@\s]+$/ }), password: v.str({ min: 1, max: 200, trim: false }) });
    const email = b.email.toLowerCase();
    if (!limiter.hit('admin:' + ctx.ip, 20, 900000) || !limiter.hit('admin:' + email, 10, 900000)) throw E.tooMany();
    const u = db.get("SELECT * FROM users WHERE role='admin' AND email=?", email);
    const ok = await verifyPassword(b.password, u?.password_hash || DUMMY_HASH);
    if (!u || !ok || u.status !== 'active') throw E.unauth('Invalid email or password');
    return { user: publicUser(u), admin_level: db.get('SELECT level FROM admins WHERE user_id=?', u.id)?.level, ...issueTokens(u, 'admin-web') };
  });

  r.post('/v1/auth/refresh', (ctx) => {
    const b = validate(ctx.body, { refresh_token: v.str({ min: 20, max: 200 }) });
    const t = db.get('SELECT * FROM refresh_tokens WHERE token_hash=?', sha256(b.refresh_token));
    if (!t) throw E.unauth('Invalid refresh token');
    if (t.revoked_at) { // reuse of a rotated token: revoke the whole family (outside any transaction so it is not rolled back)
      db.run('UPDATE refresh_tokens SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL', nowIso(), t.user_id);
      throw E.unauth('Refresh token reuse detected; please log in again');
    }
    if (t.expires_at < nowIso()) throw E.unauth('Session expired');
    const u = db.get('SELECT * FROM users WHERE id=?', t.user_id);
    if (!u || u.status !== 'active') throw E.unauth('Account is not active');
    return db.tx(() => {
      const x = db.run('UPDATE refresh_tokens SET revoked_at=? WHERE id=? AND revoked_at IS NULL', nowIso(), t.id);
      if (!x.changes) throw E.unauth('Refresh token already used');
      return issueTokens(u, t.device);
    });
  });
  r.post('/v1/auth/logout', (ctx) => {
    const b = validate(ctx.body, { refresh_token: v.str({ min: 20, max: 200 }) });
    db.run('UPDATE refresh_tokens SET revoked_at=? WHERE token_hash=? AND revoked_at IS NULL', nowIso(), sha256(b.refresh_token));
    ctx.status = 204; return undefined;
  });

  // ---------- profile ----------
  r.get('/v1/me', auth(), (ctx) => publicUser(db.get('SELECT * FROM users WHERE id=?', ctx.user.id)));
  r.patch('/v1/me', auth(), (ctx) => {
    const b = validate(ctx.body, { name: v.opt(v.str({ max: 80 })), photo_url: v.opt(v.str({ re: PUBLIC_URL, max: 100 })) });
    db.run('UPDATE users SET name=COALESCE(?,name), photo_url=COALESCE(?,photo_url), updated_at=? WHERE id=?', b.name ?? null, b.photo_url ?? null, nowIso(), ctx.user.id);
    return publicUser(db.get('SELECT * FROM users WHERE id=?', ctx.user.id));
  });
  // Account deletion (DPDP Act right to erasure). Orders/ledger rows are retained, de-identified, for tax/accounting law.
  r.del('/v1/me', auth('customer', 'seller', 'delivery'), (ctx) => {
    const id = ctx.user.id, role = ctx.user.role;
    const open = "('pending_payment','placed','accepted','preparing','ready_for_pickup','assigned','picked_up','out_for_delivery')";
    const n = role === 'customer' ? db.get(`SELECT COUNT(*) c FROM orders WHERE customer_id=? AND status IN ${open}`, id).c
      : role === 'seller' ? db.get(`SELECT COUNT(*) c FROM orders o JOIN shops s ON s.id=o.shop_id WHERE s.seller_id=? AND o.status IN ${open}`, id).c
      : db.get(`SELECT COUNT(*) c FROM orders WHERE partner_id=? AND status IN ${open}`, id).c;
    if (n > 0) throw E.conflict('You have active orders. Complete or cancel them before deleting your account.', 'active_orders');
    const unsettled = db.get("SELECT COALESCE(SUM(amount_paise),0) s FROM transactions WHERE payee_id=? AND settlement_id IS NULL", id).s;
    if (unsettled !== 0) throw E.conflict('You have an unsettled balance. Contact support to settle it before deleting your account.', 'unsettled_balance');
    db.tx(() => {
      db.run("UPDATE users SET status='deleted', name='Deleted user', mobile=NULL, email=NULL, photo_url=NULL, updated_at=? WHERE id=?", nowIso(), id);
      db.run('UPDATE refresh_tokens SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL', nowIso(), id);
      db.run('DELETE FROM device_tokens WHERE user_id=?', id); db.run('DELETE FROM addresses WHERE user_id=?', id);
      db.run('DELETE FROM cart_items WHERE customer_id=?', id); db.run('DELETE FROM carts WHERE customer_id=?', id);
      if (role === 'seller') { db.run("UPDATE shops SET is_online=0, approval_status='suspended' WHERE seller_id=?", id); db.run('UPDATE sellers SET gstin=NULL, fssai_no=NULL, payout_upi_enc=NULL WHERE user_id=?', id); }
      if (role === 'delivery') { db.run('UPDATE delivery_partners SET is_online=0, last_lat=NULL, last_lng=NULL, payout_upi_enc=NULL WHERE user_id=?', id);
        for (const d of db.all('SELECT file_key FROM partner_documents WHERE partner_id=?', id)) fs.rmSync(path.join(cfg.privateUploadDir, path.basename(d.file_key)), { force: true });
        db.run('DELETE FROM partner_documents WHERE partner_id=?', id); }
      A.audit(id, 'account_deleted', 'user', id);
    });
    ctx.status = 204; return undefined;
  });
  r.post('/v1/me/devices', auth(), (ctx) => {
    const b = validate(ctx.body, { token: v.str({ min: 20, max: 4096 }), platform: v.oneOf(['android', 'ios', 'web']) });
    db.run('INSERT INTO device_tokens(id,user_id,token,platform) VALUES (?,?,?,?) ON CONFLICT(token) DO UPDATE SET user_id=excluded.user_id, platform=excluded.platform, updated_at=?', uid(), ctx.user.id, b.token, b.platform, nowIso());
    ctx.status = 204; return undefined;
  });

  // ---------- notifications + realtime ----------
  r.get('/v1/notifications', auth(), (ctx) => {
    const { limit, offset } = page(ctx.query, 30);
    const unread = ctx.query.get('unread') === '1' ? 'AND read_at IS NULL' : '';
    const rows = db.all(`SELECT id,type,title,body,data,read_at,created_at FROM notifications WHERE user_id=? ${unread} ORDER BY created_at DESC LIMIT ? OFFSET ?`, ctx.user.id, limit, offset).map(n => ({ ...n, data: JSON.parse(n.data || '{}') }));
    return { items: rows, unread_count: db.get('SELECT COUNT(*) c FROM notifications WHERE user_id=? AND read_at IS NULL', ctx.user.id).c };
  });
  r.post('/v1/notifications/read-all', auth(), (ctx) => { db.run('UPDATE notifications SET read_at=? WHERE user_id=? AND read_at IS NULL', nowIso(), ctx.user.id); ctx.status = 204; return undefined; });
  r.post('/v1/notifications/:id/read', auth(), (ctx) => { db.run('UPDATE notifications SET read_at=? WHERE id=? AND user_id=?', nowIso(), ctx.params.id, ctx.user.id); ctx.status = 204; return undefined; });
  r.get('/v1/stream', auth(), (ctx) => { hub.add(ctx.req, ctx.res, ctx.user.id, ctx.user.role); ctx.responded = true; });

  // ---------- uploads ----------
  const sniff = b => b.length > 12 && (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff ? 'jpg' : b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) ? 'png' : b.subarray(0, 4).toString() === 'RIFF' && b.subarray(8, 12).toString() === 'WEBP' ? 'webp' : null);
  r.post('/v1/uploads', auth(), (ctx) => {
    const kind = ctx.query.get('kind');
    if (!['product', 'logo', 'cover', 'profile', 'partner_doc'].includes(kind)) throw E.bad('kind must be product|logo|cover|profile|partner_doc');
    const need = { product: 'seller', logo: 'seller', cover: 'seller', partner_doc: 'delivery' }[kind];
    if (need && ctx.user.role !== need) throw E.forbid();
    if (!limiter.hit('upl:' + ctx.user.id, 40, 3600000)) throw E.tooMany();
    const buf = ctx.raw;
    if (!buf?.length) throw E.bad('Empty upload');
    const ext = sniff(buf);
    if (!ext) throw E.bad('Only JPEG, PNG or WebP images are accepted');
    if (kind === 'partner_doc') {
      fs.mkdirSync(cfg.privateUploadDir, { recursive: true });
      const key = `${ctx.user.id}_${uid()}.${ext}`;
      fs.writeFileSync(path.join(cfg.privateUploadDir, key), buf, { mode: 0o600 });
      ctx.status = 201; return { file_key: key };
    }
    fs.mkdirSync(cfg.uploadDir, { recursive: true });
    const name = `${uid()}.${ext}`;
    fs.writeFileSync(path.join(cfg.uploadDir, name), buf);
    ctx.status = 201; return { url: `/uploads/${name}` };
  });
  r.get('/uploads/:name', (ctx) => {
    if (!/^[a-f0-9-]{36}\.(jpg|png|webp)$/.test(ctx.params.name)) throw E.notFound();
    const f = path.join(cfg.uploadDir, ctx.params.name);
    if (!fs.existsSync(f)) throw E.notFound();
    const type = { jpg: 'image/jpeg', png: 'image/png', webp: 'image/webp' }[ctx.params.name.split('.')[1]];
    ctx.res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'public, max-age=31536000, immutable', 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "default-src 'none'" });
    ctx.res.end(fs.readFileSync(f)); ctx.responded = true;
  });

  // ---------- public data ----------
  r.get('/v1/categories', (ctx) => {
    const kind = ctx.query.get('kind');
    return { items: db.all(`SELECT id,name,slug,icon_url,kind FROM categories WHERE is_active=1 ${kind ? 'AND kind=?' : ''} ORDER BY sort_order,name`, ...(kind ? [kind] : [])) };
  });
  r.get('/v1/banners', () => ({ items: db.all(`SELECT id,title,subtitle,image_url,shop_id,category_id FROM banners WHERE is_active=1
    AND (starts_at IS NULL OR starts_at<=?) AND (ends_at IS NULL OR ends_at>?) ORDER BY sort_order, created_at DESC LIMIT 10`, nowIso(), nowIso()) }));
  r.get('/v1/content/:key', (ctx) => { const c = db.get('SELECT key,title,body,updated_at FROM site_content WHERE key=?', ctx.params.key); if (!c) throw E.notFound(); return c; });

  // ---------- support tickets (all roles) ----------
  const ownsOrder = (user, orderId) => {
    const o = db.get('SELECT o.customer_id, o.partner_id, s.seller_id FROM orders o JOIN shops s ON s.id=o.shop_id WHERE o.id=?', orderId);
    return o && [o.customer_id, o.partner_id, o.seller_id].includes(user.id);
  };
  r.post('/v1/support/tickets', auth('customer', 'seller', 'delivery'), (ctx) => {
    const b = validate(ctx.body, { subject: v.str({ max: 150 }), body: v.str({ max: 3000 }), category: v.opt(v.oneOf(['general', 'order', 'payment', 'refund', 'delivery', 'account', 'complaint'])), order_id: v.opt(v.id()) });
    if (b.order_id && !ownsOrder(ctx.user, b.order_id)) throw E.notFound('Order not found');
    if (!limiter.hit('tkt:' + ctx.user.id, 10, 3600000)) throw E.tooMany();
    const id = uid();
    db.tx(() => { db.run('INSERT INTO support_tickets(id,user_id,order_id,subject,category) VALUES (?,?,?,?,?)', id, ctx.user.id, b.order_id ?? null, b.subject, b.category ?? 'general'); db.run('INSERT INTO ticket_messages(ticket_id,author_id,body) VALUES (?,?,?)', id, ctx.user.id, b.body); });
    A.notifyAdmins('ticket', 'New support ticket', b.subject, { ticket_id: id });
    ctx.status = 201; return { id };
  });
  r.get('/v1/support/tickets', auth('customer', 'seller', 'delivery'), (ctx) => ({ items: db.all('SELECT id,subject,status,category,order_id,created_at,updated_at FROM support_tickets WHERE user_id=? ORDER BY updated_at DESC LIMIT 100', ctx.user.id) }));
  r.get('/v1/support/tickets/:id', auth('customer', 'seller', 'delivery'), (ctx) => {
    const t = db.get('SELECT * FROM support_tickets WHERE id=? AND user_id=?', ctx.params.id, ctx.user.id);
    if (!t) throw E.notFound();
    return { ...t, messages: db.all('SELECT m.id,m.body,m.created_at,(u.role=\'admin\') AS from_support FROM ticket_messages m JOIN users u ON u.id=m.author_id WHERE ticket_id=? ORDER BY m.id', t.id) };
  });
  r.post('/v1/support/tickets/:id/messages', auth('customer', 'seller', 'delivery'), (ctx) => {
    const b = validate(ctx.body, { body: v.str({ max: 3000 }) });
    const t = db.get('SELECT * FROM support_tickets WHERE id=? AND user_id=?', ctx.params.id, ctx.user.id);
    if (!t) throw E.notFound();
    if (t.status === 'closed') throw E.conflict('Ticket is closed', 'ticket_closed');
    db.run('INSERT INTO ticket_messages(ticket_id,author_id,body) VALUES (?,?,?)', t.id, ctx.user.id, b.body);
    db.run("UPDATE support_tickets SET status='open', updated_at=? WHERE id=?", nowIso(), t.id);
    ctx.status = 201; return { ok: true };
  });
}

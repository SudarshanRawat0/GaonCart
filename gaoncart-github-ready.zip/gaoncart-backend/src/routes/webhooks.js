import { ApiError, E } from '../lib/http.js';
import { nowIso } from '../db.js';

export function registerWebhooks(r, A) {
  const { db, gateway, domain, audit } = A;
  // Razorpay -> server. Authenticity is proven by HMAC over the RAW body; amounts are re-checked against our own records.
  r.post('/v1/webhooks/razorpay', async (ctx) => {
    const sig = ctx.req.headers['x-razorpay-signature'];
    if (!gateway.verifyWebhookSignature(ctx.raw.toString('utf8'), sig)) throw new ApiError(401, 'bad_signature', 'Invalid signature');
    const eventId = String(ctx.req.headers['x-razorpay-event-id'] || '');
    if (!eventId) throw E.bad('Missing event id');
    if (db.get('SELECT 1 x FROM webhook_events WHERE id=?', eventId)) return { ok: true, duplicate: true };
    const ev = ctx.body, pay = ev?.payload?.payment?.entity, ref = ev?.payload?.refund?.entity;
    try {
      if (ev.event === 'payment.captured' && pay) {
        await domain.afterPayment(domain.applyCaptured({ gatewayOrderId: pay.order_id, gatewayPaymentId: pay.id, amountPaise: pay.amount }));
      } else if (ev.event === 'payment.failed' && pay) {
        domain.recordPaymentFailure(pay.order_id, pay.error_description);
      } else if (ev.event === 'refund.processed' && ref) {
        domain.markRefundProcessed(ref.id);
      } else if (ev.event === 'refund.failed' && ref) {
        db.run("UPDATE refunds SET failure_reason='gateway reported failure' WHERE gateway_refund_id=?", ref.id);
        db.run("UPDATE refunds SET status='failed' WHERE gateway_refund_id=? AND status='pending'", ref.id);
      }
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) audit(null, 'webhook_rejected', 'payment', pay?.id ?? ref?.id, { event: ev.event, reason: err.code }); // e.g. amount_mismatch: do not retry forever
      else throw err;
    }
    db.run('INSERT OR IGNORE INTO webhook_events(id,provider,event_type) VALUES (?,?,?)', eventId, 'razorpay', ev.event ?? null);
    return { ok: true };
  });
}

// Core marketplace domain logic: order lifecycle, stock, payments, refunds, commissions, ledger.
import { uid, nowIso, getIntSetting, getSetting } from './db.js';
import { E } from './lib/http.js';
import { deliveryCode, haversineKm, bbox } from './lib/security.js';

export const ACTIVE_DELIVERY = ['assigned', 'picked_up', 'out_for_delivery'];
export const MAX_ACTIVE_PER_PARTNER = 2;

// status -> { nextStatus: [roles allowed] }
export const TRANSITIONS = {
  pending_payment: { placed: ['system'], cancelled: ['customer', 'system', 'admin'] },
  placed: { accepted: ['seller'], rejected: ['seller'], cancelled: ['customer', 'admin'] },
  accepted: { preparing: ['seller'], cancelled: ['customer', 'seller', 'admin'] },
  preparing: { ready_for_pickup: ['seller'], cancelled: ['seller', 'admin'] },
  ready_for_pickup: { assigned: ['delivery'], cancelled: ['seller', 'admin'] },
  assigned: { picked_up: ['delivery'], cancelled: ['admin'] },
  picked_up: { out_for_delivery: ['delivery'], cancelled: ['admin'] },
  out_for_delivery: { delivered: ['delivery'], cancelled: ['admin'] },
};
const TS_COL = { accepted: 'accepted_at', ready_for_pickup: 'ready_at', assigned: 'assigned_at', picked_up: 'picked_up_at', delivered: 'delivered_at', cancelled: 'cancelled_at', rejected: 'cancelled_at' };

export function istMinutes(tzOffsetMin = 330, d = new Date()) {
  const t = new Date(d.getTime() + tzOffsetMin * 60000);
  return t.getUTCHours() * 60 + t.getUTCMinutes();
}
export function withinHours(opens, closes, nowMin) {
  if (opens == null || closes == null) return true;
  return opens <= closes ? nowMin >= opens && nowMin < closes : nowMin >= opens || nowMin < closes;
}

export function makeDomain({ db, hub, notify, gateway, cfg }) {
  const num = k => getIntSetting(db, k);
  const nowMin = () => istMinutes(cfg.tzOffsetMin);
  const shopOpenNow = s => s.approval_status === 'approved' && s.is_online === 1 && withinHours(s.opens_min, s.closes_min, nowMin());
  const availableProductCount = shopId => db.get('SELECT COUNT(*) c FROM products WHERE shop_id=? AND deleted_at IS NULL AND is_blocked=0 AND is_available=1 AND stock_qty>0', shopId).c;

  // ---------- order creation ----------
  function quote(customerId, addressId) {
    const cart = db.get('SELECT shop_id FROM carts WHERE customer_id=?', customerId);
    const items = db.all(`SELECT ci.qty, p.id product_id, p.name, p.price_paise, p.stock_qty, p.is_available, p.is_blocked, p.deleted_at, p.shop_id
      FROM cart_items ci JOIN products p ON p.id=ci.product_id WHERE ci.customer_id=?`, customerId);
    if (!cart?.shop_id || !items.length) throw E.bad('Your cart is empty');
    const shop = db.get('SELECT s.*, u.status seller_status FROM shops s JOIN users u ON u.id=s.seller_id WHERE s.id=?', cart.shop_id);
    if (!shop || !shopOpenNow(shop) || shop.seller_status !== 'active') throw E.conflict('This shop is currently not accepting orders', 'shop_unavailable');
    const addr = db.get('SELECT * FROM addresses WHERE id=? AND user_id=? AND deleted_at IS NULL', addressId, customerId);
    if (!addr) throw E.notFound('Address not found');
    const km = haversineKm(shop.lat, shop.lng, addr.lat, addr.lng);
    if (km > num('service_radius_km')) throw E.conflict(`This shop does not deliver to your address (${km.toFixed(1)} km away)`, 'out_of_range');
    for (const it of items) {
      if (it.deleted_at || it.is_blocked || !it.is_available || it.stock_qty < it.qty || it.shop_id !== shop.id)
        throw E.conflict(`"${it.name}" is not available in the requested quantity`, 'out_of_stock');
    }
    const subtotal = items.reduce((s, i) => s + i.price_paise * i.qty, 0);
    if (subtotal < shop.min_order_paise) throw E.conflict(`Minimum order for this shop is ₹${(shop.min_order_paise / 100).toFixed(0)}`, 'min_order');
    const fee = num('delivery_fee_paise'), platformFee = num('platform_fee_paise'), commission = Math.min(num('partner_commission_paise'), fee);
    return { shop, addr, items, subtotal_paise: subtotal, delivery_fee_paise: fee, platform_fee_paise: platformFee, total_paise: subtotal + fee + platformFee,
      partner_commission_paise: commission, partner_earning_paise: fee - commission, distance_km: Math.round(km * 10) / 10,
      shop_commission_bps: shop.commission_bps ?? num('shop_commission_bps') };
  }

  function createOrder(customerId, { addressId, paymentMethod, note, idempotencyKey }) {
    return db.tx(() => {
      if (idempotencyKey) {
        const ex = db.get('SELECT id FROM orders WHERE customer_id=? AND idempotency_key=?', customerId, idempotencyKey);
        if (ex) return { orderId: ex.id, replay: true };
      }
      const q = quote(customerId, addressId);
      const codMax = Number(getSetting(db, 'cod_max_paise') ?? 500000);
      if (paymentMethod === 'cod' && q.total_paise > codMax) throw E.conflict(`Cash on Delivery is available up to ₹${codMax / 100}. Please pay online.`, 'cod_limit');
      for (const it of q.items) {
        const r = db.run('UPDATE products SET stock_qty=stock_qty-?, updated_at=? WHERE id=? AND stock_qty>=? AND is_available=1 AND deleted_at IS NULL AND is_blocked=0', it.qty, nowIso(), it.product_id, it.qty);
        if (r.changes === 0) throw E.conflict(`"${it.name}" just went out of stock`, 'out_of_stock');
      }
      const id = uid(), number = 'GC' + Date.now().toString(36).toUpperCase() + String(Math.floor(Math.random() * 90 + 10));
      const status = paymentMethod === 'cod' ? 'placed' : 'pending_payment';
      db.run(`INSERT INTO orders(id,number,customer_id,shop_id,status,payment_method,subtotal_paise,delivery_fee_paise,platform_fee_paise,total_paise,partner_commission_paise,partner_earning_paise,shop_commission_bps,addr_name,addr_phone,addr_line,addr_lat,addr_lng,note,delivery_code,idempotency_key)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, id, number, customerId, q.shop.id, status, paymentMethod, q.subtotal_paise, q.delivery_fee_paise, q.platform_fee_paise, q.total_paise,
        q.partner_commission_paise, q.partner_earning_paise, q.shop_commission_bps, q.addr.recipient_name, q.addr.phone, [q.addr.line1, q.addr.landmark, q.addr.village, q.addr.pincode].filter(Boolean).join(', '), q.addr.lat, q.addr.lng, note ?? null, deliveryCode(), idempotencyKey ?? null);
      for (const it of q.items) {
        db.run('INSERT INTO order_items(order_id,product_id,name,price_paise,qty) VALUES (?,?,?,?,?)', id, it.product_id, it.name, it.price_paise, it.qty);
        db.run('INSERT INTO stock_movements(product_id,delta,reason,order_id) VALUES (?,?,?,?)', it.product_id, -it.qty, 'order', id);
      }
      db.run('INSERT INTO payments(id,order_id,method,gateway,amount_paise) VALUES (?,?,?,?,?)', uid(), id, paymentMethod, paymentMethod === 'online' ? 'razorpay' : null, q.total_paise);
      db.run('INSERT INTO order_events(order_id,status,actor_id,actor_role) VALUES (?,?,?,?)', id, status, customerId, 'customer');
      db.run('DELETE FROM cart_items WHERE customer_id=?', customerId);
      db.run('UPDATE carts SET shop_id=NULL, updated_at=? WHERE customer_id=?', nowIso(), customerId);
      return { orderId: id, replay: false };
    });
  }

  // Creates the Razorpay order for a pending_payment order. On gateway failure the order is cancelled and stock restored.
  async function startOnlinePayment(orderId) {
    const o = db.get('SELECT * FROM orders WHERE id=?', orderId);
    const pay = db.get("SELECT * FROM payments WHERE order_id=? AND method='online'", orderId);
    if (pay.gateway_order_id) return pay;
    try {
      const go = await gateway.createOrder({ amountPaise: o.total_paise, receipt: o.number, notes: { order_id: o.id } });
      db.run('UPDATE payments SET gateway_order_id=?, updated_at=? WHERE id=?', go.id, nowIso(), pay.id);
      return db.get('SELECT * FROM payments WHERE id=?', pay.id);
    } catch (err) {
      await transition(orderId, 'cancelled', { id: null, role: 'system' }, { note: 'Could not start payment: ' + err.message });
      throw err;
    }
  }

  // ---------- generic transition ----------
  // Returns { order, after } where `after` is a list of async tasks to run once the DB transaction has committed.
  function transitionTx(orderId, to, actor, opts = {}) {
    const o = db.get('SELECT * FROM orders WHERE id=?', orderId);
    if (!o) throw E.notFound('Order not found');
    const allowed = TRANSITIONS[o.status]?.[to];
    if (!allowed) throw E.conflict(`Order cannot move from ${o.status} to ${to}`, 'invalid_transition');
    if (actor.role === 'customer' && to === 'cancelled' && !allowed.includes('customer')) throw E.conflict('This order can no longer be cancelled', 'cancel_not_allowed');
    if (actor.role !== 'admin' && !allowed.includes(actor.role)) throw E.forbid(`Role ${actor.role} cannot set ${to}`);
    if (actor.role === 'admin' && !allowed.includes('admin')) throw E.conflict(`Order cannot move from ${o.status} to ${to}`, 'invalid_transition');
    if (to === 'cancelled' && actor.role === 'customer') {
      const until = getSetting(db, 'customer_cancel_until');
      if (o.status === 'accepted' && until !== 'accepted') throw E.conflict('This order can no longer be cancelled', 'cancel_not_allowed');
    }
    const sets = ['status=?', 'updated_at=?'], params = [to, nowIso()];
    if (TS_COL[to]) { sets.push(`${TS_COL[to]}=?`); params.push(nowIso()); }
    for (const [k, val] of Object.entries(opts.set || {})) { sets.push(`${k}=?`); params.push(val); }
    if (to === 'cancelled' || to === 'rejected') { sets.push('cancel_reason=?', 'cancelled_by=?'); params.push(opts.note ?? null, actor.role); }
    let where = 'id=? AND status=?'; params.push(orderId, o.status);
    if (opts.requirePartner) { where += ' AND partner_id=?'; params.push(actor.id); }
    if (opts.unassignedOnly) where += ' AND partner_id IS NULL';
    const r = db.run(`UPDATE orders SET ${sets.join(',')} WHERE ${where}`, ...params);
    if (r.changes === 0) throw E.conflict('Order was just updated by someone else. Please refresh.', 'stale_order');
    db.run('INSERT INTO order_events(order_id,status,actor_id,actor_role,note) VALUES (?,?,?,?,?)', orderId, to, actor.id, actor.role, opts.note ?? null);
    const after = [];
    if (to === 'cancelled' || to === 'rejected') {
      for (const it of db.all('SELECT product_id, qty FROM order_items WHERE order_id=?', orderId)) {
        db.run('UPDATE products SET stock_qty=stock_qty+?, updated_at=? WHERE id=?', it.qty, nowIso(), it.product_id);
        db.run('INSERT INTO stock_movements(product_id,delta,reason,order_id) VALUES (?,?,?,?)', it.product_id, it.qty, 'order_cancelled', orderId);
      }
      db.run("UPDATE payments SET status='failed', failure_reason=COALESCE(failure_reason,?), updated_at=? WHERE order_id=? AND status='created'", opts.note ?? 'order cancelled', nowIso(), orderId);
      const paid = db.get("SELECT * FROM payments WHERE order_id=? AND status='paid' AND method='online'", orderId);
      if (paid) { const rid = startRefundTx(orderId, paid.amount_paise, `Order ${to}: ${opts.note ?? ''}`.trim(), actor.id); after.push(() => processRefund(rid)); }
    }
    if (to === 'delivered') finalizeDelivery(orderId);
    return { order: db.get('SELECT * FROM orders WHERE id=?', orderId), after };
  }

  async function transition(orderId, to, actor, opts) {
    const { order, after } = db.tx(() => transitionTx(orderId, to, actor, opts));
    emitOrderUpdate(order, actor);
    await Promise.allSettled(after.map(f => f()));
    return db.get('SELECT * FROM orders WHERE id=?', orderId);
  }

  // ---------- delivery completion: commission + ledger (runs inside the delivering transaction) ----------
  function finalizeDelivery(orderId) {
    const o = db.get('SELECT o.*, s.seller_id FROM orders o JOIN shops s ON s.id=o.shop_id WHERE o.id=?', orderId);
    const shopCommission = Math.round(o.subtotal_paise * o.shop_commission_bps / 10000);
    const sellerEarning = o.subtotal_paise - shopCommission;
    db.run('INSERT INTO commissions(order_id,shop_commission_paise,delivery_commission_paise,platform_fee_paise,partner_earning_paise,seller_earning_paise) VALUES (?,?,?,?,?,?)',
      orderId, shopCommission, o.partner_commission_paise, o.platform_fee_paise, o.partner_earning_paise, sellerEarning);
    const tx = (type, id, kind, amt) => { if (amt !== 0) db.run('INSERT INTO transactions(order_id,payee_type,payee_id,kind,amount_paise) VALUES (?,?,?,?,?)', orderId, type, id, kind, amt); };
    tx('seller', o.seller_id, 'order_earning', sellerEarning);
    tx('partner', o.partner_id, 'delivery_earning', o.partner_earning_paise);
    tx('platform', 'platform', 'shop_commission', shopCommission);
    tx('platform', 'platform', 'delivery_commission', o.partner_commission_paise);
    tx('platform', 'platform', 'platform_fee', o.platform_fee_paise);
    if (o.payment_method === 'cod') { // partner physically holds the customer's cash and must remit it
      tx('partner', o.partner_id, 'cod_cash_held', -o.total_paise);
      db.run("UPDATE payments SET status='paid', paid_at=?, updated_at=? WHERE order_id=? AND method='cod'", nowIso(), nowIso(), orderId);
      db.run("UPDATE orders SET payment_status='paid' WHERE id=?", orderId);
    }
  }

  // ---------- payments ----------
  // Called after signature/gateway verification (checkout verify) or from a verified webhook.
  function applyCaptured({ gatewayOrderId, gatewayPaymentId, amountPaise }) {
    return db.tx(() => {
      const p = db.get('SELECT * FROM payments WHERE gateway_order_id=?', gatewayOrderId);
      if (!p) return { ignored: true };
      if (p.status === 'paid' || p.status === 'refunded' || p.status === 'partially_refunded') return { order: db.get('SELECT * FROM orders WHERE id=?', p.order_id), already: true, after: [] };
      if (amountPaise !== p.amount_paise) throw E.conflict('Paid amount does not match the order amount', 'amount_mismatch');
      db.run("UPDATE payments SET status='paid', gateway_payment_id=?, paid_at=?, failure_reason=NULL, updated_at=? WHERE id=?", gatewayPaymentId, nowIso(), nowIso(), p.id);
      const o = db.get('SELECT * FROM orders WHERE id=?', p.order_id);
      if (o.status === 'pending_payment') {
        db.run("UPDATE orders SET payment_status='paid' WHERE id=?", o.id);
        const r = transitionTx(o.id, 'placed', { id: null, role: 'system' }, { note: 'Payment confirmed' });
        return { order: r.order, after: r.after, justPaid: true };
      }
      // Payment captured after the order was already cancelled/expired -> refund automatically.
      db.run("UPDATE orders SET payment_status='paid' WHERE id=?", o.id);
      const rid = startRefundTx(o.id, p.amount_paise, 'Payment received after order was cancelled', null);
      return { order: o, after: [() => processRefund(rid)], lateCapture: true };
    });
  }
  async function afterPayment(res) {
    if (!res?.order) return res;
    if (res.justPaid) { emitOrderUpdate(res.order, { id: null, role: 'system' }); notify(res.order.customer_id, 'payment', 'Payment received', `Payment for order ${res.order.number} was successful.`, { order_id: res.order.id }); }
    await Promise.allSettled((res.after || []).map(f => f()));
    return res;
  }
  function recordPaymentFailure(gatewayOrderId, reason) {
    db.run("UPDATE payments SET failure_reason=?, updated_at=? WHERE gateway_order_id=? AND status='created'", reason ?? 'payment failed', nowIso(), gatewayOrderId);
    const p = db.get('SELECT o.customer_id, o.number, o.id FROM payments p JOIN orders o ON o.id=p.order_id WHERE p.gateway_order_id=?', gatewayOrderId);
    if (p) notify(p.customer_id, 'payment', 'Payment failed', `Payment for order ${p.number} did not go through. You can retry.`, { order_id: p.id });
  }

  // ---------- refunds ----------
  function startRefundTx(orderId, amountPaise, reason, requestedBy) {
    const p = db.get("SELECT * FROM payments WHERE order_id=? AND method='online' AND status IN ('paid','partially_refunded')", orderId);
    if (!p) throw E.conflict('No captured online payment to refund', 'nothing_to_refund');
    const already = db.get("SELECT COALESCE(SUM(amount_paise),0) s FROM refunds WHERE payment_id=? AND status IN ('pending','processed')", p.id).s;
    if (amountPaise <= 0 || already + amountPaise > p.amount_paise) throw E.conflict('Refund exceeds the amount paid', 'refund_exceeds');
    const id = uid();
    db.run('INSERT INTO refunds(id,order_id,payment_id,amount_paise,reason,requested_by) VALUES (?,?,?,?,?,?)', id, orderId, p.id, amountPaise, reason, requestedBy);
    return id;
  }
  async function processRefund(refundId) {
    const r = db.get('SELECT * FROM refunds WHERE id=?', refundId);
    if (!r || r.status !== 'pending' || r.gateway_refund_id) return r;
    const p = db.get('SELECT * FROM payments WHERE id=?', r.payment_id);
    try {
      const g = await gateway.refund(p.gateway_payment_id, r.amount_paise, { refund_id: r.id, order_id: r.order_id });
      db.run('UPDATE refunds SET gateway_refund_id=? WHERE id=?', g.id, r.id);
      if (g.status === 'processed') markRefundProcessed(g.id);
    } catch (err) {
      db.run('UPDATE refunds SET failure_reason=? WHERE id=?', String(err.message).slice(0, 300), r.id); // stays pending; admin can retry
    }
    return db.get('SELECT * FROM refunds WHERE id=?', refundId);
  }
  function markRefundProcessed(gatewayRefundId) {
    db.tx(() => {
      const r = db.get('SELECT * FROM refunds WHERE gateway_refund_id=?', gatewayRefundId);
      if (!r || r.status === 'processed') return;
      db.run("UPDATE refunds SET status='processed', processed_at=?, failure_reason=NULL WHERE id=?", nowIso(), r.id);
      const p = db.get('SELECT * FROM payments WHERE id=?', r.payment_id);
      const tot = db.get("SELECT SUM(amount_paise) s FROM refunds WHERE payment_id=? AND status='processed'", p.id).s;
      const st = tot >= p.amount_paise ? 'refunded' : 'partially_refunded';
      db.run('UPDATE payments SET status=?, updated_at=? WHERE id=?', st, nowIso(), p.id);
      db.run('UPDATE orders SET payment_status=? WHERE id=?', st, r.order_id);
      const o = db.get('SELECT customer_id, number, id FROM orders WHERE id=?', r.order_id);
      notify(o.customer_id, 'payment', 'Refund processed', `₹${(r.amount_paise / 100).toFixed(2)} refunded for order ${o.number}.`, { order_id: o.id });
    });
  }

  // ---------- realtime + notifications ----------
  const MSG = {
    placed: ['Order placed', 'We sent your order to the shop.'], accepted: ['Order accepted', 'The shop accepted your order.'],
    preparing: ['Preparing your order', 'The shop is preparing your items.'], ready_for_pickup: ['Order is ready', 'Waiting for a delivery partner.'],
    assigned: ['Delivery partner assigned', 'A delivery partner is on the way to the shop.'], picked_up: ['Order picked up', 'Your order has been picked up.'],
    out_for_delivery: ['Out for delivery', 'Your order is on the way.'], delivered: ['Order delivered', 'Enjoy! Please rate your order.'],
    rejected: ['Order rejected', 'The shop could not accept your order. Any payment will be refunded.'], cancelled: ['Order cancelled', 'Your order was cancelled. Any payment will be refunded.'],
  };
  function emitOrderUpdate(o, actor) {
    const shop = db.get('SELECT seller_id, name, lat, lng FROM shops WHERE id=?', o.shop_id);
    const payload = { order_id: o.id, number: o.number, status: o.status, updated_at: o.updated_at };
    const parties = [o.customer_id, shop.seller_id, o.partner_id].filter(Boolean);
    for (const u of parties) hub.publish(u, 'order_update', payload);
    const m = MSG[o.status], data = { order_id: o.id, status: o.status };
    if (m) notify(o.customer_id, 'order', m[0], `#${o.number}: ${m[1]}`, data);
    if (o.status === 'placed') notify(shop.seller_id, 'new_order', 'New order', `Order #${o.number} - ₹${(o.subtotal_paise / 100).toFixed(0)}`, data);
    if ((o.status === 'cancelled' || o.status === 'rejected') && actor?.role !== 'seller') notify(shop.seller_id, 'order_cancelled', 'Order cancelled', `Order #${o.number} was cancelled.`, data);
    if (o.status === 'assigned') notify(shop.seller_id, 'order', 'Delivery partner assigned', `Order #${o.number} will be picked up soon.`, data);
    if (o.status === 'ready_for_pickup') notifyNearbyPartners(o, shop);
    if (o.status === 'delivered') {
      notify(shop.seller_id, 'payment', 'Order completed', `Order #${o.number} delivered.`, data);
      if (o.partner_id) notify(o.partner_id, 'earnings', 'Delivery completed', `You earned ₹${(o.partner_earning_paise / 100).toFixed(2)} for order #${o.number}.`, data);
    }
    if ((o.status === 'cancelled') && o.partner_id) notify(o.partner_id, 'order', 'Delivery cancelled', `Order #${o.number} was cancelled.`, data);
  }
  function notifyNearbyPartners(o, shop) {
    const [a, b, c, d] = bbox(shop.lat, shop.lng, num('service_radius_km'));
    const cutoff = new Date(Date.now() - 10 * 60000).toISOString();
    const ps = db.all(`SELECT u.id FROM delivery_partners dp JOIN users u ON u.id=dp.user_id
      WHERE dp.is_online=1 AND dp.verification_status='verified' AND u.status='active' AND dp.last_seen_at>=?
      AND dp.last_lat BETWEEN ? AND ? AND dp.last_lng BETWEEN ? AND ?`, cutoff, a, b, c, d);
    for (const p of ps) notify(p.id, 'delivery_request', 'New delivery request', `Pickup from ${shop.name}. Earn ₹${(o.partner_earning_paise / 100).toFixed(0)}.`, { order_id: o.id });
  }

  // ---------- timers ----------
  async function expirePendingPayments() {
    const cutoff = new Date(Date.now() - num('pending_payment_ttl_min') * 60000).toISOString();
    const rows = db.all("SELECT id FROM orders WHERE status='pending_payment' AND created_at<?", cutoff);
    for (const r of rows) { try { await transition(r.id, 'cancelled', { id: null, role: 'system' }, { note: 'Payment not completed in time' }); } catch {} }
    return rows.length;
  }
  function expireStalePartners() {
    const cutoff = new Date(Date.now() - 10 * 60000).toISOString();
    return db.run(`UPDATE delivery_partners SET is_online=0 WHERE is_online=1 AND (last_seen_at IS NULL OR last_seen_at<?)
      AND user_id NOT IN (SELECT partner_id FROM orders WHERE partner_id IS NOT NULL AND status IN ('assigned','picked_up','out_for_delivery'))`, cutoff).changes;
  }

  return { quote, createOrder, startOnlinePayment, transition, transitionTx, emitOrderUpdate, applyCaptured, afterPayment, recordPaymentFailure,
    startRefundTx, processRefund, markRefundProcessed, expirePendingPayments, expireStalePartners, shopOpenNow, availableProductCount, nowMin };
}

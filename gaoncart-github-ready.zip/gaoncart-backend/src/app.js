import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { openDb, migrate, seedDefaults, uid } from './db.js';
import { config as defaultCfg } from './config.js';
import { ApiError, E, Router, readBody, send } from './lib/http.js';
import { makeCrypto, makeLimiter, verifyJwt } from './lib/security.js';
import { makeHub } from './lib/realtime.js';
import { makeNotifier } from './lib/notify.js';
import { makePush } from './lib/push.js';
import { makeSms } from './lib/sms.js';
import { makeGateway } from './lib/gateway.js';
import { makeDomain } from './domain.js';
import { registerCommon } from './routes/common.js';
import { registerCustomer } from './routes/customer.js';
import { registerSeller } from './routes/seller.js';
import { registerDelivery } from './routes/delivery.js';
import { registerAdmin } from './routes/admin.js';
import { registerWebhooks } from './routes/webhooks.js';

export function createApp(overrides = {}) {
  const cfg = overrides.cfg || defaultCfg;
  const db = overrides.db || openDb(cfg.dbPath);
  migrate(db); seedDefaults(db, cfg);
  const hub = makeHub();
  const notify = makeNotifier({ db, hub });
  const gateway = overrides.gateway || makeGateway({ ...cfg.razorpay, fetchImpl: overrides.fetchImpl || fetch });
  const sms = overrides.sms || makeSms({ cfg: cfg.sms, fetchImpl: overrides.fetchImpl || fetch });
  const push = overrides.push || makePush({ db, file: cfg.fcmFile, fetchImpl: overrides.fetchImpl || fetch });
  const enc = makeCrypto(cfg.encKeyHex);
  const limiter = makeLimiter();
  const domain = makeDomain({ db, hub, notify, gateway, cfg });
  const router = new Router();

  const audit = (actorId, action, entity, entityId, meta) =>
    db.run('INSERT INTO audit_log(actor_id,action,entity,entity_id,meta) VALUES (?,?,?,?,?)', actorId, action, entity, entityId, meta ? JSON.stringify(meta) : null);
  const notifyAdmins = (type, title, body, data) => { for (const a of db.all("SELECT id FROM users WHERE role='admin' AND status='active'")) notify(a.id, type, title, body, data); };

  // Guards. Account status is re-checked on every request so suspension takes effect immediately.
  const auth = (...roles) => async (ctx) => {
    const h = ctx.req.headers.authorization || '';
    const claims = h.startsWith('Bearer ') ? verifyJwt(h.slice(7), cfg.jwtSecret) : null;
    if (!claims || claims.typ !== 'access') throw E.unauth();
    const u = db.get('SELECT id, role, status, name, mobile, email FROM users WHERE id=?', claims.sub);
    if (!u || u.status !== 'active' || u.role !== claims.role) throw E.unauth('Account is not active');
    if (roles.length && !roles.includes(u.role)) throw E.forbid('Your account type cannot access this resource');
    ctx.user = u;
    if (u.role === 'admin') ctx.user.level = db.get('SELECT level FROM admins WHERE user_id=?', u.id)?.level;
    if (!limiter.hit('u:' + u.id, 600, 60000)) throw E.tooMany();
  };
  const adminLevel = (...levels) => async (ctx) => {
    await auth('admin')(ctx);
    if (ctx.user.level !== 'super' && !levels.includes(ctx.user.level)) throw E.forbid('Your admin level cannot perform this action');
  };

  const A = { cfg, db, hub, notify, notifyAdmins, gateway, sms, push, enc, limiter, domain, audit, auth, adminLevel, router };
  registerCommon(router, A); registerCustomer(router, A); registerSeller(router, A);
  registerDelivery(router, A); registerAdmin(router, A); registerWebhooks(router, A);

  const secHeaders = { 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer', 'Strict-Transport-Security': 'max-age=31536000; includeSubDomains', 'Cache-Control': 'no-store' };

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://x');
    const origin = req.headers.origin;
    const cors = {};
    if (origin && cfg.corsOrigins.includes(origin)) Object.assign(cors, { 'Access-Control-Allow-Origin': origin, Vary: 'Origin', 'Access-Control-Allow-Headers': 'Authorization, Content-Type, Idempotency-Key', 'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS', 'Access-Control-Max-Age': '600' });
    for (const [k, val] of Object.entries({ ...secHeaders, ...cors })) res.setHeader(k, val);
    const rid = uid(); res.setHeader('X-Request-Id', rid);
    try {
      if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
      const ip = req.socket.remoteAddress || '?';
      if (!limiter.hit('ip:' + ip, 3000, 60000)) throw E.tooMany();
      const m = router.match(req.method, url.pathname);
      if (!m.handlers) throw m.pathMatched ? new ApiError(405, 'method_not_allowed', 'Method not allowed') : E.notFound('Route not found');
      const ctx = { req, res, params: m.params, query: url.searchParams, body: undefined, raw: undefined, ip, app: A, status: 200 };
      const isRaw = url.pathname === '/v1/uploads' || url.pathname === '/v1/webhooks/razorpay';
      if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
        const buf = await readBody(req, url.pathname === '/v1/uploads' ? 5 * 1024 * 1024 : 1024 * 1024);
        ctx.raw = buf;
        if (!isRaw || url.pathname === '/v1/webhooks/razorpay') {
          if (buf.length) { try { ctx.body = JSON.parse(buf.toString('utf8')); } catch { if (!isRaw) throw E.bad('Body must be valid JSON'); } } else ctx.body = {};
        }
      }
      for (const h of m.handlers) {
        const out = await h(ctx);
        if (ctx.responded || res.writableEnded) return;
        if (out !== undefined) return send(res, ctx.status, out);
      }
      send(res, 204);
    } catch (err) {
      if (res.headersSent) { try { res.end(); } catch {} return; }
      if (err instanceof ApiError) return send(res, err.status, { error: { code: err.code, message: err.message, details: err.details, request_id: rid } });
      if (err && /UNIQUE constraint/.test(err.message || '')) return send(res, 409, { error: { code: 'duplicate', message: 'Already exists', request_id: rid } });
      console.error(`[${rid}]`, err);
      send(res, 500, { error: { code: 'internal', message: 'Something went wrong', request_id: rid } });
    }
  });

  const timers = [];
  function startJobs() {
    const every = (ms, fn) => { const t = setInterval(() => Promise.resolve(fn()).catch(e => console.error('job error', e)), ms); t.unref(); timers.push(t); };
    every(60000, () => domain.expirePendingPayments());
    every(60000, () => domain.expireStalePartners());
    every(5000, () => push.flush());
    every(300000, () => { limiter.sweep(); db.run("DELETE FROM otp_codes WHERE created_at < datetime('now','-1 day')"); db.run("DELETE FROM refresh_tokens WHERE expires_at < datetime('now','-7 day')"); });
  }
  async function close() { timers.forEach(clearInterval); hub.closeAll(); await new Promise(r => server.close(r)); db.close(); }
  return { server, db, A, startJobs, close };
}

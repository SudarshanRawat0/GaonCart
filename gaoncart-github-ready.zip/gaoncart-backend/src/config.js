import fs from 'node:fs';
if (fs.existsSync('.env')) process.loadEnvFile('.env');
const e = process.env;
const n = (k, d) => (e[k] !== undefined && e[k] !== '' ? Number(e[k]) : d);
const prod = e.NODE_ENV === 'production';

export const config = {
  prod,
  port: n('PORT', 8080),
  dbPath: e.DB_PATH || './data/gaoncart.db',
  jwtSecret: e.JWT_SECRET || '',
  encKeyHex: e.DATA_ENCRYPTION_KEY || '',
  corsOrigins: (e.CORS_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean),
  publicBaseUrl: e.PUBLIC_BASE_URL || '',
  uploadDir: e.UPLOAD_DIR || './uploads',
  privateUploadDir: e.PRIVATE_UPLOAD_DIR || './private_uploads',
  backupDir: e.BACKUP_DIR || './backups',
  sms: { provider: e.SMS_PROVIDER || 'none', msg91Key: e.MSG91_AUTH_KEY || '', msg91Template: e.MSG91_OTP_TEMPLATE_ID || '' },
  razorpay: { keyId: e.RAZORPAY_KEY_ID || '', keySecret: e.RAZORPAY_KEY_SECRET || '', webhookSecret: e.RAZORPAY_WEBHOOK_SECRET || '' },
  fcmFile: e.FCM_SERVICE_ACCOUNT_FILE || '',
  defaults: { deliveryFeePaise: n('DELIVERY_FEE_PAISE', 2000), partnerCommissionPaise: n('PARTNER_COMMISSION_PAISE', 500), serviceRadiusKm: n('SERVICE_RADIUS_KM', 10) },
  tzOffsetMin: 330, // IST, used for shop opening hours
};

export function assertConfig() {
  const errs = [];
  if (config.jwtSecret.length < 32) errs.push('JWT_SECRET must be at least 32 characters');
  if (!/^[0-9a-f]{64}$/i.test(config.encKeyHex)) errs.push('DATA_ENCRYPTION_KEY must be 64 hex characters');
  if (prod && config.sms.provider === 'console') errs.push('SMS_PROVIDER=console is not allowed in production');
  if (prod && config.corsOrigins.length === 0) errs.push('CORS_ORIGINS must be set in production');
  if (errs.length) throw new Error('Invalid configuration:\n - ' + errs.join('\n - '));
}

import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

export const uid = () => crypto.randomUUID();
export const nowIso = () => new Date().toISOString();

export function openDb(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const raw = new DatabaseSync(file);
  raw.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000; PRAGMA synchronous=NORMAL;');
  let depth = 0;
  const db = {
    raw,
    get: (sql, ...p) => raw.prepare(sql).get(...p),
    all: (sql, ...p) => raw.prepare(sql).all(...p),
    run: (sql, ...p) => raw.prepare(sql).run(...p),
    // Synchronous transaction. Nested calls join the outer one.
    tx(fn) {
      if (depth > 0) return fn();
      raw.exec('BEGIN IMMEDIATE');
      depth++;
      try { const r = fn(); raw.exec('COMMIT'); return r; }
      catch (err) { raw.exec('ROLLBACK'); throw err; }
      finally { depth--; }
    },
    close: () => raw.close(),
  };
  return db;
}

export function migrate(db, dir = path.resolve('migrations')) {
  db.raw.exec('CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL)');
  const done = new Set(db.all('SELECT name FROM schema_migrations').map(r => r.name));
  const applied = [];
  for (const f of fs.readdirSync(dir).filter(f => f.endsWith('.sql')).sort()) {
    if (done.has(f)) continue;
    db.tx(() => {
      db.raw.exec(fs.readFileSync(path.join(dir, f), 'utf8'));
      db.run('INSERT INTO schema_migrations(name, applied_at) VALUES (?,?)', f, nowIso());
    });
    applied.push(f);
  }
  return applied;
}

export function seedDefaults(db, cfg) {
  const set = (k, v) => db.run('INSERT OR IGNORE INTO admin_settings(key,value) VALUES (?,?)', k, String(v));
  set('delivery_fee_paise', cfg.defaults.deliveryFeePaise);
  set('partner_commission_paise', cfg.defaults.partnerCommissionPaise);
  set('shop_commission_bps', 0);
  set('platform_fee_paise', 0);
  set('service_radius_km', cfg.defaults.serviceRadiusKm);
  set('customer_cancel_until', 'accepted'); // customer may cancel while status is placed/accepted
  set('pending_payment_ttl_min', 15);
  const page = (k, t) => db.run('INSERT OR IGNORE INTO site_content(key,title,body) VALUES (?,?,?)', k, t, 'PLACEHOLDER: replace via /v1/admin/content before launch (legal text must be reviewed by your lawyer).');
  page('privacy_policy', 'Privacy Policy'); page('terms', 'Terms and Conditions');
  page('refund_policy', 'Refund and Cancellation Policy'); page('grievance', 'Grievance Redressal');
}

export const getSetting = (db, key) => db.get('SELECT value FROM admin_settings WHERE key=?', key)?.value;
export const getIntSetting = (db, key) => Number(getSetting(db, key));

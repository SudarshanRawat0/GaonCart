// Usage: ADMIN_EMAIL=you@x.in ADMIN_PASSWORD='long-passphrase' ADMIN_NAME='Owner' npm run create-admin
import { assertConfig, config } from '../src/config.js';
import { openDb, migrate, seedDefaults, uid } from '../src/db.js';
import { hashPassword } from '../src/lib/security.js';
assertConfig();
const { ADMIN_EMAIL: email, ADMIN_PASSWORD: pw, ADMIN_NAME: name = 'Admin' } = process.env;
if (!email || !pw || pw.length < 12) { console.error('Set ADMIN_EMAIL and ADMIN_PASSWORD (min 12 chars)'); process.exit(1); }
const db = openDb(config.dbPath); migrate(db); seedDefaults(db, config);
if (db.get('SELECT 1 x FROM users WHERE email=?', email.toLowerCase())) { console.error('Admin already exists'); process.exit(1); }
const id = uid();
db.run("INSERT INTO users(id,role,email,password_hash,name) VALUES (?,'admin',?,?,?)", id, email.toLowerCase(), await hashPassword(pw), name);
db.run("INSERT INTO admins(user_id,level) VALUES (?,'super')", id);
console.log('Super admin created:', email);

import { assertConfig, config } from '../src/config.js';
import { openDb, migrate, seedDefaults } from '../src/db.js';
assertConfig();
const db = openDb(config.dbPath);
const applied = migrate(db); seedDefaults(db, config);
console.log(applied.length ? `Applied: ${applied.join(', ')}` : 'Database is up to date');

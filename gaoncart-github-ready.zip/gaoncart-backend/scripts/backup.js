// Online, consistent snapshot of the database (safe while the API is running). Run from cron: 0 */6 * * *
import fs from 'node:fs';
import path from 'node:path';
import { backup, DatabaseSync } from 'node:sqlite';
import { config } from '../src/config.js';
fs.mkdirSync(config.backupDir, { recursive: true });
const src = new DatabaseSync(config.dbPath);
const out = path.join(config.backupDir, `gaoncart-${new Date().toISOString().replace(/[:.]/g, '-')}.db`);
await backup(src, out);
src.close();
const keep = Number(process.env.BACKUP_KEEP || 28);
const files = fs.readdirSync(config.backupDir).filter(f => f.startsWith('gaoncart-')).sort();
for (const f of files.slice(0, Math.max(0, files.length - keep))) fs.rmSync(path.join(config.backupDir, f));
console.log('Backup written:', out);

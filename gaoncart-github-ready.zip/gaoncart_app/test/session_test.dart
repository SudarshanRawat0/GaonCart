import 'package:flutter_test/flutter_test.dart';
import 'package:gaoncart/features/auth/session.dart';

void main() {
  test('roleFrom maps only the three mobile roles; admin or garbage never opens a dashboard', () {
    expect(roleFrom('customer'), Role.customer);
    expect(roleFrom('seller'), Role.seller);
    expect(roleFrom('delivery'), Role.delivery);
    expect(roleFrom('admin'), isNull);
    expect(roleFrom(null), isNull);
    expect(roleFrom('SELLER'), isNull);
  });
}

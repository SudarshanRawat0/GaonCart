import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/api_client.dart';
import '../../theme.dart';
import 'session.dart';

class LoginScreen extends StatefulWidget { const LoginScreen({super.key}); @override State<LoginScreen> createState() => _S(); }
class _S extends State<LoginScreen> {
  Role role = Role.customer; final mobile = TextEditingController(), otp = TextEditingController(), name = TextEditingController();
  bool otpSent = false, busy = false; String? error;
  static const labels = {Role.customer: ('Customer', 'Order from nearby shops', Icons.shopping_basket_outlined), Role.seller: ('Seller', 'Sell from your shop', Icons.storefront_outlined), Role.delivery: ('Delivery partner', 'Deliver and earn', Icons.two_wheeler_outlined)};

  Future<void> _run(Future<void> Function() f) async {
    setState(() { busy = true; error = null; });
    try { await f(); } on ApiException catch (e) { setState(() => error = e.message); } finally { if (mounted) setState(() => busy = false); }
  }
  bool get _mobileOk => RegExp(r'^[6-9]\d{9}$').hasMatch(mobile.text.trim());

  @override Widget build(BuildContext context) {
    final s = context.read<Session>();
    return Scaffold(body: SafeArea(child: ListView(padding: const EdgeInsets.all(24), children: [
      const SizedBox(height: 24), Text('GaonCart', style: Theme.of(context).textTheme.headlineMedium?.copyWith(color: GC.green, fontSize: 34)),
      const SizedBox(height: 6), const Text('Your village market, delivered.'), const SizedBox(height: 28),
      if (!otpSent) ...[
        Text('I am a', style: Theme.of(context).textTheme.titleMedium), const SizedBox(height: 8),
        for (final r in Role.values) Card(margin: const EdgeInsets.only(bottom: 8), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: role == r ? GC.green : Colors.transparent, width: 2)),
          child: ListTile(leading: Icon(labels[r]!.$3, color: GC.green), title: Text(labels[r]!.$1), subtitle: Text(labels[r]!.$2), trailing: role == r ? const Icon(Icons.check_circle, color: GC.green) : null, onTap: () => setState(() => role = r))),
        const SizedBox(height: 12),
        TextField(controller: mobile, keyboardType: TextInputType.phone, maxLength: 10, decoration: const InputDecoration(labelText: 'Mobile number', prefixText: '+91 ', counterText: ''), onChanged: (_) => setState(() {})),
        const SizedBox(height: 16),
        FilledButton(onPressed: busy || !_mobileOk ? null : () => _run(() async { await s.requestOtp(mobile.text.trim(), role); setState(() => otpSent = true); }), child: busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Send OTP')),
      ] else ...[
        Text('Enter the 6-digit code sent to +91 ${mobile.text}', style: Theme.of(context).textTheme.titleMedium), const SizedBox(height: 12),
        TextField(controller: otp, keyboardType: TextInputType.number, maxLength: 6, autofocus: true, decoration: const InputDecoration(labelText: 'OTP', counterText: ''), onChanged: (_) => setState(() {})),
        const SizedBox(height: 8), TextField(controller: name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Your name (first time only)')),
        const SizedBox(height: 16),
        FilledButton(onPressed: busy || otp.text.length != 6 ? null : () => _run(() async { await s.verifyOtp(mobile.text.trim(), role, otp.text, name: name.text.trim()); }), child: const Text('Verify & continue')),
        TextButton(onPressed: busy ? null : () => setState(() { otpSent = false; otp.clear(); }), child: const Text('Change number or role')),
      ],
      if (error != null) Padding(padding: const EdgeInsets.only(top: 16), child: Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
    ])));
  }
}

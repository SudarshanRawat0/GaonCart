import 'package:flutter/foundation.dart';
import '../../core/api_client.dart';
import '../../core/token_store.dart';

enum Role { customer, seller, delivery }
Role? roleFrom(String? s) => Role.values.where((r) => r.name == s).firstOrNull;

enum SessionState { loading, signedOut, signedIn }

/// Single source of truth for auth. The ROLE ALWAYS COMES FROM THE SERVER (user.role in the verify/me response);
/// the UI role picker only chooses which account to log in to / register. The backend enforces authorization
/// on every endpoint, so a tampered client still cannot reach another role's data.
class Session extends ChangeNotifier {
  Session() { tokens = TokenStore(); api = ApiClient(tokens, onSessionExpired: _expired); }
  late final TokenStore tokens; late final ApiClient api;
  SessionState state = SessionState.loading; Role? role; Map<String, dynamic>? user;

  Future<void> restore() async {
    await tokens.load();
    if (tokens.access == null) { state = SessionState.signedOut; return notifyListeners(); }
    try { await _loadMe(); } on ApiException catch (e) { if (!e.isNetwork) await tokens.clear(); state = SessionState.signedOut; }
    notifyListeners();
  }
  Future<void> _loadMe() async {
    final me = await api.get('/v1/me') as Map<String, dynamic>;
    final r = roleFrom(me['role']);
    if (r == null) { await tokens.clear(); state = SessionState.signedOut; return; } // e.g. an admin account: not valid in the mobile app
    user = me; role = r; state = SessionState.signedIn;
  }
  Future<void> requestOtp(String mobile, Role r) => api.post('/v1/auth/otp/request', body: {'mobile': mobile, 'role': r.name}, noAuth: true);
  Future<bool> verifyOtp(String mobile, Role r, String code, {String? name}) async {
    final res = await api.post('/v1/auth/otp/verify', body: {'mobile': mobile, 'role': r.name, 'code': code, if (name != null && name.isNotEmpty) 'name': name}, noAuth: true) as Map<String, dynamic>;
    await tokens.save(res['access_token'], res['refresh_token']);
    user = res['user']; role = roleFrom(user?['role']); state = SessionState.signedIn; notifyListeners();
    return res['is_new_user'] == true;
  }
  void setUser(Map<String, dynamic> u) { user = u; notifyListeners(); }
  Future<void> logout() async {
    final rt = tokens.refresh;
    if (rt != null) { try { await api.post('/v1/auth/logout', body: {'refresh_token': rt}); } catch (_) {} }
    await _expired();
  }
  Future<void> _expired() async { await tokens.clear(); user = null; role = null; state = SessionState.signedOut; notifyListeners(); }
}

import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/api_client.dart';
import '../../core/images.dart';
import '../../core/location.dart';
import '../../core/widgets.dart';
import '../../theme.dart';
import '../common/account_actions.dart';
import '../common/notifications_screen.dart';
import 'seller_products.dart';

class SellerShell extends StatefulWidget { const SellerShell({super.key}); @override State<SellerShell> createState() => _SSh(); }
class _SSh extends State<SellerShell> {
  Map<String, dynamic>? shop; bool loading = true, noShop = false; String? err; int i = 0;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    setState(() { loading = true; err = null; });
    try { shop = mapOf(await apiOf(context).get('/v1/seller/shop')); noShop = false; }
    on ApiException catch (e) { if (e.status == 404) { noShop = true; } else { err = e.message; } }
    if (mounted) setState(() => loading = false);
  }
  @override Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (err != null) return Scaffold(body: ErrorView(message: err!, onRetry: _load));
    if (noShop) return ShopFormScreen(onSaved: _load);
    if (shop!['approval_status'] != 'approved') return _Waiting(shop: shop!, onRefresh: _load);
    final pages = <Widget>[SellerDashboard(shop: shop!, onChanged: _load), const SellerOrders(), const SellerProducts(), SellerProfile(shop: shop!, onChanged: _load)];
    return Scaffold(body: SafeArea(child: IndexedStack(index: i, children: pages)), bottomNavigationBar: NavigationBar(selectedIndex: i, onDestinationSelected: (x) => setState(() => i = x), destinations: const [
      NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Dashboard'),
      NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Orders'),
      NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'Products'),
      NavigationDestination(icon: Icon(Icons.store_outlined), selectedIcon: Icon(Icons.store), label: 'Shop')]));
  }
}

class _Waiting extends StatelessWidget {
  const _Waiting({required this.shop, required this.onRefresh}); final Map<String, dynamic> shop; final VoidCallback onRefresh;
  @override Widget build(BuildContext context) {
    final rejected = shop['approval_status'] == 'rejected' || shop['approval_status'] == 'suspended';
    return Scaffold(appBar: AppBar(title: Text('${shop['name']}')), body: ListView(padding: const EdgeInsets.all(24), children: [
      const SizedBox(height: 40), Icon(rejected ? Icons.block : Icons.hourglass_top, size: 72, color: rejected ? Colors.red : GC.saffron), const SizedBox(height: 16),
      Text(rejected ? 'Your shop was ${shop['approval_status']}' : 'Your shop is waiting for approval', textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 8), Text(rejected ? '${shop['rejection_reason'] ?? 'Please contact support.'}' : 'We review every shop before it goes live. You will get a notification once it is approved. You can already add your products.', textAlign: TextAlign.center),
      const SizedBox(height: 24), FilledButton(onPressed: onRefresh, child: const Text('Check status')),
      if (!rejected) OutlinedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: const Text('Products')), body: const SellerProducts()))), child: const Text('Add products now')),
      const AccountActions()]));
  }
}

/// Create (POST) or edit (PATCH) the shop profile.
class ShopFormScreen extends StatefulWidget { const ShopFormScreen({super.key, this.existing, required this.onSaved}); final Map<String, dynamic>? existing; final VoidCallback onSaved; @override State<ShopFormScreen> createState() => _SF(); }
class _SF extends State<ShopFormScreen> {
  final form = GlobalKey<FormState>(); late final name = TextEditingController(text: widget.existing?['name']), desc = TextEditingController(text: widget.existing?['description']), address = TextEditingController(text: widget.existing?['address']), village = TextEditingController(text: widget.existing?['village']), pin = TextEditingController(text: widget.existing?['pincode']), minOrder = TextEditingController(text: widget.existing == null || widget.existing!['min_order_paise'] == 0 ? '' : '${widget.existing!['min_order_paise'] / 100}');
  double? lat, lng; String? logo, cover; int? opens, closes; Set<String> cats = {}; List<Map<String, dynamic>> allCats = []; bool busy = false;
  @override void initState() { super.initState(); final e = widget.existing; if (e != null) { lat = e['lat']; lng = e['lng']; logo = e['logo_url']; cover = e['cover_url']; opens = e['opens_min']; closes = e['closes_min']; cats = listOf(e['categories']).map((c) => c['id'] as String).toSet(); } _cats(); }
  Future<void> _cats() async { try { final r = mapOf(await apiOf(context).get('/v1/categories', q: {'kind': 'shop'})); if (mounted) setState(() => allCats = listOf(r['items'])); } catch (_) {} }
  String _t(int? m) => m == null ? 'Not set' : TimeOfDay(hour: m ~/ 60, minute: m % 60).format(context);
  Future<void> _pick(bool open) async { final t = await showTimePicker(context: context, initialTime: TimeOfDay(hour: (open ? opens : closes) != null ? (open ? opens! : closes!) ~/ 60 : (open ? 8 : 21), minute: 0)); if (t != null) setState(() => open ? opens = t.hour * 60 + t.minute : closes = t.hour * 60 + t.minute); }
  Future<void> _save() async {
    if (!form.currentState!.validate()) return;
    if (lat == null) { toast(context, 'Tap "Use shop location" while standing at your shop.'); return; }
    if ((opens == null) != (closes == null)) { toast(context, 'Set both opening and closing time, or neither.'); return; }
    setState(() => busy = true);
    final body = {'name': name.text.trim(), if (desc.text.trim().isNotEmpty) 'description': desc.text.trim(), 'address': address.text.trim(), if (village.text.trim().isNotEmpty) 'village': village.text.trim(), if (pin.text.trim().isNotEmpty) 'pincode': pin.text.trim(), 'lat': lat, 'lng': lng, if (opens != null) 'opens_min': opens, if (closes != null) 'closes_min': closes, if (minOrder.text.trim().isNotEmpty) 'min_order_paise': toPaise(minOrder.text), if (logo != null) 'logo_url': logo, if (cover != null) 'cover_url': cover, 'category_ids': cats.toList()};
    final api = apiOf(context);
    final r = await guard(context, () => widget.existing == null ? api.post('/v1/seller/shop', body: body) : api.patch('/v1/seller/shop', body: body));
    if (!mounted) return; setState(() => busy = false);
    if (r != null) { widget.onSaved(); if (widget.existing != null) Navigator.pop(context); }
  }
  Widget _f(TextEditingController c, String l, {bool req = true, int lines = 1, TextInputType? t, String? Function(String?)? v}) => Padding(padding: const EdgeInsets.only(bottom: 12), child: TextFormField(controller: c, maxLines: lines, keyboardType: t, decoration: InputDecoration(labelText: l), validator: v ?? (req ? (x) => (x == null || x.trim().isEmpty) ? 'Required' : null : null)));
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(widget.existing == null ? 'Register your shop' : 'Edit shop')), body: Form(key: form, child: ListView(padding: const EdgeInsets.all(16), children: [
    Row(children: [Expanded(child: _imgBox('Logo', logo, () async { final u = await pickAndUpload(context, 'logo'); if (u != null) setState(() => logo = u); })), const SizedBox(width: 12), Expanded(child: _imgBox('Cover photo', cover, () async { final u = await pickAndUpload(context, 'cover'); if (u != null) setState(() => cover = u); }))]),
    const SizedBox(height: 16), _f(name, 'Shop name'), _f(desc, 'Description (optional)', req: false, lines: 3), _f(address, 'Shop address', lines: 2), _f(village, 'Village / town', req: false), _f(pin, 'Pincode', req: false, t: TextInputType.number, v: (x) => (x == null || x.isEmpty || RegExp(r'^\d{6}$').hasMatch(x)) ? null : '6 digits'),
    _f(minOrder, 'Minimum order in ₹ (optional)', req: false, t: TextInputType.number, v: (x) => (x == null || x.isEmpty || double.tryParse(x) != null) ? null : 'Enter a number'),
    OutlinedButton.icon(onPressed: () async { final p = await guard(context, currentPosition); if (p != null) setState(() { lat = p.latitude; lng = p.longitude; }); }, icon: const Icon(Icons.my_location), label: Text(lat == null ? 'Use shop location' : 'Location captured ✓ (tap to update)')),
    const Section('Opening hours'), Row(children: [Expanded(child: OutlinedButton(onPressed: () => _pick(true), child: Text('Opens: ${_t(opens)}'))), const SizedBox(width: 12), Expanded(child: OutlinedButton(onPressed: () => _pick(false), child: Text('Closes: ${_t(closes)}')))]),
    if (allCats.isNotEmpty) ...[const Section('Shop categories'), Wrap(spacing: 8, children: [for (final k in allCats) FilterChip(label: Text('${k['name']}'), selected: cats.contains(k['id']), onSelected: (v) => setState(() => v ? cats.add(k['id']) : cats.remove(k['id'])))])],
    const SizedBox(height: 24), FilledButton(onPressed: busy ? null : _save, child: busy ? const CircularProgressIndicator() : Text(widget.existing == null ? 'Submit for approval' : 'Save changes')),
    if (widget.existing == null) const AccountActions()])));
  Widget _imgBox(String l, String? url, VoidCallback onTap) => GestureDetector(onTap: onTap, child: Column(children: [NetImage(url, w: double.infinity, h: 90, icon: Icons.add_a_photo_outlined), const SizedBox(height: 4), Text(l, style: const TextStyle(fontSize: 12))]));
}

class SellerDashboard extends StatefulWidget { const SellerDashboard({super.key, required this.shop, required this.onChanged}); final Map<String, dynamic> shop; final VoidCallback onChanged; @override State<SellerDashboard> createState() => _SD(); }
class _SD extends State<SellerDashboard> {
  late bool online = widget.shop['is_online'] == 1; bool busy = false;
  @override Widget build(BuildContext context) {
    final api = apiOf(context);
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 12, 8, 0), child: Row(children: [Expanded(child: Text('${widget.shop['name']}', style: Theme.of(context).textTheme.headlineMedium)), IconButton(icon: const Icon(Icons.notifications_none), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsScreen())))])),
      Expanded(child: Loader<Map<String, dynamic>>(load: () async { final r = await Future.wait<dynamic>([api.get('/v1/seller/reports/sales'), api.get('/v1/seller/reports/earnings')]); return {'sales': mapOf(r[0]), 'earn': mapOf(r[1])}; },
        builder: (c, d, reload) { final sales = mapOf(d['sales']), t = mapOf(sales['totals']), earn = mapOf(d['earn']), top = listOf(sales['top_products']);
          return ListView(padding: const EdgeInsets.all(16), children: [
            Card(child: SwitchListTile(value: online, title: Text(online ? 'Shop is ONLINE' : 'Shop is OFFLINE', style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text(online ? 'Customers can see and order from you' : 'Hidden from customers'),
              onChanged: busy ? null : (v) async { setState(() => busy = true); final r = await guard(c, () => api.post('/v1/seller/shop/status', body: {'is_online': v})); if (r != null) online = v; if (mounted) setState(() => busy = false); })),
            const SizedBox(height: 8), Row(children: [_stat('Orders (30d)', '${t['orders']}'), const SizedBox(width: 12), _stat('Sales (30d)', rupees(t['gross_paise'] ?? 0))]), const SizedBox(height: 12),
            Row(children: [_stat('Your earnings (30d)', rupees(t['net_paise'] ?? 0)), const SizedBox(width: 12), _stat('Awaiting payout', rupees(earn['unsettled_paise'] ?? 0))]),
            const SizedBox(height: 12), Row(children: [_stat('Paid out', rupees(earn['paid_out_paise'] ?? 0)), const SizedBox(width: 12), _stat('Cancelled (30d)', '${t['cancelled_orders']}')]),
            const Section('Top products'), if (top.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('Sales will appear here after your first delivered order.', style: TextStyle(color: Colors.black54))),
            for (final p in top) ListTile(dense: true, title: Text('${p['name']}'), subtitle: Text('${p['qty']} sold'), trailing: Text(rupees(p['revenue_paise']))),
            const Section('Recent earnings'), for (final e in listOf(earn['entries']).take(10)) ListTile(dense: true, title: Text('Order #${e['number']}'), subtitle: Text(('${e['created_at']}').substring(0, 10)), trailing: Text(rupees(e['amount_paise']), style: const TextStyle(fontWeight: FontWeight.w700)), leading: Icon(e['settled'] == 1 ? Icons.check_circle : Icons.schedule, color: e['settled'] == 1 ? GC.green : Colors.black38))]); })),
    ]);
  }
  Widget _stat(String l, String v) => Expanded(child: Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(l, style: const TextStyle(color: Colors.black54, fontSize: 12)), const SizedBox(height: 4), Text(v, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800))]))));
}

class SellerOrders extends StatefulWidget { const SellerOrders({super.key}); @override State<SellerOrders> createState() => _SO(); }
class _SO extends State<SellerOrders> with SingleTickerProviderStateMixin {
  late final tab = TabController(length: 3, vsync: this); final keys = List.generate(3, (_) => GlobalKey<LoaderState<List<Map<String, dynamic>>>>()); Timer? t;
  static const groups = ['active', 'completed', 'cancelled'];
  @override void initState() { super.initState(); t = Timer.periodic(const Duration(seconds: 10), (_) => keys[tab.index].currentState?.reload()); }
  @override void dispose() { t?.cancel(); tab.dispose(); super.dispose(); }
  Future<void> _do(Map<String, dynamic> o, String action, {bool reason = false}) async {
    Map<String, dynamic>? body; if (reason) { final r = await askText(context, 'Reason for ${action == 'reject' ? 'rejecting' : 'cancelling'}', hint: 'e.g. Item not available'); if (r == null || r.isEmpty) return; body = {'reason': r}; }
    await guard(context, () => apiOf(context).post('/v1/seller/orders/${o['id']}/$action', body: body)); keys[tab.index].currentState?.reload();
  }
  @override Widget build(BuildContext context) => Column(children: [
    TabBar(controller: tab, tabs: const [Tab(text: 'Active'), Tab(text: 'Completed'), Tab(text: 'Cancelled')]),
    Expanded(child: TabBarView(controller: tab, children: [for (var i = 0; i < 3; i++) Loader<List<Map<String, dynamic>>>(key: keys[i], load: () async => listOf(mapOf(await apiOf(context).get('/v1/seller/orders', q: {'group': groups[i]}))['items']), isEmpty: (l) => l.isEmpty, emptyText: i == 0 ? 'No active orders.\nNew orders appear here instantly.' : 'Nothing here yet', emptyIcon: Icons.receipt_long_outlined,
      builder: (c, items, reload) => ListView(padding: const EdgeInsets.all(12), children: [for (final o in items) _card(c, o)]))])),
  ]);
  Widget _card(BuildContext c, Map<String, dynamic> o) {
    final st = o['status'] as String, items = listOf(o['items']);
    return Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Text('#${o['number']}', style: Theme.of(c).textTheme.titleMedium)), StatusChip(st)]), const SizedBox(height: 6),
      for (final i in items) Text('${i['qty']} × ${i['name']}'), const SizedBox(height: 6),
      Text('${rupees(o['subtotal_paise'])} items • ${o['payment_method'] == 'cod' ? 'Cash on delivery' : 'Paid online'}', style: const TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 6), Text('${mapOf(o['customer'])['name'] ?? ''} • ${mapOf(o['address'])['line']}', style: const TextStyle(color: Colors.black54)),
      if (o['note'] != null) Text('Note: ${o['note']}', style: const TextStyle(fontStyle: FontStyle.italic)),
      Row(children: [TextButton.icon(onPressed: () => callPhone(mapOf(o['customer'])['phone']), icon: const Icon(Icons.call, size: 18), label: const Text('Call customer'))]),
      if (st == 'placed') Row(children: [Expanded(child: OutlinedButton(onPressed: () => _do(o, 'reject', reason: true), child: const Text('Reject'))), const SizedBox(width: 8), Expanded(child: FilledButton(onPressed: () => _do(o, 'accept'), child: const Text('Accept')))]),
      if (st == 'accepted') FilledButton(onPressed: () => _do(o, 'preparing'), child: const Text('Start preparing')),
      if (st == 'preparing') FilledButton(onPressed: () => _do(o, 'ready'), child: const Text('Mark ready for pickup')),
      if (['accepted', 'preparing', 'ready_for_pickup'].contains(st)) TextButton(onPressed: () => _do(o, 'cancel', reason: true), child: const Text('Cancel order', style: TextStyle(color: Colors.red))),
      if (st == 'ready_for_pickup') const Text('Waiting for a delivery partner…', style: TextStyle(color: Colors.black54)),
    ])));
  }
}

class SellerProfile extends StatelessWidget {
  const SellerProfile({super.key, required this.shop, required this.onChanged}); final Map<String, dynamic> shop; final VoidCallback onChanged;
  @override Widget build(BuildContext context) {
    final api = apiOf(context);
    return ListView(children: [
      Padding(padding: const EdgeInsets.all(16), child: Row(children: [NetImage(shop['logo_url'], w: 64, h: 64, icon: Icons.storefront), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${shop['name']}', style: Theme.of(context).textTheme.titleMedium), Text('${shop['address']}', maxLines: 2, overflow: TextOverflow.ellipsis)]))])),
      ListTile(leading: const Icon(Icons.edit_outlined), title: const Text('Edit shop details & hours'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ShopFormScreen(existing: shop, onSaved: onChanged)))),
      ListTile(leading: const Icon(Icons.account_balance_wallet_outlined), title: const Text('Payout UPI ID'), subtitle: const Text('Where we send your earnings'), onTap: () async { final u = await askText(context, 'Your UPI ID', hint: 'name@bank'); if (u != null && u.isNotEmpty) { final r = await guard(context, () => api.patch('/v1/seller/profile', body: {'payout_upi': u})); if (r != null && context.mounted) toast(context, 'Saved'); } }),
      ListTile(leading: const Icon(Icons.payments_outlined), title: const Text('Payout history'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: const Text('Payouts')), body: Loader<List<Map<String, dynamic>>>(load: () async => listOf(mapOf(await api.get('/v1/seller/reports/payments'))['items']), isEmpty: (l) => l.isEmpty, emptyText: 'No payouts yet', emptyIcon: Icons.payments_outlined,
        builder: (c, l, r) => ListView(children: [for (final p in l) ListTile(title: Text(rupees(p['amount_paise'])), subtitle: Text('${p['status']}${p['reference'] != null ? ' • ref ${p['reference']}' : ''}'), trailing: Text(('${p['created_at']}').substring(0, 10)))])))))),
      ListTile(leading: const Icon(Icons.support_agent), title: const Text('Help & support'), onTap: () async { final t = await askText(context, 'Describe your problem'); if (t == null || t.length < 5) return; final r = await guard(context, () => api.post('/v1/support/tickets', body: {'subject': t.length > 60 ? t.substring(0, 60) : t, 'body': t})); if (r != null && context.mounted) toast(context, 'Ticket created'); }),
      const AccountActions()]);
  }
}

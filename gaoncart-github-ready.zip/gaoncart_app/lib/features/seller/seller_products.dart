import 'package:flutter/material.dart';
import '../../core/images.dart';
import '../../core/widgets.dart';
import '../../theme.dart';

class SellerProducts extends StatefulWidget { const SellerProducts({super.key}); @override State<SellerProducts> createState() => _SP(); }
class _SP extends State<SellerProducts> {
  final key = GlobalKey<LoaderState<List<Map<String, dynamic>>>>();
  Future<void> _open([Map<String, dynamic>? p]) async { final ok = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => ProductForm(product: p))); if (ok == true) key.currentState?.reload(); }
  @override Widget build(BuildContext context) {
    final api = apiOf(context);
    return Scaffold(floatingActionButton: FloatingActionButton.extended(onPressed: _open, icon: const Icon(Icons.add), label: const Text('Add product')),
      body: Loader<List<Map<String, dynamic>>>(key: key, load: () async => listOf(mapOf(await api.get('/v1/seller/products'))['items']), isEmpty: (l) => l.isEmpty, emptyText: 'No products yet.\nTap “Add product” to start selling.', emptyIcon: Icons.inventory_2_outlined,
        builder: (c, items, reload) => ListView(padding: const EdgeInsets.fromLTRB(12, 12, 12, 90), children: [for (final p in items) Card(child: ListTile(onTap: () => _open(p), leading: NetImage(p['image_url'], w: 52, h: 52),
          title: Text('${p['name']}'), subtitle: Text('${rupees(p['price_paise'])} • ${p['stock_qty'] == 0 ? 'OUT OF STOCK' : '${p['stock_qty']} in stock'}${p['is_blocked'] == 1 ? ' • BLOCKED by admin' : ''}', style: TextStyle(color: p['stock_qty'] == 0 || p['is_blocked'] == 1 ? Colors.red : null)),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            IconButton(tooltip: 'Update stock', icon: const Icon(Icons.inventory_outlined), onPressed: () async { final t = await askText(c, 'New stock quantity', number: true); final n = int.tryParse(t ?? ''); if (n == null) return; await guard(c, () => api.patch('/v1/seller/products/${p['id']}/stock', body: {'stock_qty': n})); reload(); }),
            Switch(value: p['is_available'] == 1, activeColor: GC.green, onChanged: (v) async { await guard(c, () => api.patch('/v1/seller/products/${p['id']}', body: {'is_available': v})); reload(); })])))])));
  }
}

class ProductForm extends StatefulWidget { const ProductForm({super.key, this.product}); final Map<String, dynamic>? product; @override State<ProductForm> createState() => _PF(); }
class _PF extends State<ProductForm> {
  final form = GlobalKey<FormState>(); late final name = TextEditingController(text: widget.product?['name']), desc = TextEditingController(text: widget.product?['description']), price = TextEditingController(text: widget.product == null ? '' : '${widget.product!['price_paise'] / 100}'), stock = TextEditingController(text: '${widget.product?['stock_qty'] ?? ''}');
  String? image; String? categoryId; bool available = true, busy = false; List<Map<String, dynamic>> cats = [];
  @override void initState() { super.initState(); image = widget.product?['image_url']; available = widget.product == null || widget.product!['is_available'] == 1; categoryId = widget.product?['category_id']; _cats(); }
  Future<void> _cats() async { try { final r = mapOf(await apiOf(context).get('/v1/categories', q: {'kind': 'product'})); if (mounted) setState(() => cats = listOf(r['items'])); } catch (_) {} }
  Future<void> _save() async {
    if (!form.currentState!.validate()) return; setState(() => busy = true);
    final api = apiOf(context), edit = widget.product != null;
    final body = {'name': name.text.trim(), if (desc.text.trim().isNotEmpty) 'description': desc.text.trim(), 'price_paise': toPaise(price.text), if (image != null) 'image_url': image, if (categoryId != null) 'category_id': categoryId, 'is_available': available, if (!edit) 'stock_qty': int.parse(stock.text.trim())};
    final r = await guard(context, () => edit ? api.patch('/v1/seller/products/${widget.product!['id']}', body: body) : api.post('/v1/seller/products', body: body));
    if (!mounted) return; setState(() => busy = false); if (r != null) Navigator.pop(context, true);
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(widget.product == null ? 'Add product' : 'Edit product'), actions: [
    if (widget.product != null) IconButton(icon: const Icon(Icons.delete_outline, color: Colors.red), onPressed: () async { if (!await confirm(context, 'Delete product?', 'It will be removed from your shop and from customers’ carts.', yes: 'Delete')) return; final r = await guard(context, () async { await apiOf(context).delete('/v1/seller/products/${widget.product!['id']}'); return true; }); if (r == true && mounted) Navigator.pop(context, true); })]),
    body: Form(key: form, child: ListView(padding: const EdgeInsets.all(16), children: [
      GestureDetector(onTap: () async { final u = await pickAndUpload(context, 'product'); if (u != null) setState(() => image = u); }, child: NetImage(image, w: double.infinity, h: 160, icon: Icons.add_a_photo_outlined)), const Padding(padding: EdgeInsets.only(top: 4, bottom: 12), child: Text('Tap to add a clear photo', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, fontSize: 12))),
      TextFormField(controller: name, decoration: const InputDecoration(labelText: 'Product name'), validator: (x) => (x == null || x.trim().isEmpty) ? 'Required' : null), const SizedBox(height: 12),
      TextFormField(controller: desc, maxLines: 3, decoration: const InputDecoration(labelText: 'Description (optional)')), const SizedBox(height: 12),
      TextFormField(controller: price, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Price (₹)', prefixText: '₹ '), validator: (x) { final v = double.tryParse(x ?? ''); return v == null || v < 1 ? 'Enter a price of at least ₹1' : null; }), const SizedBox(height: 12),
      if (widget.product == null) ...[TextFormField(controller: stock, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Stock quantity'), validator: (x) { final v = int.tryParse(x ?? ''); return v == null || v < 0 ? 'Enter 0 or more' : null; }), const SizedBox(height: 12)],
      if (cats.isNotEmpty) DropdownButtonFormField<String>(value: categoryId, decoration: const InputDecoration(labelText: 'Category (optional)'), items: [for (final c in cats) DropdownMenuItem(value: c['id'] as String, child: Text('${c['name']}'))], onChanged: (v) => setState(() => categoryId = v)),
      SwitchListTile(value: available, onChanged: (v) => setState(() => available = v), title: const Text('Available for sale')),
      const SizedBox(height: 12), FilledButton(onPressed: busy ? null : _save, child: busy ? const CircularProgressIndicator() : const Text('Save product'))])));
}

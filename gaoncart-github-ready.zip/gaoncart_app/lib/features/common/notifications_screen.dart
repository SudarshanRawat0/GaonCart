import 'package:flutter/material.dart';
import '../../core/widgets.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});
  @override Widget build(BuildContext context) {
    final api = apiOf(context);
    return Scaffold(appBar: AppBar(title: const Text('Notifications'), actions: [TextButton(onPressed: () async { await guard(context, () => api.post('/v1/notifications/read-all')); }, child: const Text('Mark all read'))]),
      body: Loader<List<Map<String, dynamic>>>(load: () async => listOf(mapOf(await api.get('/v1/notifications'))['items']), isEmpty: (l) => l.isEmpty, emptyText: 'No notifications yet', emptyIcon: Icons.notifications_none,
        builder: (c, items, reload) => ListView.separated(itemCount: items.length, separatorBuilder: (_, __) => const Divider(height: 1), itemBuilder: (_, i) {
          final n = items[i]; final unread = n['read_at'] == null;
          return ListTile(tileColor: unread ? Colors.white : null, leading: Icon(Icons.notifications, color: unread ? Colors.orange : Colors.black26), title: Text('${n['title']}', style: TextStyle(fontWeight: unread ? FontWeight.w700 : FontWeight.w400)), subtitle: Text('${n['body'] ?? ''}'),
            onTap: () async { if (unread) { await api.post('/v1/notifications/${n['id']}/read'); reload(); } });
        })));
  }
}

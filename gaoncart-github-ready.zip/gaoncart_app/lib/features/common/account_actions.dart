import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/widgets.dart';
import '../auth/session.dart';
import 'notifications_screen.dart';

/// Shared by all roles: notifications, logout, and account deletion (Play Store / DPDP requirement).
class AccountActions extends StatelessWidget {
  const AccountActions({super.key});
  @override Widget build(BuildContext context) {
    final s = context.read<Session>();
    return Column(children: [
      ListTile(leading: const Icon(Icons.notifications_outlined), title: const Text('Notifications'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsScreen()))),
      ListTile(leading: const Icon(Icons.logout), title: const Text('Log out'), onTap: () async { if (await confirm(context, 'Log out?', 'You will need an OTP to log in again.')) s.logout(); }),
      ListTile(leading: const Icon(Icons.delete_outline, color: Colors.red), title: const Text('Delete my account', style: TextStyle(color: Colors.red)), onTap: () async {
        if (!await confirm(context, 'Delete account?', 'This permanently removes your personal data. Order records are kept without your identity for legal accounting. This cannot be undone.', yes: 'Delete')) return;
        final ok = await guard(context, () async { await s.api.delete('/v1/me'); return true; });
        if (ok == true) s.logout();
      }),
    ]);
  }
}

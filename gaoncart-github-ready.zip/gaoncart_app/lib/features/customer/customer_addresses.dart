import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/location.dart';
import '../../core/widgets.dart';
import '../auth/session.dart';

class AddressesScreen extends StatelessWidget {
  const AddressesScreen({super.key, this.select = false});
  final bool select;
  @override Widget build(BuildContext context) {
    final api = apiOf(context); final key = GlobalKey<LoaderState<List<Map<String, dynamic>>>>();
    return Scaffold(appBar: AppBar(title: Text(select ? 'Choose address' : 'Delivery addresses')),
      floatingActionButton: FloatingActionButton.extended(icon: const Icon(Icons.add_location_alt_outlined), label: const Text('Add address'), onPressed: () async { final ok = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => const AddAddressScreen())); if (ok == true) key.currentState?.reload(); }),
      body: Loader<List<Map<String, dynamic>>>(key: key, load: () async => listOf(mapOf(await api.get('/v1/customer/addresses'))['items']), isEmpty: (l) => l.isEmpty, emptyText: 'No saved addresses yet', emptyIcon: Icons.location_off_outlined,
        builder: (c, items, reload) => ListView(padding: const EdgeInsets.only(bottom: 90), children: [for (final a in items) ListTile(leading: Icon(a['is_default'] == 1 ? Icons.home : Icons.location_on_outlined), title: Text('${a['label'] ?? a['recipient_name']}'), subtitle: Text('${a['line1']}${a['village'] != null ? ', ${a['village']}' : ''}\n${a['phone']}'), isThreeLine: true,
          onTap: select ? () => Navigator.pop(c, a['id']) : null,
          trailing: select ? null : IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async { if (await confirm(c, 'Delete address?', '${a['line1']}')) { await guard(c, () => api.delete('/v1/customer/addresses/${a['id']}')); reload(); } }))])));
  }
}

class AddAddressScreen extends StatefulWidget { const AddAddressScreen({super.key}); @override State<AddAddressScreen> createState() => _AA(); }
class _AA extends State<AddAddressScreen> {
  final name = TextEditingController(), phone = TextEditingController(), line1 = TextEditingController(), landmark = TextEditingController(), village = TextEditingController(), pin = TextEditingController(), label = TextEditingController();
  double? lat, lng; bool busy = false; final form = GlobalKey<FormState>();
  @override void initState() { super.initState(); final u = context.read<Session>().user; name.text = '${u?['name'] ?? ''}'; phone.text = '${u?['mobile'] ?? ''}'; }
  Future<void> _gps() async { final p = await guard(context, currentPosition); if (p != null) setState(() { lat = p.latitude; lng = p.longitude; }); }
  Future<void> _save() async {
    if (!form.currentState!.validate()) return;
    if (lat == null) { toast(context, 'Tap "Use my current location" so the delivery partner can find you.'); return; }
    setState(() => busy = true);
    final r = await guard(context, () => apiOf(context).post('/v1/customer/addresses', body: {'recipient_name': name.text.trim(), 'phone': phone.text.trim(), 'line1': line1.text.trim(), if (landmark.text.trim().isNotEmpty) 'landmark': landmark.text.trim(), if (village.text.trim().isNotEmpty) 'village': village.text.trim(), if (pin.text.trim().isNotEmpty) 'pincode': pin.text.trim(), if (label.text.trim().isNotEmpty) 'label': label.text.trim(), 'lat': lat, 'lng': lng}));
    if (mounted) { setState(() => busy = false); if (r != null) Navigator.pop(context, true); }
  }
  Widget _f(TextEditingController c, String l, {bool req = true, TextInputType? t, int? max, String? Function(String?)? v}) => Padding(padding: const EdgeInsets.only(bottom: 12), child: TextFormField(controller: c, keyboardType: t, maxLength: max, decoration: InputDecoration(labelText: l, counterText: ''), validator: v ?? (req ? (x) => (x == null || x.trim().isEmpty) ? 'Required' : null : null)));
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('New address')), body: Form(key: form, child: ListView(padding: const EdgeInsets.all(16), children: [
    _f(name, 'Recipient name'), _f(phone, 'Phone', t: TextInputType.phone, max: 10, v: (x) => RegExp(r'^[6-9]\d{9}$').hasMatch(x ?? '') ? null : 'Enter a 10-digit mobile number'),
    _f(line1, 'House / street / area'), _f(landmark, 'Landmark (optional)', req: false), _f(village, 'Village / town', req: false), _f(pin, 'Pincode (optional)', req: false, t: TextInputType.number, max: 6, v: (x) => (x == null || x.isEmpty || RegExp(r'^\d{6}$').hasMatch(x)) ? null : '6 digits'), _f(label, 'Label e.g. Home (optional)', req: false),
    OutlinedButton.icon(onPressed: _gps, icon: const Icon(Icons.my_location), label: Text(lat == null ? 'Use my current location' : 'Location captured ✓')),
    const SizedBox(height: 16), FilledButton(onPressed: busy ? null : _save, child: busy ? const CircularProgressIndicator() : const Text('Save address'))])));
}

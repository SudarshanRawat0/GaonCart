import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import '../../core/api_client.dart';
import '../../core/widgets.dart';
import '../../theme.dart';
import '../auth/session.dart';
import 'customer_shop.dart';

/// Razorpay checkout. The app NEVER reports success on its own: it calls the backend, which re-verifies the
/// signature and fetches the payment from Razorpay. Only the backend's "paid" answer is trusted.
class PayFlow {
  static Future<void> start(BuildContext context, Map<String, dynamic> order) async {
    final pay = order['payment'] as Map?;
    if (pay == null) return;
    final api = apiOf(context); final mobile = context.read<Session>().user?['mobile'];
    final rz = Razorpay(); final done = Completer<void>(); String? msg;
    rz.on(Razorpay.EVENT_PAYMENT_SUCCESS, (PaymentSuccessResponse r) async {
      try { await api.post('/v1/customer/payments/verify', body: {'order_id': order['id'], 'razorpay_order_id': r.orderId, 'razorpay_payment_id': r.paymentId, 'razorpay_signature': r.signature}); msg = 'Payment confirmed'; }
      on ApiException catch (e) { msg = e.message; }
      if (!done.isCompleted) done.complete();
    });
    rz.on(Razorpay.EVENT_PAYMENT_ERROR, (PaymentFailureResponse r) { msg = 'Payment was not completed${r.message == null ? '' : ': ${r.message}'}'; if (!done.isCompleted) done.complete(); });
    rz.on(Razorpay.EVENT_EXTERNAL_WALLET, (ExternalWalletResponse r) {});
    rz.open({'key': pay['key_id'], 'amount': pay['amount_paise'], 'currency': 'INR', 'order_id': pay['gateway_order_id'], 'name': 'GaonCart', 'description': 'Order ${order['number']}', 'prefill': {'contact': mobile}});
    await done.future; rz.clear();
    if (context.mounted && msg != null) toast(context, msg!);
  }
}

class OrdersTab extends StatelessWidget {
  const OrdersTab({super.key});
  @override Widget build(BuildContext context) {
    final api = apiOf(context);
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 16, 16, 8), child: Align(alignment: Alignment.centerLeft, child: Text('My orders', style: Theme.of(context).textTheme.headlineMedium))),
      Expanded(child: Loader<List<Map<String, dynamic>>>(load: () async => listOf(mapOf(await api.get('/v1/customer/orders'))['items']), isEmpty: (l) => l.isEmpty, emptyText: 'No orders yet.\nYour orders will show up here.', emptyIcon: Icons.receipt_long_outlined,
        builder: (c, items, reload) => ListView(padding: const EdgeInsets.symmetric(horizontal: 16), children: [for (final o in items) Card(child: ListTile(
          leading: NetImage(o['shop_logo'], w: 48, h: 48, icon: Icons.storefront), title: Text('${o['shop_name']}'), subtitle: Text('#${o['number']} • ${o['item_count']} item(s) • ${rupees(o['total_paise'])}\n${('${o['created_at']}').substring(0, 10)}'), isThreeLine: true, trailing: StatusChip(o['status']),
          onTap: () async { await Navigator.push(c, MaterialPageRoute(builder: (_) => OrderDetailScreen(orderId: o['id']))); reload(); }))]))),
    ]);
  }
}

double _km(num la1, num lo1, num la2, num lo2) { double r(num d) => d * pi / 180; final a = pow(sin(r(la2 - la1) / 2), 2) + cos(r(la1)) * cos(r(la2)) * pow(sin(r(lo2 - lo1) / 2), 2); return 12742 * asin(sqrt(a)); }

class OrderDetailScreen extends StatefulWidget { const OrderDetailScreen({super.key, required this.orderId}); final String orderId; @override State<OrderDetailScreen> createState() => _OD(); }
class _OD extends State<OrderDetailScreen> {
  Map<String, dynamic>? o, tr; String? err; Timer? timer;
  @override void initState() { super.initState(); _poll(); timer = Timer.periodic(const Duration(seconds: 6), (_) => _poll()); }
  @override void dispose() { timer?.cancel(); super.dispose(); }
  Future<void> _poll() async {
    try {
      final api = apiOf(context); final x = mapOf(await api.get('/v1/customer/orders/${widget.orderId}'));
      Map<String, dynamic>? t; if (['assigned', 'picked_up', 'out_for_delivery'].contains(x['status'])) t = mapOf(await api.get('/v1/customer/orders/${widget.orderId}/tracking'));
      if (mounted) setState(() { o = x; tr = t; err = null; });
    } on ApiException catch (e) { if (mounted && o == null) setState(() => err = e.message); }
  }
  @override Widget build(BuildContext context) {
    if (o == null) return Scaffold(appBar: AppBar(), body: err != null ? ErrorView(message: err!, onRetry: _poll) : const Center(child: CircularProgressIndicator()));
    final order = o!; final st = order['status'] as String; final api = apiOf(context);
    final items = listOf(order['items']); final events = listOf(order['events']); final shop = mapOf(order['shop']); final addr = mapOf(order['address']);
    final loc = tr?['partner_location'] as Map?;
    return Scaffold(appBar: AppBar(title: Text('Order #${order['number']}')), body: RefreshIndicator(onRefresh: _poll, child: ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [Expanded(child: Text('${shop['name']}', style: Theme.of(context).textTheme.titleMedium)), StatusChip(st)]),
      if (st == 'pending_payment') Card(color: const Color(0xFFFFF4DD), child: ListTile(title: const Text('Payment not completed'), subtitle: const Text('Complete it within 15 minutes or the order will be cancelled.'), trailing: FilledButton(style: FilledButton.styleFrom(minimumSize: const Size(90, 40)), onPressed: () async { await PayFlow.start(context, order); _poll(); }, child: const Text('Pay now')))),
      if (order['delivery_code'] != null) Card(color: GC.green.withOpacity(.08), child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [const Text('Delivery code — share only when you receive the order'), const SizedBox(height: 6), Text('${order['delivery_code']}', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 8, color: GC.green))]))),
      if (order['partner'] != null) Card(child: ListTile(leading: const Icon(Icons.two_wheeler, color: GC.green), title: Text('${order['partner']['name'] ?? 'Delivery partner'}'), subtitle: const Text('Your delivery partner'), trailing: IconButton(icon: const Icon(Icons.call), onPressed: () => callPhone(order['partner']['phone'])))),
      if (tr != null) Card(child: ListTile(leading: const Icon(Icons.my_location, color: GC.green), title: Text(loc == null ? 'Waiting for the partner’s location…' : 'Live location • ${_km(loc['lat'], loc['lng'], addr['lat'], addr['lng']).toStringAsFixed(1)} km from you'), subtitle: loc == null ? null : Text('Updated ${('${loc['recorded_at']}').substring(11, 19)} UTC'),
        trailing: loc == null ? null : TextButton(onPressed: () => navigateTo(loc['lat'], loc['lng']), child: const Text('View map')))),
      const Section('Status'),
      for (final e in events.reversed) ListTile(dense: true, leading: const Icon(Icons.check_circle, color: GC.green, size: 20), title: Text(StatusChip.names[e['status']] ?? '${e['status']}'), subtitle: Text(('${e['created_at']}').replaceFirst('T', ' ').substring(0, 16) + (e['note'] != null ? ' • ${e['note']}' : ''))),
      const Section('Items'),
      for (final i in items) ListTile(dense: true, title: Text('${i['qty']} × ${i['name']}'), trailing: Text(rupees(i['price_paise'] * i['qty']))),
      const Divider(), _r('Item total', order['subtotal_paise']), _r('Delivery fee', order['delivery_fee_paise']), _r('Total', order['total_paise'], bold: true),
      Padding(padding: const EdgeInsets.only(top: 8), child: Text('${order['payment_method'] == 'cod' ? 'Cash on Delivery' : 'Paid online'} • payment ${order['payment_status']}', style: const TextStyle(color: Colors.black54))),
      const Section('Delivering to'), Text('${addr['name']}\n${addr['line']}\n${addr['phone']}'),
      const SizedBox(height: 20),
      if (['pending_payment', 'placed', 'accepted'].contains(st)) OutlinedButton(onPressed: () async { if (!await confirm(context, 'Cancel order?', 'Any online payment will be refunded.')) return; await guard(context, () => api.post('/v1/customer/orders/${order['id']}/cancel', body: {})); _poll(); }, child: const Text('Cancel order')),
      if (st == 'delivered' && order['reviewed'] != true) FilledButton(onPressed: _review, child: const Text('Rate this order')),
      if (['delivered', 'cancelled', 'rejected'].contains(st)) Padding(padding: const EdgeInsets.only(top: 8), child: OutlinedButton(onPressed: () async { final r = await guard(context, () => api.post('/v1/customer/orders/${order['id']}/reorder')); if (r != null && mounted) { final m = mapOf(r); if ((m['skipped'] as List).isNotEmpty) toast(context, 'Unavailable: ${(m['skipped'] as List).join(', ')}'); Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen())); } }, child: const Text('Order again'))),
      TextButton(onPressed: () async { final t = await askText(context, 'What went wrong?'); if (t == null || t.length < 5) return; final r = await guard(context, () => api.post('/v1/support/tickets', body: {'subject': 'Order #${order['number']}', 'body': t, 'category': 'order', 'order_id': order['id']})); if (r != null && mounted) toast(context, 'Support ticket created'); }, child: const Text('Need help with this order?')),
    ])));
  }
  Future<void> _review() async {
    int stars = 5; final t = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (c) => StatefulBuilder(builder: (c, set) => AlertDialog(title: const Text('Rate your order'), content: Column(mainAxisSize: MainAxisSize.min, children: [
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [for (var i = 1; i <= 5; i++) IconButton(onPressed: () => set(() => stars = i), icon: Icon(i <= stars ? Icons.star : Icons.star_border, color: GC.saffron, size: 32))]), TextField(controller: t, maxLength: 500, decoration: const InputDecoration(hintText: 'Comments (optional)'))]),
      actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Later')), FilledButton(style: FilledButton.styleFrom(minimumSize: const Size(80, 40)), onPressed: () => Navigator.pop(c, true), child: const Text('Submit'))])));
    if (ok == true) { await guard(context, () => apiOf(context).post('/v1/customer/orders/${widget.orderId}/review', body: {'shop_rating': stars, if (t.text.trim().isNotEmpty) 'comment': t.text.trim()})); _poll(); }
  }
  Widget _r(String l, num v, {bool bold = false}) => Padding(padding: const EdgeInsets.symmetric(vertical: 2), child: Row(children: [Expanded(child: Text(l, style: TextStyle(fontWeight: bold ? FontWeight.w800 : null))), Text(rupees(v), style: TextStyle(fontWeight: bold ? FontWeight.w800 : null))]));
}

import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/api_client.dart';
import '../../core/widgets.dart';
import '../../theme.dart';
import 'customer_addresses.dart';
import 'customer_orders.dart';

class ShopScreen extends StatefulWidget { const ShopScreen({super.key, required this.shopId, this.lat, this.lng}); final String shopId; final double? lat, lng; @override State<ShopScreen> createState() => _SS(); }
class _SS extends State<ShopScreen> {
  Map<String, int> qty = {}; int count = 0, total = 0;
  @override void initState() { super.initState(); _syncCart(); }
  void _apply(Map<String, dynamic> cart) {
    final shop = cart['shop'] as Map?; final items = listOf(cart['items']);
    setState(() { qty = shop != null && shop['id'] == widget.shopId ? {for (final i in items) i['product_id'] as String: i['qty'] as int} : {}; count = qty.values.fold(0, (a, b) => a + b); total = shop != null && shop['id'] == widget.shopId ? cart['subtotal_paise'] as int : 0; });
  }
  Future<void> _syncCart() async { try { _apply(mapOf(await apiOf(context).get('/v1/customer/cart'))); } catch (_) {} }
  Future<void> _set(String pid, int q, {bool replace = false}) async {
    try { _apply(mapOf(await apiOf(context).put('/v1/customer/cart/items', body: {'product_id': pid, 'qty': q, if (replace) 'replace_cart': true}))); }
    on ApiException catch (e) {
      if (e.code == 'cart_other_shop' && mounted) { if (await confirm(context, 'Start a new cart?', 'Your cart has items from another shop. Clear it and add this item?', yes: 'Start new cart')) _set(pid, q, replace: true); }
      else if (mounted) toast(context, e.message);
    }
  }
  @override Widget build(BuildContext context) {
    final api = apiOf(context);
    return Scaffold(
      body: Loader<Map<String, dynamic>>(load: () async => mapOf(await api.get('/v1/customer/shops/${widget.shopId}', q: {if (widget.lat != null) 'lat': widget.lat, if (widget.lng != null) 'lng': widget.lng})),
        builder: (c, s, reload) {
          final products = listOf(s['products']);
          return CustomScrollView(slivers: [
            SliverAppBar(pinned: true, expandedHeight: 170, flexibleSpace: FlexibleSpaceBar(title: Text('${s['name']}', style: const TextStyle(shadows: [Shadow(blurRadius: 8)])), background: NetImage(s['cover_url'] ?? s['logo_url'], radius: 0, icon: Icons.storefront))),
            SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (s['description'] != null) Text('${s['description']}'), const SizedBox(height: 6),
              Text('${s['address']}', style: const TextStyle(color: Colors.black54)), Text('${s['distance_km']} km • ~${s['eta_min']} min${(s['rating_count'] ?? 0) > 0 ? ' • ${s['rating_avg']} ★ (${s['rating_count']})' : ''}', style: const TextStyle(color: Colors.black54))]))),
            SliverList.builder(itemCount: products.length, itemBuilder: (_, i) {
              final p = products[i]; final q = qty[p['id']] ?? 0; final can = p['purchasable'] == true;
              return Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 10), child: Card(child: Padding(padding: const EdgeInsets.all(10), child: Row(children: [
                Opacity(opacity: can ? 1 : .4, child: NetImage(p['image_url'], w: 84, h: 84)), const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${p['name']}', style: Theme.of(c).textTheme.titleMedium), if (p['description'] != null) Text('${p['description']}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.black54, fontSize: 12)),
                  const SizedBox(height: 4), Text(rupees(p['price_paise']), style: const TextStyle(fontWeight: FontWeight.w800)), if (p['low_stock'] != null) Text('Only ${p['low_stock']} left', style: const TextStyle(color: Colors.red, fontSize: 12))])),
                if (!can) const Text('Out of stock', style: TextStyle(color: Colors.black45))
                else if (q == 0) OutlinedButton(onPressed: () => _set(p['id'], 1), child: const Text('ADD'))
                else Row(children: [IconButton(onPressed: () => _set(p['id'], q - 1), icon: const Icon(Icons.remove_circle_outline)), Text('$q', style: const TextStyle(fontWeight: FontWeight.w800)), IconButton(onPressed: () => _set(p['id'], q + 1), icon: const Icon(Icons.add_circle, color: GC.green))])]))));
            }),
            const SliverToBoxAdapter(child: SizedBox(height: 90)),
          ]);
        }),
      bottomNavigationBar: count == 0 ? null : SafeArea(child: Padding(padding: const EdgeInsets.all(12), child: FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen())).then((_) => _syncCart()), child: Text('View cart • $count item${count > 1 ? 's' : ''} • ${rupees(total)}')))),
    );
  }
}

class CartScreen extends StatefulWidget { const CartScreen({super.key, this.embedded = false}); final bool embedded; @override State<CartScreen> createState() => _CartS(); }
class _CartS extends State<CartScreen> {
  final key = GlobalKey<LoaderState<Map<String, dynamic>>>();
  @override Widget build(BuildContext context) {
    final api = apiOf(context);
    final body = Loader<Map<String, dynamic>>(key: key, load: () async => mapOf(await api.get('/v1/customer/cart')), isEmpty: (c) => (c['items'] as List).isEmpty, emptyText: 'Your cart is empty.\nAdd items from a shop to get started.', emptyIcon: Icons.shopping_cart_outlined,
      builder: (c, cart, reload) {
        final items = listOf(cart['items']); final shop = cart['shop'] as Map?; final okAll = items.every((i) => i['available'] == true);
        Future<void> setQ(Map<String, dynamic> i, int q) async { await guard(c, () => api.put('/v1/customer/cart/items', body: {'product_id': i['product_id'], 'qty': q})); reload(); }
        return Column(children: [
          Expanded(child: ListView(padding: const EdgeInsets.all(16), children: [
            if (shop != null) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text('From ${shop['name']}', style: Theme.of(c).textTheme.titleMedium)),
            for (final i in items) Card(child: ListTile(leading: NetImage(i['image_url'], w: 52, h: 52), title: Text('${i['name']}'), subtitle: Text(i['available'] == true ? rupees(i['price_paise']) : 'Not available in this quantity', style: TextStyle(color: i['available'] == true ? null : Colors.red)),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [IconButton(onPressed: () => setQ(i, i['qty'] - 1), icon: const Icon(Icons.remove_circle_outline)), Text('${i['qty']}', style: const TextStyle(fontWeight: FontWeight.w800)), IconButton(onPressed: () => setQ(i, i['qty'] + 1), icon: const Icon(Icons.add_circle, color: GC.green))]))),
            const SizedBox(height: 8), Row(children: [const Expanded(child: Text('Item total')), Text(rupees(cart['subtotal_paise']))]), const SizedBox(height: 4), Row(children: [const Expanded(child: Text('Delivery fee')), Text(rupees(cart['delivery_fee_paise']))]),
            const Divider(height: 24), Row(children: [const Expanded(child: Text('To pay', style: TextStyle(fontWeight: FontWeight.w800))), Text(rupees(cart['subtotal_paise'] + cart['delivery_fee_paise']), style: const TextStyle(fontWeight: FontWeight.w800))]),
            TextButton(onPressed: () async { await guard(c, () => api.delete('/v1/customer/cart')); reload(); }, child: const Text('Clear cart'))])),
          SafeArea(child: Padding(padding: const EdgeInsets.all(12), child: FilledButton(onPressed: okAll ? () async { await Navigator.push(c, MaterialPageRoute(builder: (_) => const CheckoutScreen())); reload(); } : null, child: const Text('Proceed to checkout')))),
        ]);
      });
    return widget.embedded ? Column(children: [Padding(padding: const EdgeInsets.fromLTRB(16, 16, 16, 0), child: Align(alignment: Alignment.centerLeft, child: Text('Cart', style: Theme.of(context).textTheme.headlineMedium))), Expanded(child: body)]) : Scaffold(appBar: AppBar(title: const Text('Your cart')), body: body);
  }
}

class CheckoutScreen extends StatefulWidget { const CheckoutScreen({super.key}); @override State<CheckoutScreen> createState() => _CO(); }
class _CO extends State<CheckoutScreen> {
  List<Map<String, dynamic>> addrs = []; String? sel, error; Map<String, dynamic>? quote; String method = 'cod'; bool busy = false, loading = true;
  final note = TextEditingController(); final idem = 'co-${DateTime.now().microsecondsSinceEpoch}-${Random.secure().nextInt(1 << 30)}';
  @override void initState() { super.initState(); _init(); }
  Future<void> _init() async {
    try {
      addrs = listOf(mapOf(await apiOf(context).get('/v1/customer/addresses'))['items']);
      sel = addrs.isEmpty ? null : (addrs.firstWhere((a) => a['is_default'] == 1, orElse: () => addrs.first)['id'] as String);
      await _quote();
    } on ApiException catch (e) { error = e.message; }
    if (mounted) setState(() => loading = false);
  }
  Future<void> _quote() async {
    if (sel == null) return;
    try { quote = mapOf(await apiOf(context).post('/v1/customer/checkout/quote', body: {'address_id': sel})); error = null; if (quote!['online_payment_available'] != true && method == 'online') method = 'cod'; if (quote!['cod_available'] != true && method == 'cod') method = 'online'; }
    on ApiException catch (e) { quote = null; error = e.message; }
    if (mounted) setState(() {});
  }
  Future<void> _place() async {
    setState(() => busy = true);
    try {
      final o = mapOf(await apiOf(context).post('/v1/customer/orders', body: {'address_id': sel, 'payment_method': method, if (note.text.trim().isNotEmpty) 'note': note.text.trim()}, headers: {'Idempotency-Key': idem}));
      if (method == 'online') await PayFlow.start(context, o);
      if (mounted) Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => OrderDetailScreen(orderId: o['id'])), (r) => r.isFirst);
    } on ApiException catch (e) { if (mounted) toast(context, e.message); }
    if (mounted) setState(() => busy = false);
  }
  @override Widget build(BuildContext context) {
    if (loading) return Scaffold(appBar: AppBar(title: const Text('Checkout')), body: const Center(child: CircularProgressIndicator()));
    final a = addrs.where((x) => x['id'] == sel).firstOrNull;
    return Scaffold(appBar: AppBar(title: const Text('Checkout')), body: ListView(padding: const EdgeInsets.all(16), children: [
      Text('Deliver to', style: Theme.of(context).textTheme.titleMedium),
      Card(child: ListTile(leading: const Icon(Icons.location_on, color: GC.green), title: Text(a == null ? 'Add a delivery address' : '${a['recipient_name']}'), subtitle: a == null ? null : Text('${a['line1']}${a['village'] != null ? ', ${a['village']}' : ''}'), trailing: const Icon(Icons.chevron_right),
        onTap: () async { final id = await Navigator.push<String>(context, MaterialPageRoute(builder: (_) => const AddressesScreen(select: true))); if (id != null) { sel = id; await _init(); } })),
      if (error != null) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
      if (quote != null) ...[
        const SizedBox(height: 12), Text('Payment method', style: Theme.of(context).textTheme.titleMedium),
        RadioListTile<String>(value: 'cod', groupValue: method, onChanged: quote!['cod_available'] == true ? (v) => setState(() => method = v!) : null, title: const Text('Cash on Delivery'), subtitle: quote!['cod_available'] == true ? null : const Text('Not available for this order value')),
        RadioListTile<String>(value: 'online', groupValue: method, onChanged: quote!['online_payment_available'] == true ? (v) => setState(() => method = v!) : null, title: const Text('Pay online (UPI / cards / netbanking)'), subtitle: quote!['online_payment_available'] == true ? null : const Text('Currently unavailable')),
        TextField(controller: note, maxLength: 300, decoration: const InputDecoration(labelText: 'Note for the shop (optional)', counterText: '')),
        const SizedBox(height: 12), _row('Item total', quote!['subtotal_paise']), _row('Delivery fee (${quote!['distance_km']} km)', quote!['delivery_fee_paise']), if ((quote!['platform_fee_paise'] ?? 0) > 0) _row('Platform fee', quote!['platform_fee_paise']), const Divider(height: 24), _row('To pay', quote!['total_paise'], bold: true)],
    ]), bottomNavigationBar: SafeArea(child: Padding(padding: const EdgeInsets.all(12), child: FilledButton(onPressed: quote == null || busy ? null : _place, child: busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)) : Text(method == 'online' ? 'Pay ${quote == null ? '' : rupees(quote!['total_paise'])}' : 'Place order')))));
  }
  Widget _row(String l, num v, {bool bold = false}) => Padding(padding: const EdgeInsets.symmetric(vertical: 2), child: Row(children: [Expanded(child: Text(l, style: TextStyle(fontWeight: bold ? FontWeight.w800 : null))), Text(rupees(v), style: TextStyle(fontWeight: bold ? FontWeight.w800 : null))]));
}

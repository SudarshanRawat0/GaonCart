import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/location.dart';
import '../../core/widgets.dart';
import '../../theme.dart';
import '../auth/session.dart';
import '../common/account_actions.dart';
import '../common/notifications_screen.dart';
import 'customer_addresses.dart';
import 'customer_orders.dart';
import 'customer_shop.dart';

class CustomerShell extends StatefulWidget { const CustomerShell({super.key}); @override State<CustomerShell> createState() => _CS(); }
class _CS extends State<CustomerShell> {
  int i = 0;
  @override Widget build(BuildContext context) {
    final pages = <Widget>[const HomeTab(), const CartScreen(embedded: true), const OrdersTab(), const ProfileTab()];
    return Scaffold(body: SafeArea(child: IndexedStack(index: i, children: pages)),
      bottomNavigationBar: NavigationBar(selectedIndex: i, onDestinationSelected: (x) => setState(() => i = x), destinations: const [
        NavigationDestination(icon: Icon(Icons.storefront_outlined), selectedIcon: Icon(Icons.storefront), label: 'Shops'),
        NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), selectedIcon: Icon(Icons.shopping_cart), label: 'Cart'),
        NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Orders'),
        NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile')]));
  }
}

class HomeTab extends StatefulWidget { const HomeTab({super.key}); @override State<HomeTab> createState() => _HT(); }
class _HT extends State<HomeTab> {
  String q = ''; String? cat; final search = TextEditingController();
  Future<Map<String, dynamic>> _load() async {
    final api = apiOf(context);
    final pos = await currentPosition();
    final r = await Future.wait<dynamic>([
      api.get('/v1/banners'), api.get('/v1/categories', q: {'kind': 'shop'}),
      api.get('/v1/customer/shops', q: {'lat': pos.latitude, 'lng': pos.longitude, if (q.isNotEmpty) 'q': q, if (cat != null) 'category_id': cat}),
    ]);
    return {'banners': listOf(mapOf(r[0])['items']), 'cats': listOf(mapOf(r[1])['items']), 'shops': listOf(mapOf(r[2])['items']), 'lat': pos.latitude, 'lng': pos.longitude};
  }
  @override Widget build(BuildContext context) {
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 12, 8, 4), child: Row(children: [
        Expanded(child: Text('GaonCart', style: Theme.of(context).textTheme.headlineMedium?.copyWith(color: GC.green))),
        IconButton(icon: const Icon(Icons.notifications_none), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsScreen())))])),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: TextField(controller: search, textInputAction: TextInputAction.search, onSubmitted: (v) => setState(() => q = v.trim()),
        decoration: InputDecoration(hintText: 'Search shops near you', prefixIcon: const Icon(Icons.search), suffixIcon: q.isEmpty ? null : IconButton(icon: const Icon(Icons.close), onPressed: () { search.clear(); setState(() => q = ''); })))),
      Expanded(child: Loader<Map<String, dynamic>>(key: ValueKey('$q|$cat'), load: _load, builder: (c, d, reload) {
        final banners = d['banners'] as List<Map<String, dynamic>>, cats = d['cats'] as List<Map<String, dynamic>>, shops = d['shops'] as List<Map<String, dynamic>>;
        return ListView(children: [
          if (banners.isNotEmpty) SizedBox(height: 150, child: ListView.separated(padding: const EdgeInsets.fromLTRB(16, 12, 16, 0), scrollDirection: Axis.horizontal, itemCount: banners.length, separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (_, i) { final b = banners[i]; return GestureDetector(onTap: b['shop_id'] == null ? null : () => Navigator.push(c, MaterialPageRoute(builder: (_) => ShopScreen(shopId: b['shop_id'], lat: d['lat'], lng: d['lng']))),
              child: Stack(children: [NetImage(b['image_url'], w: 290, h: 138, radius: 16), Positioned(left: 12, bottom: 10, right: 12, child: Text('${b['title']}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16, shadows: [Shadow(blurRadius: 6)])))])); })),
          if (cats.isNotEmpty) SizedBox(height: 56, child: ListView(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), scrollDirection: Axis.horizontal, children: [
            Padding(padding: const EdgeInsets.only(right: 8), child: ChoiceChip(label: const Text('All'), selected: cat == null, onSelected: (_) => setState(() => cat = null))),
            for (final k in cats) Padding(padding: const EdgeInsets.only(right: 8), child: ChoiceChip(label: Text('${k['name']}'), selected: cat == k['id'], onSelected: (_) => setState(() => cat = k['id'])))])),
          const Section('Shops open near you'),
          if (shops.isEmpty) const Padding(padding: EdgeInsets.only(top: 40), child: EmptyView('No open shops found near you right now.\nTry again a little later.', icon: Icons.store_mall_directory_outlined)),
          for (final s in shops) Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 14), child: InkWell(borderRadius: BorderRadius.circular(16), onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => ShopScreen(shopId: s['id'], lat: d['lat'], lng: d['lng']))),
            child: Card(clipBehavior: Clip.antiAlias, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              NetImage(s['cover_url'] ?? s['logo_url'], w: double.infinity, h: 130, radius: 0, icon: Icons.storefront),
              Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [Expanded(child: Text('${s['name']}', style: Theme.of(c).textTheme.titleMedium)),
                  if ((s['rating_count'] ?? 0) > 0) Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3), decoration: BoxDecoration(color: GC.green, borderRadius: BorderRadius.circular(8)), child: Text('${s['rating_avg']} ★', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12)))]),
                const SizedBox(height: 4), Text('${s['distance_km']} km • ~${s['eta_min']} min${(s['min_order_paise'] ?? 0) > 0 ? ' • Min ${rupees(s['min_order_paise'])}' : ''}', style: const TextStyle(color: Colors.black54)),
                if (s['village'] != null) Text('${s['village']}', style: const TextStyle(color: Colors.black45, fontSize: 12))])),
            ]))))]);
      })),
    ]);
  }
}

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});
  @override Widget build(BuildContext context) {
    final s = context.watch<Session>();
    return ListView(children: [
      Padding(padding: const EdgeInsets.all(20), child: Row(children: [const CircleAvatar(radius: 30, backgroundColor: GC.green, child: Icon(Icons.person, color: Colors.white, size: 32)), const SizedBox(width: 16),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${s.user?['name'] ?? 'Add your name'}', style: Theme.of(context).textTheme.titleMedium), Text('+91 ${s.user?['mobile'] ?? ''}')])),
        IconButton(icon: const Icon(Icons.edit_outlined), onPressed: () async { final n = await askText(context, 'Your name'); if (n != null && n.isNotEmpty) { await guard(context, () async { s.setUser(mapOf(await s.api.patch('/v1/me', body: {'name': n}))); }); } })])),
      ListTile(leading: const Icon(Icons.location_on_outlined), title: const Text('Delivery addresses'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddressesScreen()))),
      ListTile(leading: const Icon(Icons.support_agent), title: const Text('Help & support'), trailing: const Icon(Icons.chevron_right), onTap: () async {
        final t = await askText(context, 'Describe your problem'); if (t == null || t.length < 5) return;
        final r = await guard(context, () => s.api.post('/v1/support/tickets', body: {'subject': t.length > 60 ? t.substring(0, 60) : t, 'body': t, 'category': 'general'})); if (r != null && context.mounted) toast(context, 'Ticket created. We will reply in Notifications.'); }),
      const AccountActions(),
    ]);
  }
}

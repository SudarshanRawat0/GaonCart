import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/api_client.dart';
import '../../core/images.dart';
import '../../core/location.dart';
import '../../core/widgets.dart';
import '../../theme.dart';
import '../common/account_actions.dart';
import '../common/notifications_screen.dart';

class DeliveryShell extends StatefulWidget { const DeliveryShell({super.key}); @override State<DeliveryShell> createState() => _DS(); }
class _DS extends State<DeliveryShell> {
  Map<String, dynamic>? p; bool loading = true; String? err; int i = 0; bool online = false, busy = false; Timer? gps; String? gpsMsg;
  @override void initState() { super.initState(); _load(); }
  @override void dispose() { gps?.cancel(); super.dispose(); }
  Future<void> _load() async {
    setState(() { loading = true; err = null; });
    try { p = mapOf(await apiOf(context).get('/v1/delivery/profile')); online = p!['is_online'] == true; if (online) _startGps(); }
    on ApiException catch (e) { err = e.message; }
    if (mounted) setState(() => loading = false);
  }
  // Real GPS from the phone, sent to the backend every 6 s while online (foreground). The backend pushes it to the customer.
  Future<void> _sendLocation() async {
    try { final pos = await currentPosition(); await apiOf(context).post('/v1/delivery/location', body: {'lat': pos.latitude, 'lng': pos.longitude, if (pos.accuracy > 0) 'accuracy_m': pos.accuracy, if (pos.speed >= 0) 'speed_mps': pos.speed, if (pos.heading >= 0) 'heading': pos.heading}); if (mounted && gpsMsg != null) setState(() => gpsMsg = null); }
    on ApiException catch (e) { if (mounted) setState(() => gpsMsg = e.message); }
  }
  void _startGps() { gps?.cancel(); _sendLocation(); gps = Timer.periodic(const Duration(seconds: 6), (_) => _sendLocation()); }
  Future<void> _toggle(bool v) async {
    setState(() => busy = true);
    if (v) { final pos = await guard(context, currentPosition); if (pos == null) { setState(() => busy = false); return; } }
    final r = await guard(context, () => apiOf(context).post('/v1/delivery/status', body: {'is_online': v}));
    if (r != null) { online = v; if (v) { _startGps(); } else { gps?.cancel(); } }
    if (mounted) setState(() => busy = false);
  }
  @override Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (err != null) return Scaffold(body: ErrorView(message: err!, onRetry: _load));
    if (p!['verification_status'] != 'verified' || p!['vehicle_type'] == null) return _Onboarding(profile: p!, onRefresh: _load);
    final pages = <Widget>[RequestsTab(onAccepted: () => setState(() => i = 1)), const ActiveTab(), const EarningsTab(), _Profile(profile: p!, onChanged: _load)];
    return Scaffold(body: SafeArea(child: Column(children: [
      Container(color: online ? GC.green : Colors.black87, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6), child: Row(children: [
        Expanded(child: Text(online ? 'You are ONLINE' : 'You are OFFLINE', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800))),
        IconButton(icon: const Icon(Icons.notifications_none, color: Colors.white), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsScreen()))),
        Switch(value: online, activeColor: GC.saffron, onChanged: busy ? null : _toggle)])),
      if (gpsMsg != null) Container(width: double.infinity, color: const Color(0xFFFFE0B2), padding: const EdgeInsets.all(8), child: Text(gpsMsg!, textAlign: TextAlign.center)),
      Expanded(child: IndexedStack(index: i, children: pages))])),
      bottomNavigationBar: NavigationBar(selectedIndex: i, onDestinationSelected: (x) => setState(() => i = x), destinations: const [
        NavigationDestination(icon: Icon(Icons.notifications_active_outlined), selectedIcon: Icon(Icons.notifications_active), label: 'Requests'),
        NavigationDestination(icon: Icon(Icons.delivery_dining_outlined), selectedIcon: Icon(Icons.delivery_dining), label: 'Active'),
        NavigationDestination(icon: Icon(Icons.currency_rupee), label: 'Earnings'),
        NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile')]));
  }
}

class _Onboarding extends StatefulWidget { const _Onboarding({required this.profile, required this.onRefresh}); final Map<String, dynamic> profile; final VoidCallback onRefresh; @override State<_Onboarding> createState() => _OB(); }
class _OB extends State<_Onboarding> {
  String? vehicle; final number = TextEditingController(), name = TextEditingController(); bool busy = false;
  static const docs = {'aadhaar': 'Aadhaar card', 'driving_licence': 'Driving licence', 'vehicle_rc': 'Vehicle RC', 'photo': 'Your photo'};
  @override void initState() { super.initState(); vehicle = widget.profile['vehicle_type']; number.text = widget.profile['vehicle_number'] ?? ''; name.text = widget.profile['name'] ?? ''; }
  Future<void> _saveProfile() async {
    if (vehicle == null || name.text.trim().isEmpty) { toast(context, 'Enter your name and choose a vehicle'); return; }
    setState(() => busy = true);
    final r = await guard(context, () => apiOf(context).put('/v1/delivery/profile', body: {'name': name.text.trim(), 'vehicle_type': vehicle, if (number.text.trim().length >= 4) 'vehicle_number': number.text.trim()}));
    if (mounted) setState(() => busy = false); if (r != null) widget.onRefresh();
  }
  Future<void> _upload(String type) async {
    final key = await pickAndUpload(context, 'partner_doc'); if (key == null || !mounted) return;
    String? num; if (type != 'photo') num = await askText(context, '${docs[type]} number (optional)');
    final r = await guard(context, () => apiOf(context).post('/v1/delivery/documents', body: {'doc_type': type, 'file_key': key, if (num != null && num.isNotEmpty) 'doc_number': num}));
    if (r != null) { toast(context, 'Uploaded'); widget.onRefresh(); }
  }
  @override Widget build(BuildContext context) {
    final p = widget.profile, st = p['verification_status'], uploaded = listOf(p['documents']);
    return Scaffold(appBar: AppBar(title: const Text('Become a delivery partner'), actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: widget.onRefresh)]), body: ListView(padding: const EdgeInsets.all(16), children: [
      Card(color: st == 'rejected' ? Colors.red.withOpacity(.08) : const Color(0xFFFFF4DD), child: Padding(padding: const EdgeInsets.all(14), child: Text(st == 'rejected' ? 'Verification rejected: ${p['rejection_reason'] ?? ''}\nUpload corrected documents to apply again.' : uploaded.isEmpty ? 'Complete your profile and upload your documents. We verify every partner before they can take orders.' : 'Documents submitted. Verification usually takes 1–2 days. Pull the refresh button to check.'))),
      const Section('1. Your details'), TextField(controller: name, decoration: const InputDecoration(labelText: 'Full name')), const SizedBox(height: 12),
      Wrap(spacing: 8, children: [for (final v in const ['bicycle', 'bike', 'scooter', 'other']) ChoiceChip(label: Text(v), selected: vehicle == v, onSelected: (_) => setState(() => vehicle = v))]), const SizedBox(height: 12),
      TextField(controller: number, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'Vehicle number (if any)')), const SizedBox(height: 12),
      FilledButton(onPressed: busy ? null : _saveProfile, child: const Text('Save details')),
      const Section('2. Documents'), for (final e in docs.entries) ListTile(leading: Icon(uploaded.any((d) => d['doc_type'] == e.key) ? Icons.check_circle : Icons.upload_file, color: uploaded.any((d) => d['doc_type'] == e.key) ? GC.green : null), title: Text(e.value), subtitle: Text(uploaded.where((d) => d['doc_type'] == e.key).map((d) => d['status']).join(', ')), trailing: TextButton(onPressed: () => _upload(e.key), child: const Text('Upload'))),
      const AccountActions()]));
  }
}

class RequestsTab extends StatefulWidget { const RequestsTab({super.key, required this.onAccepted}); final VoidCallback onAccepted; @override State<RequestsTab> createState() => _RT(); }
class _RT extends State<RequestsTab> {
  final key = GlobalKey<LoaderState<List<Map<String, dynamic>>>>(); final dismissed = <String>{}; Timer? t;
  @override void initState() { super.initState(); t = Timer.periodic(const Duration(seconds: 8), (_) => key.currentState?.reload()); }
  @override void dispose() { t?.cancel(); super.dispose(); }
  @override Widget build(BuildContext context) => Loader<List<Map<String, dynamic>>>(key: key, load: () async => listOf(mapOf(await apiOf(context).get('/v1/delivery/requests'))['items']), emptyText: 'No delivery requests right now.\nStay online — new ones appear here automatically.', emptyIcon: Icons.notifications_none,
    isEmpty: (l) => l.where((o) => !dismissed.contains(o['id'])).isEmpty,
    builder: (c, items, reload) => ListView(padding: const EdgeInsets.all(12), children: [for (final o in items.where((o) => !dismissed.contains(o['id']))) Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Text('${mapOf(o['shop'])['name']}', style: Theme.of(c).textTheme.titleMedium)), Text(rupees(o['earning_paise']), style: const TextStyle(color: GC.green, fontWeight: FontWeight.w900, fontSize: 20))]),
      Text('${mapOf(o['shop'])['address']}', style: const TextStyle(color: Colors.black54)), const SizedBox(height: 6),
      Text('Pickup ${o['pickup_distance_km']} km away • Trip ${o['trip_km']} km'), if ((o['collect_cash_paise'] ?? 0) > 0) Text('Collect cash: ${rupees(o['collect_cash_paise'])}', style: const TextStyle(fontWeight: FontWeight.w700, color: Colors.deepOrange)),
      const SizedBox(height: 10), Row(children: [Expanded(child: OutlinedButton(onPressed: () => setState(() => dismissed.add(o['id'])), child: const Text('Reject'))), const SizedBox(width: 8),
        Expanded(child: FilledButton(onPressed: () async { final r = await guard(c, () => apiOf(c).post('/v1/delivery/orders/${o['id']}/accept')); if (r != null) { widget.onAccepted(); } reload(); }, child: const Text('Accept')))])])))]));
}

class ActiveTab extends StatefulWidget { const ActiveTab({super.key}); @override State<ActiveTab> createState() => _AT(); }
class _AT extends State<ActiveTab> {
  final key = GlobalKey<LoaderState<List<Map<String, dynamic>>>>(); Timer? t;
  @override void initState() { super.initState(); t = Timer.periodic(const Duration(seconds: 10), (_) => key.currentState?.reload()); }
  @override void dispose() { t?.cancel(); super.dispose(); }
  Future<void> _step(Map<String, dynamic> o, String path, {Map<String, dynamic>? body}) async { await guard(context, () => apiOf(context).post('/v1/delivery/orders/${o['id']}/$path', body: body)); key.currentState?.reload(); }
  @override Widget build(BuildContext context) => Loader<List<Map<String, dynamic>>>(key: key, load: () async => listOf(mapOf(await apiOf(context).get('/v1/delivery/orders', q: {'group': 'active'}))['items']), isEmpty: (l) => l.isEmpty, emptyText: 'No active deliveries.\nAccepted orders appear here.', emptyIcon: Icons.delivery_dining_outlined,
    builder: (c, items, reload) => ListView(padding: const EdgeInsets.all(12), children: [for (final o in items) _card(c, o)]));
  Widget _card(BuildContext c, Map<String, dynamic> o) {
    final st = o['status'] as String, shop = mapOf(o['shop']), a = mapOf(o['address']);
    return Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Text('#${o['number']}', style: Theme.of(c).textTheme.titleMedium)), StatusChip(st)]),
      const SizedBox(height: 8), const Text('PICKUP', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.black45)), Text('${shop['name']}', style: const TextStyle(fontWeight: FontWeight.w700)), Text('${shop['address']}'),
      Row(children: [TextButton.icon(onPressed: () => callPhone(shop['phone'] ?? o['shop_phone']), icon: const Icon(Icons.call, size: 18), label: const Text('Call shop')), TextButton.icon(onPressed: () => navigateTo(shop['lat'], shop['lng']), icon: const Icon(Icons.navigation_outlined, size: 18), label: const Text('Navigate'))]),
      const Divider(), const Text('DELIVER TO', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.black45)), Text('${a['name']}', style: const TextStyle(fontWeight: FontWeight.w700)), Text('${a['line']}'),
      Row(children: [TextButton.icon(onPressed: () => callPhone(a['phone']), icon: const Icon(Icons.call, size: 18), label: const Text('Call customer')), TextButton.icon(onPressed: () => navigateTo(a['lat'], a['lng']), icon: const Icon(Icons.navigation_outlined, size: 18), label: const Text('Navigate'))]),
      if ((o['collect_cash_paise'] ?? 0) > 0) Container(width: double.infinity, margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: const Color(0xFFFFF4DD), borderRadius: BorderRadius.circular(10)), child: Text('Collect ${rupees(o['collect_cash_paise'])} cash from the customer', style: const TextStyle(fontWeight: FontWeight.w800))),
      Text('You earn ${rupees(o['earning_paise'])}', style: const TextStyle(color: GC.green, fontWeight: FontWeight.w800)), const SizedBox(height: 8),
      if (st == 'assigned') FilledButton(onPressed: () => _step(o, 'pickup'), child: const Text('Picked up from shop')),
      if (st == 'picked_up') FilledButton(onPressed: () => _step(o, 'out-for-delivery'), child: const Text('Out for delivery')),
      if (st == 'out_for_delivery') FilledButton(onPressed: () async { final code = await askText(c, 'Enter the customer’s 4-digit delivery code', number: true); if (code != null && code.length == 4) _step(o, 'deliver', body: {'code': code}); else if (code != null) toast(c, 'The code has 4 digits'); }, child: const Text('Confirm delivery')),
    ])));
  }
}

class EarningsTab extends StatelessWidget {
  const EarningsTab({super.key});
  @override Widget build(BuildContext context) {
    final api = apiOf(context);
    return Loader<Map<String, dynamic>>(load: () async { final r = await Future.wait<dynamic>([api.get('/v1/delivery/earnings'), api.get('/v1/delivery/orders', q: {'group': 'history'}), api.get('/v1/delivery/payments')]); return {'e': mapOf(r[0]), 'h': listOf(mapOf(r[1])['items']), 'p': listOf(mapOf(r[2])['items'])}; },
      builder: (c, d, reload) { final e = mapOf(d['e']), days = listOf(e['days']), hist = d['h'] as List<Map<String, dynamic>>, pays = d['p'] as List<Map<String, dynamic>>;
        return ListView(padding: const EdgeInsets.all(16), children: [
          Card(color: GC.green, child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Today', style: TextStyle(color: Colors.white70)), Text(rupees(e['today_paise']), style: const TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.w900)), Text('${e['today_deliveries']} deliveries', style: const TextStyle(color: Colors.white70))]))),
          Row(children: [_s('Total earned', rupees(e['total_paise'])), const SizedBox(width: 12), _s('Cash to hand over', rupees(e['cash_to_remit_paise']))]), const SizedBox(height: 12), Row(children: [_s('Awaiting settlement', rupees(e['unsettled_paise'])), const SizedBox(width: 12), _s('Paid out', rupees(e['paid_out_paise']))]),
          if ((e['cash_to_remit_paise'] ?? 0) > 0) const Padding(padding: EdgeInsets.only(top: 8), child: Text('Cash collected on delivery must be handed over to GaonCart; it is adjusted in your settlement.', style: TextStyle(color: Colors.black54, fontSize: 12))),
          const Section('Daily earnings'), if (days.isEmpty) const Text('No deliveries yet.'), for (final x in days) ListTile(dense: true, title: Text('${x['day']}'), subtitle: Text('${x['deliveries']} deliveries'), trailing: Text(rupees(x['earned_paise']), style: const TextStyle(fontWeight: FontWeight.w800))),
          const Section('Payments'), if (pays.isEmpty) const Text('No settlements yet.'), for (final p in pays) ListTile(dense: true, title: Text(rupees(p['amount_paise'])), subtitle: Text('${p['status']}${p['reference'] != null ? ' • ref ${p['reference']}' : ''}'), trailing: Text(('${p['created_at']}').substring(0, 10))),
          const Section('Delivery history'), if (hist.isEmpty) const Text('Completed deliveries will appear here.'), for (final o in hist) ListTile(dense: true, title: Text('#${o['number']} • ${mapOf(o['shop'])['name']}'), subtitle: Text('${('${o['delivered_at'] ?? o['created_at']}').substring(0, 10)}'), trailing: StatusChip(o['status']))]); });
  }
  Widget _s(String l, String v) => Expanded(child: Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(l, style: const TextStyle(color: Colors.black54, fontSize: 12)), const SizedBox(height: 4), Text(v, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))]))));
}

class _Profile extends StatelessWidget {
  const _Profile({required this.profile, required this.onChanged}); final Map<String, dynamic> profile; final VoidCallback onChanged;
  @override Widget build(BuildContext context) => ListView(children: [
    ListTile(leading: const CircleAvatar(backgroundColor: GC.green, child: Icon(Icons.two_wheeler, color: Colors.white)), title: Text('${profile['name'] ?? ''}'), subtitle: Text('+91 ${profile['mobile']} • ${profile['vehicle_type']} ${profile['vehicle_number'] ?? ''}\nVerified ✓'), isThreeLine: true),
    ListTile(leading: const Icon(Icons.account_balance_wallet_outlined), title: const Text('Payout UPI ID'), onTap: () async { final u = await askText(context, 'Your UPI ID', hint: 'name@bank'); if (u == null || u.isEmpty) return; final r = await guard(context, () => apiOf(context).put('/v1/delivery/profile', body: {'vehicle_type': profile['vehicle_type'], 'payout_upi': u})); if (r != null && context.mounted) toast(context, 'Saved'); }),
    ListTile(leading: const Icon(Icons.support_agent), title: const Text('Help & support'), onTap: () async { final t = await askText(context, 'Describe your problem'); if (t == null || t.length < 5) return; final r = await guard(context, () => apiOf(context).post('/v1/support/tickets', body: {'subject': t.length > 60 ? t.substring(0, 60) : t, 'body': t})); if (r != null && context.mounted) toast(context, 'Ticket created'); }),
    const AccountActions()]);
}

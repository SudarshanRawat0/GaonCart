import 'package:flutter/material.dart';
/// GaonCart brand: deep green + warm saffron accent (original palette; not a copy of any competitor).
class GC {
  static const green = Color(0xFF1B7F4B), saffron = Color(0xFFF5A524), ink = Color(0xFF16231B), soft = Color(0xFFF4F7F5);
  static ThemeData theme() => ThemeData(
    useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: green, primary: green, secondary: saffron, surface: Colors.white),
    scaffoldBackgroundColor: soft, appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: ink, elevation: 0, scrolledUnderElevation: 1),
    textTheme: const TextTheme(headlineMedium: TextStyle(fontWeight: FontWeight.w800, color: ink), titleMedium: TextStyle(fontWeight: FontWeight.w700, color: ink)),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)))),
    inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
  );
}

/// Build with: flutter run --dart-define=API_BASE_URL=https://api.yourdomain.in
/// Nothing secret lives in the app: Razorpay's public key id is returned by the backend per payment.
class AppConfig {
  static const apiBaseUrl = String.fromEnvironment('API_BASE_URL', defaultValue: '');
  static String assetUrl(String? path) => path == null || path.isEmpty ? '' : (path.startsWith('http') ? path : '$apiBaseUrl$path');
}

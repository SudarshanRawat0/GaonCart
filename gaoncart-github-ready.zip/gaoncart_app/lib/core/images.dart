import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'widgets.dart';

/// Picks a photo from the gallery and uploads it. The backend re-validates type (magic bytes) and size (5 MB).
/// Returns the public url (product/logo/cover/profile) or the private file_key (partner_doc).
Future<String?> pickAndUpload(BuildContext c, String kind) async {
  final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1600, imageQuality: 85);
  if (x == null) return null;
  final bytes = await x.readAsBytes();
  if (bytes.length > 5 * 1024 * 1024) { if (c.mounted) toast(c, 'Image is larger than 5 MB'); return null; }
  if (!c.mounted) return null;
  final r = await guard(c, () => apiOf(c).upload(kind, bytes, x.mimeType ?? 'image/jpeg'));
  return (r?['url'] ?? r?['file_key']) as String?;
}

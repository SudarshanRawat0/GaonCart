import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../features/auth/session.dart';
import '../theme.dart';
import 'api_client.dart';
import 'config.dart';

ApiClient apiOf(BuildContext c) => c.read<Session>().api;
Map<String, dynamic> mapOf(dynamic v) => Map<String, dynamic>.from(v as Map);
List<Map<String, dynamic>> listOf(dynamic v) => (v as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
String rupees(num paise) { final r = paise / 100; return '₹${r == r.roundToDouble() ? r.toStringAsFixed(0) : r.toStringAsFixed(2)}'; }
int toPaise(String rupeesText) => (double.parse(rupeesText.trim()) * 100).round();

void toast(BuildContext c, String m) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating));

/// Runs an API action; shows the backend's message on failure and returns null.
Future<T?> guard<T>(BuildContext c, Future<T> Function() f) async {
  try { return await f(); }
  on ApiException catch (e) { if (c.mounted) toast(c, e.message); }
  catch (e) { if (c.mounted) toast(c, 'Something went wrong. Please try again.'); }
  return null;
}
Future<bool> confirm(BuildContext c, String title, String body, {String yes = 'Yes'}) async =>
    await showDialog<bool>(context: c, builder: (_) => AlertDialog(title: Text(title), content: Text(body), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('No')), FilledButton(style: FilledButton.styleFrom(minimumSize: const Size(80, 40)), onPressed: () => Navigator.pop(c, true), child: Text(yes))])) ?? false;
Future<String?> askText(BuildContext c, String title, {String hint = '', bool number = false}) async {
  final t = TextEditingController();
  return showDialog<String>(context: c, builder: (_) => AlertDialog(title: Text(title), content: TextField(controller: t, autofocus: true, keyboardType: number ? TextInputType.number : null, decoration: InputDecoration(hintText: hint)),
    actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Cancel')), FilledButton(style: FilledButton.styleFrom(minimumSize: const Size(80, 40)), onPressed: () => Navigator.pop(c, t.text.trim()), child: const Text('OK'))]));
}
Future<void> callPhone(String? phone) async { if (phone != null && phone.isNotEmpty) await launchUrl(Uri.parse('tel:$phone')); }
Future<void> navigateTo(num lat, num lng) => launchUrl(Uri.parse('https://www.google.com/maps/dir/?api=1&destination=$lat,$lng'), mode: LaunchMode.externalApplication);

class NetImage extends StatelessWidget {
  const NetImage(this.path, {super.key, this.w, this.h, this.radius = 12, this.icon = Icons.image_outlined});
  final String? path; final double? w, h, radius; final IconData icon;
  @override Widget build(BuildContext c) => ClipRRect(borderRadius: BorderRadius.circular(radius!), child: path == null || path!.isEmpty
    ? Container(width: w, height: h, color: GC.soft, child: Icon(icon, color: Colors.black26))
    : Image.network(AppConfig.assetUrl(path), width: w, height: h, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(width: w, height: h, color: GC.soft, child: Icon(icon, color: Colors.black26))));
}

class EmptyView extends StatelessWidget {
  const EmptyView(this.text, {super.key, this.icon = Icons.inbox_outlined});
  final String text; final IconData icon;
  @override Widget build(BuildContext c) => Center(child: Padding(padding: const EdgeInsets.all(32), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 64, color: Colors.black26), const SizedBox(height: 12), Text(text, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54))])));
}
class ErrorView extends StatelessWidget {
  const ErrorView({super.key, required this.message, required this.onRetry});
  final String message; final VoidCallback onRetry;
  @override Widget build(BuildContext c) => Center(child: Padding(padding: const EdgeInsets.all(32), child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Icon(Icons.cloud_off_outlined, size: 56, color: Colors.black38), const SizedBox(height: 12), Text(message, textAlign: TextAlign.center), const SizedBox(height: 16),
    OutlinedButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh), label: const Text('Try again'))])));
}

/// Loading / error / empty / pull-to-refresh wrapper used by every list screen.
class Loader<T> extends StatefulWidget {
  const Loader({super.key, required this.load, required this.builder, this.isEmpty, this.emptyText = 'Nothing here yet', this.emptyIcon = Icons.inbox_outlined});
  final Future<T> Function() load; final Widget Function(BuildContext, T, Future<void> Function()) builder;
  final bool Function(T)? isEmpty; final String emptyText; final IconData emptyIcon;
  @override State<Loader<T>> createState() => LoaderState<T>();
}
class LoaderState<T> extends State<Loader<T>> {
  T? data; Object? err; bool loading = true;
  @override void initState() { super.initState(); reload(); }
  Future<void> reload() async {
    if (mounted) setState(() { loading = data == null; err = null; });
    try { final d = await widget.load(); if (mounted) setState(() { data = d; loading = false; }); }
    catch (e) { if (mounted) setState(() { err = e; loading = false; }); }
  }
  @override Widget build(BuildContext c) {
    if (loading) return const Center(child: CircularProgressIndicator());
    if (err != null && data == null) return ErrorView(message: '$err', onRetry: reload);
    final d = data as T;
    if (widget.isEmpty?.call(d) == true) return RefreshIndicator(onRefresh: reload, child: ListView(children: [const SizedBox(height: 120), EmptyView(widget.emptyText, icon: widget.emptyIcon)]));
    return RefreshIndicator(onRefresh: reload, child: widget.builder(c, d, reload));
  }
}

class StatusChip extends StatelessWidget {
  const StatusChip(this.status, {super.key});
  final String status;
  static const names = {'pending_payment': 'Awaiting payment', 'placed': 'Placed', 'accepted': 'Accepted', 'preparing': 'Preparing', 'ready_for_pickup': 'Ready for pickup', 'assigned': 'Partner assigned', 'picked_up': 'Picked up', 'out_for_delivery': 'Out for delivery', 'delivered': 'Delivered', 'rejected': 'Rejected', 'cancelled': 'Cancelled'};
  @override Widget build(BuildContext c) {
    final bad = status == 'rejected' || status == 'cancelled', done = status == 'delivered';
    final col = bad ? Colors.red : done ? GC.green : GC.saffron;
    return Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: col.withOpacity(.12), borderRadius: BorderRadius.circular(20)), child: Text(names[status] ?? status, style: TextStyle(color: col.withOpacity(.95), fontWeight: FontWeight.w700, fontSize: 12)));
  }
}

class Section extends StatelessWidget {
  const Section(this.title, {super.key, this.trailing});
  final String title; final Widget? trailing;
  @override Widget build(BuildContext c) => Padding(padding: const EdgeInsets.fromLTRB(16, 20, 16, 8), child: Row(children: [Expanded(child: Text(title, style: Theme.of(c).textTheme.titleMedium)), if (trailing != null) trailing!]));
}

import 'package:geolocator/geolocator.dart';
import 'api_client.dart';

/// Real device GPS. Throws a user-readable ApiException if services/permission are unavailable.
Future<Position> currentPosition() async {
  if (!await Geolocator.isLocationServiceEnabled()) throw ApiException(0, 'gps', 'Please turn on location services.');
  var p = await Geolocator.checkPermission();
  if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
  if (p == LocationPermission.denied || p == LocationPermission.deniedForever) throw ApiException(0, 'gps', 'Location permission is required. Enable it in Settings.');
  return Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high));
}

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class TokenStore {
  static const _s = FlutterSecureStorage(aOptions: AndroidOptions(encryptedSharedPreferences: true));
  String? access, refresh;
  Future<void> load() async { access = await _s.read(key: 'at'); refresh = await _s.read(key: 'rt'); }
  Future<void> save(String a, String r) async { access = a; refresh = r; await _s.write(key: 'at', value: a); await _s.write(key: 'rt', value: r); }
  Future<void> clear() async { access = null; refresh = null; await _s.deleteAll(); }
}

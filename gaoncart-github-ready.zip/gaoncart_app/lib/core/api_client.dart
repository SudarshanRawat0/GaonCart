import 'dart:async';
import 'package:dio/dio.dart';
import 'config.dart';
import 'token_store.dart';

/// Mirrors the backend error envelope: { error: { code, message, details, request_id } }.
class ApiException implements Exception {
  final int status; final String code, message; final Map<String, dynamic>? details;
  ApiException(this.status, this.code, this.message, [this.details]);
  bool get isNetwork => status == 0;
  @override String toString() => message;
}

class ApiClient {
  ApiClient(this.tokens, {required this.onSessionExpired}) {
    _dio = Dio(BaseOptions(baseUrl: AppConfig.apiBaseUrl, connectTimeout: const Duration(seconds: 15), receiveTimeout: const Duration(seconds: 30), headers: {'Content-Type': 'application/json'}));
    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (o, h) { if (tokens.access != null && o.extra['noAuth'] != true) o.headers['Authorization'] = 'Bearer ${tokens.access}'; h.next(o); },
      onError: (e, h) async {
        final retried = e.requestOptions.extra['retried'] == true;
        if (e.response?.statusCode == 401 && !retried && e.requestOptions.extra['noAuth'] != true && tokens.refresh != null) {
          if (await _refresh()) {
            final o = e.requestOptions..extra['retried'] = true..headers['Authorization'] = 'Bearer ${tokens.access}';
            try { return h.resolve(await _dio.fetch(o)); } on DioException catch (e2) { return h.next(e2); }
          }
          onSessionExpired();
        }
        h.next(e);
      },
    ));
  }
  final TokenStore tokens; final void Function() onSessionExpired; late final Dio _dio; Completer<bool>? _refreshing;
  String get baseUrl => _dio.options.baseUrl;
  Map<String, String> get authHeader => {'Authorization': 'Bearer ${tokens.access}'};

  // Single-flight refresh: concurrent 401s share one rotation (the backend revokes reused refresh tokens).
  Future<bool> _refresh() {
    if (_refreshing != null) return _refreshing!.future;
    final c = _refreshing = Completer<bool>();
    () async {
      try {
        final r = await Dio(BaseOptions(baseUrl: AppConfig.apiBaseUrl)).post('/v1/auth/refresh', data: {'refresh_token': tokens.refresh});
        await tokens.save(r.data['access_token'], r.data['refresh_token']); c.complete(true);
      } catch (_) { c.complete(false); } finally { _refreshing = null; }
    }();
    return c.future;
  }

  Future<T> _wrap<T>(Future<Response<dynamic>> Function() f) async {
    try { return (await f()).data as T; }
    on DioException catch (e) {
      final d = e.response?.data;
      if (d is Map && d['error'] is Map) { final er = d['error'] as Map; throw ApiException(e.response!.statusCode ?? 0, '${er['code']}', '${er['message']}', (er['details'] as Map?)?.cast<String, dynamic>()); }
      throw ApiException(0, 'network', 'Cannot reach GaonCart. Check your internet connection.');
    }
  }
  Future<dynamic> get(String p, {Map<String, dynamic>? q}) => _wrap(() => _dio.get(p, queryParameters: q));
  Future<dynamic> post(String p, {Object? body, Map<String, String>? headers, bool noAuth = false}) => _wrap(() => _dio.post(p, data: body ?? {}, options: Options(headers: headers, extra: {'noAuth': noAuth})));
  Future<dynamic> put(String p, {Object? body}) => _wrap(() => _dio.put(p, data: body));
  Future<dynamic> patch(String p, {Object? body}) => _wrap(() => _dio.patch(p, data: body));
  Future<dynamic> delete(String p) => _wrap(() => _dio.delete(p));
  /// Raw image upload; the backend verifies magic bytes and size (5 MB). kind: product|logo|cover|profile|partner_doc
  Future<Map<String, dynamic>> upload(String kind, List<int> bytes, String mime) =>
      _wrap<Map<String, dynamic>>(() => _dio.post('/v1/uploads', queryParameters: {'kind': kind}, data: Stream.fromIterable([bytes]), options: Options(contentType: mime, headers: {'Content-Length': bytes.length})));
}

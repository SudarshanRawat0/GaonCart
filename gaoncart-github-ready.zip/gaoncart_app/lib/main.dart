import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'features/auth/login_screen.dart';
import 'features/auth/session.dart';
import 'features/customer/customer_shell.dart';
import 'features/seller/seller_shell.dart';
import 'features/delivery/delivery_shell.dart';
import 'theme.dart';

void main() { WidgetsFlutterBinding.ensureInitialized(); runApp(ChangeNotifierProvider(create: (_) => Session()..restore(), child: const GaonCartApp())); }

class GaonCartApp extends StatelessWidget {
  const GaonCartApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(title: 'GaonCart', theme: GC.theme(), debugShowCheckedModeBanner: false, home: const _Gate());
}

/// Role-based routing: the server-provided role decides the dashboard. No other route exists for the other roles.
class _Gate extends StatelessWidget {
  const _Gate();
  @override Widget build(BuildContext context) {
    final s = context.watch<Session>();
    if (s.state == SessionState.loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (s.state == SessionState.signedOut || s.role == null) return const LoginScreen();
    if (s.role == Role.seller) return const SellerShell();
    if (s.role == Role.delivery) return const DeliveryShell();
    return const CustomerShell();
  }
}

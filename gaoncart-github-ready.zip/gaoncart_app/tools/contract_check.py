import re,glob,sys,os
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'))
os.chdir(ROOT)
BACKEND=os.environ.get('BACKEND_DIR',os.path.join(ROOT,'..','gaoncart-backend'))
routes=set()
for f in glob.glob(BACKEND+'/src/routes/*.js'):
    s=open(f).read()
    for m,p in re.findall(r"r\.(get|post|put|patch|del)\('([^']+)'",s): routes.add((m.upper().replace('DEL','DELETE'),p))
    for p in re.findall(r"act\('([a-z-]+)'",s): routes.add(('POST','/v1/seller/orders/:id/'+p))
    for p in re.findall(r"step\('([a-z-]+)'",s): routes.add(('POST','/v1/delivery/orders/:id/'+p))
rx=[(m,re.compile('^'+re.sub(r':\w+','[^/]+',p)+'$')) for m,p in routes]
calls=set()
for f in glob.glob('lib/**/*.dart',recursive=True):
    s=open(f).read(); name=f.split('/')[-1]
    for m,p in re.findall(r"\.(get|post|put|patch|delete)\(\s*'(/v1/(?:[^'$]|\$\{[^}]*\}|\$\w+)*)'",s):
        calls.add((m.upper(),re.sub(r'\$\{[^}]+\}|\$\w+','X',p),name))
    if "'/v1/uploads'" in s: calls.add(('POST','/v1/uploads',name))
# calls whose last segment is a variable (_step / _do helpers): check each literal action used
for f,pre,helper in [('lib/features/delivery/delivery_shell.dart','/v1/delivery/orders/X/','_step'),('lib/features/seller/seller_shell.dart','/v1/seller/orders/X/','_do')]:
    src=open(f).read()
    for act in sorted(set(re.findall(helper+r"\(o, '([a-z-]+)'",src))):
        calls.add(('POST',pre+act,f.split('/')[-1]))
calls={c for c in calls if not c[1].endswith('/X/X')}
bad=0
for m,p,f in sorted(calls):
    ok=any(m==rm and r.match(p) for rm,r in rx)
    bad+=not ok
    print(('OK      ' if ok else 'MISSING '),m,p,'(%s)'%f)
print(f'\n{len(calls)} distinct app calls checked, {bad} without a matching backend route')
sys.exit(1 if bad else 0)

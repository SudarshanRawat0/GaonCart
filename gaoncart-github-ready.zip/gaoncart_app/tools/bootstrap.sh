#!/usr/bin/env bash
# One-time setup on a machine with Flutter >= 3.27 and the Android SDK.
set -euo pipefail
flutter create . --platforms=android --org in.gaoncart --project-name gaoncart
python3 tools/patch_android.py
flutter pub get
echo "Now apply android_overlay/AndroidManifest.additions.md, then:"
echo "  flutter analyze && flutter test"
echo "  flutter run --dart-define=API_BASE_URL=https://api.yourdomain.in"
echo "  flutter build apk --debug --dart-define=API_BASE_URL=https://api.yourdomain.in"

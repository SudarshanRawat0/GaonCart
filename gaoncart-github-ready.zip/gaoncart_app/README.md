# GaonCart Android app (Flutter) — one app, three roles

Customer, Seller and Delivery Partner dashboards in a single app. After OTP login the **server-returned role** decides which dashboard opens;
the backend independently enforces role permissions on every endpoint.

## STATUS — read this first
**No APK has been built yet.** The last attempt (see `docs/BUILD_ATTEMPT_LOG.txt`) ran in a sandbox without Flutter, Android SDK or internet.
Fastest way to get the APK without installing anything: follow `../GITHUB_UPLOAD_GUIDE.md` (works from an Android phone). The workflow lives at the repository root: `.github/workflows/build-apk.yml`.

- Source code is complete for the scoped features, but **it has NOT been compiled or run**: the build environment used to write it has no Flutter/Android SDK and no internet.
  Expect a few compile/analyzer fixes on the first `flutter analyze`.
- **Verified:** every API call the app makes matches a real backend route (`tools/contract_check.py`: 69/69) and the backend (18 passing integration tests) returns every field the screens read.
- **Not verified:** UI rendering, navigation, Razorpay checkout, GPS, image upload from a device, APK/AAB build. No APK is included.

## Setup (machine with Flutter >= 3.27, Android SDK, JDK 17)
```bash
cd gaoncart_app && ./tools/bootstrap.sh        # generates android/, runs pub get
# apply android_overlay/AndroidManifest.additions.md
flutter analyze && flutter test
flutter run --dart-define=API_BASE_URL=https://api.yourdomain.in
flutter build apk --debug --dart-define=API_BASE_URL=https://api.yourdomain.in
```
Start the backend first (`../gaoncart-backend`, see its README). Real SMS (MSG91) and Razorpay credentials live on the **server only**;
the app receives Razorpay's public key id from the backend per payment and never contains secrets.

## Release (AAB)
Create a keystore, add `android/key.properties`, configure `signingConfigs.release` in `android/app/build.gradle`, then
`flutter build appbundle --release --dart-define=API_BASE_URL=https://api.yourdomain.in`.

## Structure
```
lib/main.dart                      role gate (server role -> dashboard)
lib/core/                          api_client (token refresh, error envelope), token_store (Android Keystore), widgets, location, images
lib/features/auth/                 session + OTP login
lib/features/customer/             home/search/categories/banners, shop, cart, addresses, checkout (COD + Razorpay), orders, tracking, reviews
lib/features/seller/               shop registration/edit, dashboard, orders workflow, products + stock + photos, payouts
lib/features/delivery/             onboarding + documents, online/GPS, requests, active delivery steps (+code), earnings
lib/features/common/               notifications, logout, account deletion
docs/API_INTEGRATION.md            endpoint map, gaps and decisions
tools/contract_check.py            app-vs-backend route verification
```
## Security notes
Tokens in encrypted Android Keystore storage; automatic single-flight refresh with rotation; no secrets in the app; HTTPS-only manifest setting;
client-side input validation mirrors server rules (server remains the authority); images re-validated server-side by magic bytes; online payments are
marked paid **only** after the backend verifies the signature with Razorpay.

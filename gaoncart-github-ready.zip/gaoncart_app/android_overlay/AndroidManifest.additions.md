# Android manifest additions (apply after `flutter create`)

Inside `<manifest>` (before `<application>`):
```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
<queries>
  <intent><action android:name="android.intent.action.DIAL"/><data android:scheme="tel"/></intent>
  <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>
</queries>
```
On `<application>`: `android:label="GaonCart"` and `android:usesCleartextTraffic="false"` (HTTPS only).

`android/app/build.gradle(.kts)`: `minSdk = 21` (Razorpay), keep `compileSdk`/`targetSdk` at the current Play requirement.

Play Console: declare **location** (precise) use, add your privacy policy URL (serve it from `GET /v1/content/privacy_policy`), complete the Data safety form (phone number, name, address, precise location, photos, purchase history), and enable "Delete account" URL/in-app path (Profile → Delete my account).

# GaonCart app <-> backend integration

All 69 distinct calls made by the app are verified against the backend route table by `python3 tools/contract_check.py`.
The backend test `response shapes the Flutter app depends on` pins every response field the Dart code reads.

| Area | Screen | Endpoints |
|---|---|---|
| Auth | Login | `POST /v1/auth/otp/request`, `/otp/verify` (role chosen on screen; **server returns the real role**), `/refresh` (single-flight, rotation), `/logout`; `GET/PATCH /v1/me`; `DELETE /v1/me` |
| Customer | Home | `GET /v1/banners`, `/v1/categories?kind=shop`, `/v1/customer/shops?lat&lng&q&category_id` |
| | Shop | `GET /v1/customer/shops/:id` |
| | Cart | `GET/DELETE /v1/customer/cart`, `PUT /v1/customer/cart/items` |
| | Checkout | `GET/POST/DELETE /v1/customer/addresses`, `POST /v1/customer/checkout/quote`, `POST /v1/customer/orders` (Idempotency-Key), `POST /v1/customer/payments/verify` |
| | Orders | `GET /v1/customer/orders[/:id]`, `/cancel`, `/reorder`, `/review`, `/tracking` (polled every 6 s) |
| Seller | Shop | `GET/POST/PATCH /v1/seller/shop`, `POST /v1/seller/shop/status`, `PATCH /v1/seller/profile` |
| | Products | `GET/POST /v1/seller/products`, `PATCH/DELETE /:id`, `PATCH /:id/stock`, `POST /v1/uploads?kind=product|logo|cover` |
| | Orders | `GET /v1/seller/orders?group=active|completed|cancelled` (polled every 10 s), `POST /:id/accept|reject|preparing|ready|cancel` |
| | Reports | `/v1/seller/reports/sales|earnings|payments` |
| Delivery | Onboarding | `PUT /v1/delivery/profile`, `POST /v1/uploads?kind=partner_doc`, `POST /v1/delivery/documents` |
| | Online + GPS | `POST /v1/delivery/status`, `POST /v1/delivery/location` (real GPS every 6 s while online) |
| | Work | `GET /v1/delivery/requests` (8 s), `POST /v1/delivery/orders/:id/accept|pickup|out-for-delivery|deliver {code}`, `GET /v1/delivery/orders?group=active|history` |
| | Money | `GET /v1/delivery/earnings`, `/payments` |
| All | | `GET /v1/notifications`, `POST /:id/read`, `/read-all`, `POST /v1/support/tickets` |

## Backend change made for the app (smallest compatible)
`migrations/002_banners.sql` + `GET /v1/banners` (public) + `GET/POST/DELETE /v1/admin/banners`. Nothing existing was changed; tests 1-16 still pass.

## Gaps / decisions (documented, not hidden)
1. **Role selection at login.** The backend keeps one account per (role, mobile), so the login screen asks "I am a Customer / Seller / Partner". The dashboard is always chosen from the role the *server* returns. Smallest future change: let `/otp/request` omit `role` for existing numbers and return the roles found.
2. **Reject delivery request** only hides the request locally; there is no server-side "decline" (not needed: the order stays open for other partners).
3. **Product filters.** `/v1/customer/search` exists but is not wired into the UI; category/price filters for *products* need a small backend addition (`category_id`, `min/max price` on search). The home screen filters *shops* by category.
4. **Live map.** Tracking shows the partner's real GPS coordinates, distance and a "View map" button that opens Google Maps. An in-app map needs a Google Maps API key (not provided; add `google_maps_flutter` + key in the manifest).
5. **Realtime.** The backend has SSE (`/v1/stream`); the app currently *polls* (6-10 s). Switch to SSE later for instant seller alerts.
6. **Push notifications (FCM).** Not wired: it needs your Firebase project's `google-services.json`. Device-token endpoint `POST /v1/me/devices` already exists on the backend. Until then, notifications appear in the in-app Notifications screen.
7. **Partner GPS runs only while the app is open** (foreground). Background tracking needs a foreground service + `ACCESS_BACKGROUND_LOCATION` and Play Console justification.
8. **Admin accounts** are rejected by the mobile app (role not in the three mobile roles).
